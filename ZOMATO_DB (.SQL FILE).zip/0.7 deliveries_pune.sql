INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (1, 181, 'ASSIGNED', '2025-02-02 10:12:09', NULL, '2025-09-29 13:19:42', '2025-07-01 18:58:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (2, 633, 'DELIVERED', '2025-08-05 23:38:59', '2025-09-29 14:02:37', '2025-09-29 12:32:01', '2025-05-02 00:09:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (3, 546, 'ASSIGNED', '2025-06-28 15:24:04', NULL, '2025-09-29 12:49:32', '2025-08-21 16:08:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (4, 20, 'ASSIGNED', '2025-04-17 02:41:34', NULL, '2025-09-29 12:31:33', '2025-08-03 02:08:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (5, 89, 'OUT_FOR_DELIVERY', '2025-03-03 13:05:15', NULL, '2025-09-29 13:14:58', '2025-08-29 11:29:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (6, 110, 'CANCELLED', NULL, NULL, NULL, '2025-04-25 15:20:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (7, 140, 'DELIVERED', '2025-06-17 16:22:26', '2025-09-29 13:20:42', '2025-09-29 12:53:59', '2025-07-18 11:04:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (8, 760, 'DELIVERED', '2025-03-04 03:16:19', '2025-09-29 14:26:20', '2025-09-29 12:38:07', '2025-02-09 09:09:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (9, 303, 'PENDING', NULL, NULL, NULL, '2025-07-28 12:43:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (10, 808, 'ASSIGNED', '2025-05-09 17:44:19', NULL, '2025-09-29 13:03:23', '2025-04-19 14:07:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (11, 58, 'PENDING', NULL, NULL, NULL, '2025-01-23 06:35:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (12, 988, 'OUT_FOR_DELIVERY', '2025-09-17 19:50:09', NULL, '2025-09-29 13:02:47', '2025-06-16 19:50:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (13, 65, 'OUT_FOR_DELIVERY', '2025-02-13 20:48:16', NULL, '2025-09-29 12:59:27', '2025-06-18 13:45:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (14, 544, 'DELIVERED', '2025-07-12 13:01:53', '2025-09-29 14:30:38', '2025-09-29 13:00:16', '2025-04-23 17:54:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (15, 37, 'DELIVERED', '2025-08-19 21:43:30', '2025-09-29 13:28:46', '2025-09-29 12:38:03', '2025-04-29 23:00:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (16, 684, 'OUT_FOR_DELIVERY', '2025-05-08 19:33:49', NULL, '2025-09-29 12:59:17', '2025-03-11 20:47:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (17, 474, 'OUT_FOR_DELIVERY', '2025-04-19 19:56:15', NULL, '2025-09-29 12:45:25', '2025-03-02 16:36:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (18, 224, 'OUT_FOR_DELIVERY', '2025-02-10 13:59:12', NULL, '2025-09-29 12:54:55', '2025-07-18 15:37:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (19, 613, 'ASSIGNED', '2025-04-05 06:11:49', NULL, '2025-09-29 13:03:24', '2025-04-30 04:40:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (20, 829, 'ASSIGNED', '2025-07-03 23:10:33', NULL, '2025-09-29 13:01:36', '2025-06-15 07:06:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (21, 700, 'PENDING', NULL, NULL, NULL, '2025-05-15 19:06:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (22, 551, 'PENDING', NULL, NULL, NULL, '2025-07-14 00:31:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (23, 372, 'PENDING', NULL, NULL, NULL, '2025-03-11 00:27:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (24, 778, 'OUT_FOR_DELIVERY', '2025-03-15 06:54:58', NULL, '2025-09-29 13:08:05', '2025-09-11 00:30:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (25, 383, 'CANCELLED', NULL, NULL, NULL, '2025-09-05 16:47:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (26, 80, 'CANCELLED', NULL, NULL, NULL, '2025-01-10 12:10:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (27, 946, 'CANCELLED', NULL, NULL, NULL, '2025-09-23 23:07:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (28, 235, 'ASSIGNED', '2025-09-24 08:28:46', NULL, '2025-09-29 13:00:34', '2025-05-06 23:29:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (29, 78, 'CANCELLED', NULL, NULL, NULL, '2025-03-06 04:53:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (30, 69, 'OUT_FOR_DELIVERY', '2025-02-20 07:01:48', NULL, '2025-09-29 12:28:51', '2025-06-16 06:18:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (31, 110, 'ASSIGNED', '2025-05-04 17:01:34', NULL, '2025-09-29 13:23:54', '2025-01-12 01:45:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (32, 517, 'OUT_FOR_DELIVERY', '2025-03-21 06:45:40', NULL, '2025-09-29 13:09:07', '2025-08-21 13:10:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (33, 617, 'ASSIGNED', '2025-06-25 18:03:32', NULL, '2025-09-29 12:52:59', '2025-08-18 09:37:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (34, 99, 'DELIVERED', '2025-04-17 04:16:34', '2025-09-29 13:03:39', '2025-09-29 13:16:42', '2025-06-21 16:20:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (35, 907, 'DELIVERED', '2025-01-31 03:25:53', '2025-09-29 14:22:27', '2025-09-29 13:10:42', '2025-05-02 00:23:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (36, 361, 'OUT_FOR_DELIVERY', '2025-08-17 04:09:50', NULL, '2025-09-29 13:02:35', '2025-05-21 21:10:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (37, 34, 'PENDING', NULL, NULL, NULL, '2025-03-24 16:26:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (38, 253, 'DELIVERED', '2025-05-28 22:50:49', '2025-09-29 13:06:41', '2025-09-29 13:16:26', '2025-04-17 05:26:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (39, 589, 'PENDING', NULL, NULL, NULL, '2025-05-11 05:03:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (40, 373, 'ASSIGNED', '2025-08-01 15:21:04', NULL, '2025-09-29 12:49:41', '2025-01-26 18:25:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (41, 903, 'CANCELLED', NULL, NULL, NULL, '2025-05-02 20:45:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (42, 137, 'DELIVERED', '2025-02-06 23:43:21', '2025-09-29 13:17:06', '2025-09-29 13:12:02', '2025-03-20 23:56:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (43, 34, 'CANCELLED', NULL, NULL, NULL, '2025-03-11 00:11:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (44, 723, 'PENDING', NULL, NULL, NULL, '2025-06-07 22:49:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (45, 7, 'ASSIGNED', '2025-03-01 15:38:29', NULL, '2025-09-29 12:29:17', '2025-05-04 12:04:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (46, 20, 'DELIVERED', '2025-09-01 11:12:37', '2025-09-29 13:12:44', '2025-09-29 12:52:16', '2025-03-29 08:52:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (47, 731, 'OUT_FOR_DELIVERY', '2025-03-29 04:17:50', NULL, '2025-09-29 12:27:31', '2025-02-08 06:49:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (48, 594, 'CANCELLED', NULL, NULL, NULL, '2025-01-02 04:47:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (49, 20, 'CANCELLED', NULL, NULL, NULL, '2025-04-30 03:26:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (50, 790, 'OUT_FOR_DELIVERY', '2025-08-31 09:45:31', NULL, '2025-09-29 12:35:07', '2025-03-03 03:47:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (51, 188, 'OUT_FOR_DELIVERY', '2025-01-01 02:40:19', NULL, '2025-09-29 13:19:04', '2025-09-14 13:03:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (52, 367, 'CANCELLED', NULL, NULL, NULL, '2025-05-19 08:55:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (53, 174, 'CANCELLED', NULL, NULL, NULL, '2025-07-21 13:34:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (54, 746, 'OUT_FOR_DELIVERY', '2025-09-28 01:54:32', NULL, '2025-09-29 12:36:55', '2025-06-14 06:01:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (55, 870, 'ASSIGNED', '2025-09-20 12:18:17', NULL, '2025-09-29 12:39:24', '2025-05-28 00:13:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (56, 562, 'ASSIGNED', '2025-09-01 03:45:30', NULL, '2025-09-29 12:57:11', '2025-01-05 07:57:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (57, 225, 'ASSIGNED', '2025-01-27 13:17:44', NULL, '2025-09-29 12:38:06', '2025-08-01 08:04:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (58, 592, 'PENDING', NULL, NULL, NULL, '2025-08-08 01:41:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (59, 795, 'ASSIGNED', '2025-07-15 22:54:32', NULL, '2025-09-29 12:51:36', '2025-01-07 08:19:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (60, 481, 'ASSIGNED', '2025-05-01 03:57:07', NULL, '2025-09-29 13:17:23', '2025-02-17 23:50:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (61, 832, 'OUT_FOR_DELIVERY', '2025-05-17 23:57:08', NULL, '2025-09-29 12:43:55', '2025-07-04 23:19:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (62, 424, 'CANCELLED', NULL, NULL, NULL, '2025-01-10 23:50:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (63, 486, 'CANCELLED', NULL, NULL, NULL, '2025-05-27 04:51:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (64, 710, 'OUT_FOR_DELIVERY', '2025-02-21 09:22:32', NULL, '2025-09-29 12:58:09', '2025-07-06 10:52:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (65, 86, 'PENDING', NULL, NULL, NULL, '2025-06-17 06:35:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (66, 648, 'ASSIGNED', '2025-01-12 07:54:48', NULL, '2025-09-29 12:33:28', '2025-04-18 15:41:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (67, 872, 'DELIVERED', '2025-03-02 06:58:26', '2025-09-29 13:00:55', '2025-09-29 13:20:05', '2025-02-12 08:20:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (68, 104, 'ASSIGNED', '2025-07-16 13:45:29', NULL, '2025-09-29 13:07:22', '2025-01-30 23:40:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (69, 591, 'OUT_FOR_DELIVERY', '2025-02-18 16:07:17', NULL, '2025-09-29 12:50:21', '2025-05-04 15:02:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (70, 45, 'PENDING', NULL, NULL, NULL, '2025-02-09 17:03:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (71, 548, 'OUT_FOR_DELIVERY', '2025-05-30 00:37:38', NULL, '2025-09-29 12:34:35', '2025-07-13 11:56:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (72, 393, 'DELIVERED', '2025-08-14 04:16:07', '2025-09-29 13:12:57', '2025-09-29 13:02:09', '2025-05-28 22:14:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (73, 686, 'PENDING', NULL, NULL, NULL, '2025-04-08 11:22:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (74, 567, 'CANCELLED', NULL, NULL, NULL, '2025-04-22 17:21:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (75, 284, 'DELIVERED', '2025-09-27 21:08:37', '2025-09-29 14:41:43', '2025-09-29 13:09:16', '2025-08-19 08:20:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (76, 459, 'PENDING', NULL, NULL, NULL, '2025-05-10 06:02:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (77, 45, 'CANCELLED', NULL, NULL, NULL, '2025-06-23 13:21:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (78, 551, 'OUT_FOR_DELIVERY', '2025-02-21 07:17:25', NULL, '2025-09-29 13:09:23', '2025-05-21 07:42:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (79, 702, 'CANCELLED', NULL, NULL, NULL, '2025-05-08 05:38:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (80, 788, 'ASSIGNED', '2025-02-06 11:38:36', NULL, '2025-09-29 12:50:11', '2025-08-22 04:41:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (81, 395, 'ASSIGNED', '2025-02-12 11:07:57', NULL, '2025-09-29 12:56:35', '2025-07-04 14:16:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (82, 714, 'ASSIGNED', '2025-06-07 11:30:05', NULL, '2025-09-29 12:34:19', '2025-05-10 02:26:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (83, 107, 'ASSIGNED', '2025-04-25 20:59:48', NULL, '2025-09-29 12:49:43', '2025-01-24 10:54:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (84, 558, 'DELIVERED', '2025-03-27 18:02:31', '2025-09-29 14:03:07', '2025-09-29 12:46:13', '2025-03-26 10:29:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (85, 896, 'OUT_FOR_DELIVERY', '2025-08-20 21:49:40', NULL, '2025-09-29 13:19:10', '2025-07-12 18:23:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (86, 841, 'PENDING', NULL, NULL, NULL, '2025-08-31 05:27:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (87, 787, 'OUT_FOR_DELIVERY', '2025-07-07 18:09:18', NULL, '2025-09-29 12:32:17', '2025-05-13 22:05:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (88, 722, 'ASSIGNED', '2025-07-15 12:20:23', NULL, '2025-09-29 13:11:02', '2025-07-02 06:57:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (89, 696, 'PENDING', NULL, NULL, NULL, '2025-05-08 05:39:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (90, 71, 'PENDING', NULL, NULL, NULL, '2025-01-26 12:12:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (91, 200, 'OUT_FOR_DELIVERY', '2025-07-13 04:21:29', NULL, '2025-09-29 13:10:08', '2025-07-19 11:31:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (92, 535, 'ASSIGNED', '2025-01-20 22:40:10', NULL, '2025-09-29 12:55:27', '2025-07-20 10:52:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (93, 936, 'CANCELLED', NULL, NULL, NULL, '2025-03-13 11:13:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (94, 688, 'ASSIGNED', '2025-01-29 04:33:42', NULL, '2025-09-29 13:00:40', '2025-03-26 23:48:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (95, 976, 'ASSIGNED', '2025-07-05 10:17:51', NULL, '2025-09-29 13:04:33', '2025-05-19 12:44:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (96, 389, 'CANCELLED', NULL, NULL, NULL, '2025-04-23 04:07:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (97, 422, 'PENDING', NULL, NULL, NULL, '2025-07-23 17:58:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (98, 691, 'OUT_FOR_DELIVERY', '2025-08-06 12:27:53', NULL, '2025-09-29 12:47:54', '2025-01-05 08:12:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (99, 737, 'ASSIGNED', '2025-08-18 15:06:03', NULL, '2025-09-29 12:27:31', '2025-08-21 17:50:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (100, 721, 'CANCELLED', NULL, NULL, NULL, '2025-03-05 13:07:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (101, 185, 'CANCELLED', NULL, NULL, NULL, '2025-03-23 23:04:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (102, 218, 'DELIVERED', '2025-03-31 20:08:27', '2025-09-29 13:40:41', '2025-09-29 13:02:48', '2025-03-27 19:28:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (103, 394, 'PENDING', NULL, NULL, NULL, '2025-05-31 06:36:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (104, 782, 'ASSIGNED', '2025-09-09 13:15:25', NULL, '2025-09-29 13:12:22', '2025-02-04 16:57:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (105, 206, 'CANCELLED', NULL, NULL, NULL, '2025-01-24 13:55:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (106, 413, 'OUT_FOR_DELIVERY', '2025-09-08 07:40:35', NULL, '2025-09-29 12:52:11', '2025-06-26 00:39:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (107, 306, 'CANCELLED', NULL, NULL, NULL, '2025-05-21 17:20:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (108, 482, 'DELIVERED', '2025-02-21 01:54:43', '2025-09-29 14:40:41', '2025-09-29 13:13:41', '2025-07-14 13:10:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (109, 959, 'DELIVERED', '2025-02-13 09:38:33', '2025-09-29 13:40:47', '2025-09-29 13:09:48', '2025-05-24 10:35:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (110, 594, 'ASSIGNED', '2025-07-04 22:14:19', NULL, '2025-09-29 12:43:22', '2025-01-23 09:26:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (111, 158, 'PENDING', NULL, NULL, NULL, '2025-07-08 19:56:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (112, 950, 'PENDING', NULL, NULL, NULL, '2025-08-15 16:18:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (113, 855, 'PENDING', NULL, NULL, NULL, '2025-08-29 16:45:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (114, 840, 'CANCELLED', NULL, NULL, NULL, '2025-03-04 06:22:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (115, 760, 'ASSIGNED', '2025-07-21 19:51:24', NULL, '2025-09-29 13:23:01', '2025-04-27 03:53:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (116, 495, 'ASSIGNED', '2025-06-16 21:10:59', NULL, '2025-09-29 13:14:04', '2025-01-11 22:19:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (117, 656, 'DELIVERED', '2025-07-03 03:05:39', '2025-09-29 13:30:03', '2025-09-29 12:26:55', '2025-05-14 19:30:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (118, 828, 'ASSIGNED', '2025-09-03 16:59:16', NULL, '2025-09-29 12:43:07', '2025-05-24 08:10:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (119, 742, 'PENDING', NULL, NULL, NULL, '2025-07-18 02:10:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (120, 323, 'DELIVERED', '2025-08-21 04:27:09', '2025-09-29 14:10:32', '2025-09-29 12:38:36', '2025-05-08 21:53:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (121, 509, 'DELIVERED', '2025-06-26 22:17:10', '2025-09-29 13:15:35', '2025-09-29 12:36:46', '2025-06-11 15:57:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (122, 105, 'CANCELLED', NULL, NULL, NULL, '2025-01-04 16:57:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (123, 763, 'ASSIGNED', '2025-02-22 01:23:59', NULL, '2025-09-29 12:35:16', '2025-02-08 01:37:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (124, 928, 'OUT_FOR_DELIVERY', '2025-08-12 00:39:47', NULL, '2025-09-29 13:02:04', '2025-07-14 11:31:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (125, 994, 'OUT_FOR_DELIVERY', '2025-04-15 12:31:38', NULL, '2025-09-29 13:14:03', '2025-08-01 00:26:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (126, 406, 'CANCELLED', NULL, NULL, NULL, '2025-09-29 09:26:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (127, 986, 'CANCELLED', NULL, NULL, NULL, '2025-01-06 18:09:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (128, 186, 'PENDING', NULL, NULL, NULL, '2025-05-08 23:20:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (129, 402, 'ASSIGNED', '2025-03-30 10:24:08', NULL, '2025-09-29 13:10:25', '2025-01-30 16:56:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (130, 955, 'DELIVERED', '2025-02-10 14:24:00', '2025-09-29 13:49:00', '2025-09-29 12:50:02', '2025-06-05 21:17:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (131, 165, 'OUT_FOR_DELIVERY', '2025-04-25 11:27:29', NULL, '2025-09-29 13:01:29', '2025-05-09 16:30:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (132, 791, 'ASSIGNED', '2025-06-26 20:31:40', NULL, '2025-09-29 13:02:59', '2025-02-04 16:48:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (133, 746, 'PENDING', NULL, NULL, NULL, '2025-06-14 15:17:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (134, 683, 'OUT_FOR_DELIVERY', '2025-05-16 04:41:44', NULL, '2025-09-29 12:32:45', '2025-03-28 13:58:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (135, 888, 'PENDING', NULL, NULL, NULL, '2025-07-16 13:32:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (136, 607, 'PENDING', NULL, NULL, NULL, '2025-09-17 19:02:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (137, 327, 'PENDING', NULL, NULL, NULL, '2025-07-31 22:11:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (138, 521, 'OUT_FOR_DELIVERY', '2025-07-27 15:23:50', NULL, '2025-09-29 12:55:52', '2025-06-05 02:53:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (139, 879, 'ASSIGNED', '2025-05-30 03:36:33', NULL, '2025-09-29 13:10:30', '2025-04-30 01:46:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (140, 12, 'ASSIGNED', '2025-04-26 00:31:05', NULL, '2025-09-29 12:32:33', '2025-01-30 10:39:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (141, 883, 'CANCELLED', NULL, NULL, NULL, '2025-05-07 05:53:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (142, 122, 'DELIVERED', '2025-03-01 09:03:54', '2025-09-29 13:21:51', '2025-09-29 13:07:36', '2025-05-15 10:12:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (143, 169, 'PENDING', NULL, NULL, NULL, '2025-03-01 08:29:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (144, 294, 'DELIVERED', '2025-02-21 12:19:46', '2025-09-29 13:33:38', '2025-09-29 13:02:07', '2025-08-16 17:50:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (145, 871, 'DELIVERED', '2025-06-14 22:44:01', '2025-09-29 14:40:15', '2025-09-29 13:10:00', '2025-03-25 14:41:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (146, 491, 'DELIVERED', '2025-06-18 23:33:49', '2025-09-29 14:37:16', '2025-09-29 13:18:48', '2025-06-03 19:56:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (147, 639, 'OUT_FOR_DELIVERY', '2025-03-11 03:36:52', NULL, '2025-09-29 13:20:10', '2025-01-15 18:49:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (148, 618, 'CANCELLED', NULL, NULL, NULL, '2025-03-31 21:48:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (149, 350, 'OUT_FOR_DELIVERY', '2025-04-17 10:55:47', NULL, '2025-09-29 12:48:44', '2025-05-26 18:07:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (150, 901, 'CANCELLED', NULL, NULL, NULL, '2025-07-10 01:29:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (151, 447, 'PENDING', NULL, NULL, NULL, '2025-07-10 20:47:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (152, 188, 'CANCELLED', NULL, NULL, NULL, '2025-04-27 14:07:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (153, 986, 'PENDING', NULL, NULL, NULL, '2025-02-22 04:04:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (154, 225, 'OUT_FOR_DELIVERY', '2025-07-13 01:51:10', NULL, '2025-09-29 13:02:25', '2025-04-24 14:02:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (155, 997, 'OUT_FOR_DELIVERY', '2025-06-21 09:35:19', NULL, '2025-09-29 12:26:53', '2025-08-14 00:37:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (156, 345, 'CANCELLED', NULL, NULL, NULL, '2025-05-26 16:22:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (157, 102, 'OUT_FOR_DELIVERY', '2025-03-30 10:03:59', NULL, '2025-09-29 13:10:01', '2025-07-09 06:23:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (158, 156, 'DELIVERED', '2025-06-14 15:16:09', '2025-09-29 12:58:05', '2025-09-29 12:40:27', '2025-05-12 22:12:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (159, 812, 'PENDING', NULL, NULL, NULL, '2025-05-04 05:23:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (160, 258, 'PENDING', NULL, NULL, NULL, '2025-04-28 16:38:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (161, 155, 'OUT_FOR_DELIVERY', '2025-06-20 15:20:21', NULL, '2025-09-29 12:44:56', '2025-03-26 02:41:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (162, 99, 'PENDING', NULL, NULL, NULL, '2025-06-12 07:12:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (163, 803, 'OUT_FOR_DELIVERY', '2025-05-14 01:01:23', NULL, '2025-09-29 13:03:46', '2025-01-01 02:46:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (164, 688, 'DELIVERED', '2025-04-18 17:11:23', '2025-09-29 12:58:50', '2025-09-29 12:38:04', '2025-09-10 22:36:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (165, 856, 'OUT_FOR_DELIVERY', '2025-06-26 08:28:01', NULL, '2025-09-29 13:04:23', '2025-06-09 09:18:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (166, 858, 'DELIVERED', '2025-02-16 22:46:57', '2025-09-29 13:46:41', '2025-09-29 12:39:51', '2025-05-09 19:58:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (167, 789, 'PENDING', NULL, NULL, NULL, '2025-01-13 23:58:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (168, 420, 'DELIVERED', '2025-07-21 18:48:17', '2025-09-29 14:14:42', '2025-09-29 13:17:36', '2025-09-05 14:00:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (169, 440, 'CANCELLED', NULL, NULL, NULL, '2025-04-05 07:32:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (170, 258, 'DELIVERED', '2025-03-25 02:40:58', '2025-09-29 14:14:01', '2025-09-29 12:54:52', '2025-04-18 21:57:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (171, 321, 'ASSIGNED', '2025-02-28 20:37:09', NULL, '2025-09-29 12:29:21', '2025-04-06 16:04:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (172, 206, 'ASSIGNED', '2025-03-28 01:30:59', NULL, '2025-09-29 12:40:01', '2025-01-18 07:38:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (173, 869, 'DELIVERED', '2025-06-10 19:11:02', '2025-09-29 13:31:23', '2025-09-29 13:23:46', '2025-08-23 23:08:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (174, 489, 'DELIVERED', '2025-09-09 00:29:00', '2025-09-29 14:18:04', '2025-09-29 13:10:31', '2025-04-12 23:49:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (175, 174, 'ASSIGNED', '2025-05-13 21:59:40', NULL, '2025-09-29 13:18:28', '2025-06-27 04:25:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (176, 848, 'PENDING', NULL, NULL, NULL, '2025-09-08 23:55:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (177, 407, 'DELIVERED', '2025-05-08 01:05:56', '2025-09-29 13:04:11', '2025-09-29 13:13:52', '2025-01-10 22:47:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (178, 476, 'DELIVERED', '2025-03-15 19:21:42', '2025-09-29 14:04:46', '2025-09-29 12:31:04', '2025-09-29 05:16:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (179, 721, 'ASSIGNED', '2025-08-28 04:27:45', NULL, '2025-09-29 12:37:33', '2025-08-04 07:32:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (180, 80, 'PENDING', NULL, NULL, NULL, '2025-03-29 04:10:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (181, 793, 'ASSIGNED', '2025-05-02 20:46:30', NULL, '2025-09-29 12:48:38', '2025-03-19 08:49:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (182, 786, 'ASSIGNED', '2025-09-16 15:09:46', NULL, '2025-09-29 12:51:33', '2025-06-02 04:10:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (183, 389, 'CANCELLED', NULL, NULL, NULL, '2025-04-01 11:06:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (184, 97, 'PENDING', NULL, NULL, NULL, '2025-01-22 10:02:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (185, 951, 'DELIVERED', '2025-08-18 13:27:21', '2025-09-29 13:21:03', '2025-09-29 13:11:41', '2025-07-14 09:27:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (186, 787, 'ASSIGNED', '2025-08-12 02:08:10', NULL, '2025-09-29 12:47:11', '2025-07-15 06:55:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (187, 120, 'CANCELLED', NULL, NULL, NULL, '2025-04-13 07:49:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (188, 300, 'ASSIGNED', '2025-02-09 16:17:13', NULL, '2025-09-29 13:24:44', '2025-02-22 20:37:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (189, 514, 'DELIVERED', '2025-02-01 04:35:46', '2025-09-29 14:18:06', '2025-09-29 13:08:11', '2025-07-21 17:40:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (190, 812, 'ASSIGNED', '2025-03-27 08:07:46', NULL, '2025-09-29 12:50:38', '2025-02-07 08:31:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (191, 464, 'DELIVERED', '2025-09-10 15:08:48', '2025-09-29 14:23:14', '2025-09-29 12:37:41', '2025-05-11 08:36:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (192, 660, 'ASSIGNED', '2025-05-18 11:53:23', NULL, '2025-09-29 12:42:11', '2025-08-29 20:57:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (193, 111, 'DELIVERED', '2025-08-31 01:04:27', '2025-09-29 14:06:30', '2025-09-29 13:20:51', '2025-02-17 00:10:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (194, 110, 'ASSIGNED', '2025-07-20 07:45:11', NULL, '2025-09-29 12:29:34', '2025-06-04 16:43:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (195, 304, 'CANCELLED', NULL, NULL, NULL, '2025-09-28 03:12:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (196, 679, 'CANCELLED', NULL, NULL, NULL, '2025-08-04 13:36:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (197, 915, 'CANCELLED', NULL, NULL, NULL, '2025-04-27 00:47:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (198, 163, 'PENDING', NULL, NULL, NULL, '2025-06-10 19:57:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (199, 102, 'ASSIGNED', '2025-01-14 13:54:09', NULL, '2025-09-29 12:40:14', '2025-07-08 06:01:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (200, 261, 'CANCELLED', NULL, NULL, NULL, '2025-06-30 10:53:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (201, 749, 'ASSIGNED', '2025-06-02 12:36:22', NULL, '2025-09-29 13:03:13', '2025-07-03 13:11:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (202, 798, 'OUT_FOR_DELIVERY', '2025-03-17 04:03:08', NULL, '2025-09-29 13:12:24', '2025-08-16 00:06:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (203, 152, 'OUT_FOR_DELIVERY', '2025-08-21 18:12:41', NULL, '2025-09-29 12:49:07', '2025-03-01 03:34:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (204, 329, 'OUT_FOR_DELIVERY', '2025-04-03 10:26:18', NULL, '2025-09-29 13:00:57', '2025-07-14 16:29:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (205, 11, 'DELIVERED', '2025-06-21 06:52:54', '2025-09-29 13:13:33', '2025-09-29 13:05:09', '2025-05-21 05:05:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (206, 520, 'DELIVERED', '2025-01-18 02:00:42', '2025-09-29 12:57:28', '2025-09-29 12:42:02', '2025-01-15 15:05:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (207, 41, 'PENDING', NULL, NULL, NULL, '2025-08-10 03:15:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (208, 91, 'OUT_FOR_DELIVERY', '2025-04-25 21:59:57', NULL, '2025-09-29 13:11:55', '2025-08-08 20:47:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (209, 561, 'ASSIGNED', '2025-06-30 20:35:34', NULL, '2025-09-29 12:57:08', '2025-05-05 16:54:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (210, 283, 'ASSIGNED', '2025-07-30 16:08:33', NULL, '2025-09-29 13:24:27', '2025-04-29 02:56:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (211, 481, 'ASSIGNED', '2025-04-24 04:30:50', NULL, '2025-09-29 13:18:54', '2025-01-11 04:48:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (212, 955, 'DELIVERED', '2025-08-30 17:09:33', '2025-09-29 13:55:47', '2025-09-29 12:35:37', '2025-01-04 17:45:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (213, 218, 'DELIVERED', '2025-04-13 13:59:40', '2025-09-29 13:32:31', '2025-09-29 12:55:25', '2025-04-19 09:43:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (214, 923, 'OUT_FOR_DELIVERY', '2025-06-11 00:57:59', NULL, '2025-09-29 13:00:08', '2025-06-12 17:06:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (215, 790, 'ASSIGNED', '2025-04-04 13:13:25', NULL, '2025-09-29 13:08:15', '2025-08-12 01:00:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (216, 961, 'OUT_FOR_DELIVERY', '2025-02-14 14:48:20', NULL, '2025-09-29 12:41:12', '2025-05-05 16:10:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (217, 50, 'PENDING', NULL, NULL, NULL, '2025-05-13 06:12:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (218, 499, 'ASSIGNED', '2025-09-14 18:33:53', NULL, '2025-09-29 12:57:32', '2025-08-09 19:57:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (219, 27, 'OUT_FOR_DELIVERY', '2025-07-04 13:22:32', NULL, '2025-09-29 13:16:15', '2025-07-23 00:44:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (220, 326, 'PENDING', NULL, NULL, NULL, '2025-03-29 10:52:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (221, 425, 'PENDING', NULL, NULL, NULL, '2025-05-01 15:10:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (222, 291, 'DELIVERED', '2025-03-11 20:06:29', '2025-09-29 14:24:57', '2025-09-29 12:57:59', '2025-01-07 04:07:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (223, 494, 'CANCELLED', NULL, NULL, NULL, '2025-08-21 13:47:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (224, 967, 'PENDING', NULL, NULL, NULL, '2025-01-03 02:08:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (225, 636, 'CANCELLED', NULL, NULL, NULL, '2025-09-12 08:04:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (226, 636, 'OUT_FOR_DELIVERY', '2025-06-14 17:31:25', NULL, '2025-09-29 13:00:07', '2025-09-21 08:50:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (227, 646, 'OUT_FOR_DELIVERY', '2025-05-23 23:06:51', NULL, '2025-09-29 12:51:52', '2025-01-04 15:58:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (228, 788, 'CANCELLED', NULL, NULL, NULL, '2025-06-21 20:38:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (229, 197, 'DELIVERED', '2025-03-02 10:50:27', '2025-09-29 13:55:44', '2025-09-29 13:03:17', '2025-03-22 22:53:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (230, 253, 'ASSIGNED', '2025-01-01 17:35:06', NULL, '2025-09-29 12:27:40', '2025-08-28 09:15:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (231, 920, 'ASSIGNED', '2025-07-16 00:43:11', NULL, '2025-09-29 13:23:07', '2025-02-20 04:48:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (232, 631, 'DELIVERED', '2025-01-03 22:03:30', '2025-09-29 13:52:34', '2025-09-29 12:30:33', '2025-06-14 03:04:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (233, 806, 'ASSIGNED', '2025-08-31 02:30:22', NULL, '2025-09-29 13:16:13', '2025-07-05 19:04:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (234, 852, 'PENDING', NULL, NULL, NULL, '2025-02-25 19:45:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (235, 791, 'DELIVERED', '2025-03-30 03:58:19', '2025-09-29 13:46:19', '2025-09-29 13:20:47', '2025-07-09 07:13:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (236, 589, 'CANCELLED', NULL, NULL, NULL, '2025-08-26 14:18:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (237, 777, 'ASSIGNED', '2025-06-05 15:24:07', NULL, '2025-09-29 12:59:09', '2025-05-06 09:16:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (238, 107, 'DELIVERED', '2025-05-17 05:44:14', '2025-09-29 14:54:49', '2025-09-29 13:25:06', '2025-03-29 18:26:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (239, 51, 'DELIVERED', '2025-04-04 15:45:20', '2025-09-29 12:57:32', '2025-09-29 12:36:11', '2025-08-25 01:53:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (240, 581, 'DELIVERED', '2025-03-22 06:59:21', '2025-09-29 13:36:49', '2025-09-29 12:43:29', '2025-07-08 10:39:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (241, 813, 'OUT_FOR_DELIVERY', '2025-06-24 17:29:35', NULL, '2025-09-29 12:50:37', '2025-03-16 07:02:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (242, 683, 'CANCELLED', NULL, NULL, NULL, '2025-03-26 14:52:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (243, 982, 'DELIVERED', '2025-09-26 05:00:42', '2025-09-29 13:02:47', '2025-09-29 13:24:24', '2025-05-20 12:53:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (244, 2, 'DELIVERED', '2025-02-27 08:46:55', '2025-09-29 13:16:30', '2025-09-29 13:23:52', '2025-03-02 09:20:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (245, 318, 'OUT_FOR_DELIVERY', '2025-06-26 02:54:11', NULL, '2025-09-29 12:37:03', '2025-05-31 11:18:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (246, 797, 'PENDING', NULL, NULL, NULL, '2025-08-08 08:15:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (247, 799, 'OUT_FOR_DELIVERY', '2025-07-26 05:48:13', NULL, '2025-09-29 12:45:10', '2025-02-27 17:51:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (248, 553, 'ASSIGNED', '2025-08-03 15:57:24', NULL, '2025-09-29 12:42:23', '2025-08-18 18:51:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (249, 575, 'DELIVERED', '2025-03-31 14:19:34', '2025-09-29 13:04:59', '2025-09-29 13:18:47', '2025-05-09 05:41:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (250, 623, 'PENDING', NULL, NULL, NULL, '2025-01-19 23:44:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (251, 499, 'DELIVERED', '2025-02-16 15:11:24', '2025-09-29 13:06:05', '2025-09-29 12:41:13', '2025-05-07 23:47:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (252, 953, 'PENDING', NULL, NULL, NULL, '2025-09-23 23:07:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (253, 187, 'PENDING', NULL, NULL, NULL, '2025-05-09 12:36:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (254, 933, 'OUT_FOR_DELIVERY', '2025-09-05 23:59:00', NULL, '2025-09-29 12:38:59', '2025-05-28 01:37:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (255, 191, 'CANCELLED', NULL, NULL, NULL, '2025-03-14 07:58:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (256, 514, 'OUT_FOR_DELIVERY', '2025-03-19 22:25:12', NULL, '2025-09-29 13:16:48', '2025-08-12 22:12:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (257, 523, 'PENDING', NULL, NULL, NULL, '2025-09-25 20:23:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (258, 853, 'OUT_FOR_DELIVERY', '2025-09-01 12:04:27', NULL, '2025-09-29 12:52:46', '2025-04-18 01:51:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (259, 302, 'OUT_FOR_DELIVERY', '2025-07-08 10:25:27', NULL, '2025-09-29 13:24:14', '2025-07-31 05:57:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (260, 833, 'CANCELLED', NULL, NULL, NULL, '2025-02-02 18:35:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (261, 846, 'PENDING', NULL, NULL, NULL, '2025-05-20 05:19:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (262, 504, 'PENDING', NULL, NULL, NULL, '2025-05-08 14:45:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (263, 338, 'CANCELLED', NULL, NULL, NULL, '2025-06-10 00:27:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (264, 982, 'ASSIGNED', '2025-07-04 04:23:09', NULL, '2025-09-29 13:19:12', '2025-02-15 09:09:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (265, 650, 'OUT_FOR_DELIVERY', '2025-02-12 18:15:47', NULL, '2025-09-29 12:53:55', '2025-09-10 08:56:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (266, 179, 'PENDING', NULL, NULL, NULL, '2025-05-29 02:41:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (267, 592, 'CANCELLED', NULL, NULL, NULL, '2025-07-18 02:05:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (268, 116, 'PENDING', NULL, NULL, NULL, '2025-01-28 18:16:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (269, 976, 'PENDING', NULL, NULL, NULL, '2025-08-05 03:35:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (270, 672, 'PENDING', NULL, NULL, NULL, '2025-04-11 20:22:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (271, 157, 'OUT_FOR_DELIVERY', '2025-04-16 02:06:58', NULL, '2025-09-29 13:25:40', '2025-08-13 10:38:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (272, 281, 'OUT_FOR_DELIVERY', '2025-03-09 04:34:11', NULL, '2025-09-29 13:10:37', '2025-07-23 18:34:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (273, 703, 'PENDING', NULL, NULL, NULL, '2025-08-24 17:26:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (274, 918, 'DELIVERED', '2025-06-07 06:37:25', '2025-09-29 14:35:41', '2025-09-29 12:59:55', '2025-05-21 12:49:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (275, 28, 'DELIVERED', '2025-05-12 23:12:15', '2025-09-29 14:12:15', '2025-09-29 13:14:53', '2025-09-07 20:16:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (276, 908, 'DELIVERED', '2025-09-29 05:26:20', '2025-09-29 14:02:46', '2025-09-29 12:39:10', '2025-04-17 13:27:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (277, 960, 'PENDING', NULL, NULL, NULL, '2025-04-29 23:05:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (278, 4, 'ASSIGNED', '2025-04-10 05:31:56', NULL, '2025-09-29 12:58:53', '2025-05-28 14:43:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (279, 531, 'OUT_FOR_DELIVERY', '2025-01-19 22:09:08', NULL, '2025-09-29 13:08:26', '2025-05-08 14:12:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (280, 435, 'CANCELLED', NULL, NULL, NULL, '2025-02-06 16:38:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (281, 221, 'OUT_FOR_DELIVERY', '2025-05-29 18:13:41', NULL, '2025-09-29 13:16:20', '2025-04-22 19:26:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (282, 343, 'PENDING', NULL, NULL, NULL, '2025-07-26 17:30:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (283, 664, 'DELIVERED', '2025-09-13 11:59:11', '2025-09-29 13:24:23', '2025-09-29 12:44:24', '2025-01-16 10:05:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (284, 301, 'CANCELLED', NULL, NULL, NULL, '2025-02-04 12:03:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (285, 107, 'ASSIGNED', '2025-09-24 09:31:01', NULL, '2025-09-29 13:05:29', '2025-04-14 23:15:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (286, 793, 'CANCELLED', NULL, NULL, NULL, '2025-02-16 23:38:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (287, 96, 'DELIVERED', '2025-02-16 05:08:58', '2025-09-29 14:03:19', '2025-09-29 13:16:48', '2025-08-08 08:28:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (288, 143, 'PENDING', NULL, NULL, NULL, '2025-09-13 07:06:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (289, 961, 'PENDING', NULL, NULL, NULL, '2025-04-27 04:20:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (290, 904, 'PENDING', NULL, NULL, NULL, '2025-09-27 08:28:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (291, 147, 'DELIVERED', '2025-06-24 01:48:30', '2025-09-29 14:44:04', '2025-09-29 12:32:32', '2025-02-19 03:28:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (292, 448, 'ASSIGNED', '2025-08-04 15:14:47', NULL, '2025-09-29 12:55:59', '2025-05-11 19:59:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (293, 641, 'OUT_FOR_DELIVERY', '2025-05-02 11:16:18', NULL, '2025-09-29 12:42:04', '2025-02-01 08:46:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (294, 976, 'OUT_FOR_DELIVERY', '2025-06-18 22:24:19', NULL, '2025-09-29 12:47:57', '2025-01-21 12:28:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (295, 666, 'OUT_FOR_DELIVERY', '2025-08-16 07:08:28', NULL, '2025-09-29 13:13:03', '2025-09-05 19:38:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (296, 252, 'OUT_FOR_DELIVERY', '2025-08-27 19:13:01', NULL, '2025-09-29 13:10:48', '2025-01-04 15:26:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (297, 941, 'OUT_FOR_DELIVERY', '2025-03-25 23:05:08', NULL, '2025-09-29 12:31:00', '2025-03-10 01:33:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (298, 821, 'CANCELLED', NULL, NULL, NULL, '2025-04-07 07:08:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (299, 485, 'DELIVERED', '2025-04-26 08:28:32', '2025-09-29 13:05:16', '2025-09-29 13:01:43', '2025-01-24 04:45:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (300, 108, 'CANCELLED', NULL, NULL, NULL, '2025-02-01 02:58:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (301, 446, 'DELIVERED', '2025-04-20 10:10:03', '2025-09-29 13:18:12', '2025-09-29 13:02:17', '2025-03-19 22:47:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (302, 926, 'PENDING', NULL, NULL, NULL, '2025-06-05 09:35:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (303, 289, 'ASSIGNED', '2025-07-30 06:44:52', NULL, '2025-09-29 13:00:17', '2025-08-06 07:18:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (304, 609, 'PENDING', NULL, NULL, NULL, '2025-08-28 18:42:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (305, 463, 'PENDING', NULL, NULL, NULL, '2025-01-06 12:52:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (306, 714, 'DELIVERED', '2025-07-28 11:08:29', '2025-09-29 13:00:49', '2025-09-29 12:45:42', '2025-08-02 03:01:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (307, 974, 'OUT_FOR_DELIVERY', '2025-07-13 10:56:14', NULL, '2025-09-29 12:49:41', '2025-06-10 02:30:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (308, 360, 'ASSIGNED', '2025-04-11 13:00:14', NULL, '2025-09-29 13:11:52', '2025-02-12 00:01:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (309, 964, 'ASSIGNED', '2025-01-24 23:37:35', NULL, '2025-09-29 12:49:37', '2025-04-12 13:10:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (310, 307, 'ASSIGNED', '2025-04-11 04:39:56', NULL, '2025-09-29 12:41:41', '2025-04-03 03:53:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (311, 307, 'DELIVERED', '2025-05-29 06:00:14', '2025-09-29 13:59:07', '2025-09-29 12:53:28', '2025-09-20 08:23:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (312, 743, 'ASSIGNED', '2025-07-31 02:48:35', NULL, '2025-09-29 13:25:58', '2025-09-02 06:29:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (313, 642, 'ASSIGNED', '2025-03-23 05:04:47', NULL, '2025-09-29 13:00:09', '2025-04-19 01:23:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (314, 2, 'CANCELLED', NULL, NULL, NULL, '2025-09-03 03:09:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (315, 334, 'OUT_FOR_DELIVERY', '2025-09-08 23:28:40', NULL, '2025-09-29 12:43:00', '2025-01-26 07:44:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (316, 175, 'CANCELLED', NULL, NULL, NULL, '2025-09-08 17:28:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (317, 861, 'DELIVERED', '2025-08-13 02:36:27', '2025-09-29 13:35:51', '2025-09-29 12:36:10', '2025-06-25 23:32:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (318, 932, 'OUT_FOR_DELIVERY', '2025-08-29 18:57:52', NULL, '2025-09-29 13:05:35', '2025-09-25 08:45:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (319, 669, 'DELIVERED', '2025-04-04 05:04:58', '2025-09-29 13:48:55', '2025-09-29 12:38:29', '2025-02-21 16:52:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (320, 599, 'CANCELLED', NULL, NULL, NULL, '2025-06-03 15:59:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (321, 766, 'OUT_FOR_DELIVERY', '2025-05-19 23:56:29', NULL, '2025-09-29 12:39:25', '2025-04-18 11:39:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (322, 966, 'CANCELLED', NULL, NULL, NULL, '2025-05-18 14:57:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (323, 612, 'CANCELLED', NULL, NULL, NULL, '2025-07-24 21:26:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (324, 397, 'OUT_FOR_DELIVERY', '2025-09-19 13:22:59', NULL, '2025-09-29 13:24:40', '2025-02-09 00:06:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (325, 699, 'CANCELLED', NULL, NULL, NULL, '2025-07-11 20:15:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (326, 885, 'OUT_FOR_DELIVERY', '2025-03-25 13:58:27', NULL, '2025-09-29 12:52:06', '2025-09-19 20:06:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (327, 972, 'DELIVERED', '2025-05-02 03:46:08', '2025-09-29 14:00:25', '2025-09-29 12:40:56', '2025-08-06 10:37:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (328, 291, 'CANCELLED', NULL, NULL, NULL, '2025-08-05 14:39:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (329, 186, 'OUT_FOR_DELIVERY', '2025-08-26 04:43:16', NULL, '2025-09-29 12:30:24', '2025-02-20 13:26:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (330, 114, 'DELIVERED', '2025-01-13 07:06:33', '2025-09-29 13:17:47', '2025-09-29 12:34:45', '2025-01-27 01:15:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (331, 940, 'OUT_FOR_DELIVERY', '2025-03-26 11:39:13', NULL, '2025-09-29 13:21:32', '2025-07-24 20:41:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (332, 401, 'CANCELLED', NULL, NULL, NULL, '2025-06-18 16:04:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (333, 848, 'PENDING', NULL, NULL, NULL, '2025-04-28 21:46:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (334, 485, 'ASSIGNED', '2025-06-28 01:13:10', NULL, '2025-09-29 12:46:08', '2025-04-07 05:19:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (335, 309, 'CANCELLED', NULL, NULL, NULL, '2025-05-19 14:11:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (336, 256, 'DELIVERED', '2025-07-28 08:06:04', '2025-09-29 14:27:06', '2025-09-29 13:15:56', '2025-05-16 03:05:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (337, 947, 'DELIVERED', '2025-03-28 17:55:25', '2025-09-29 13:08:25', '2025-09-29 13:00:20', '2025-02-01 20:50:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (338, 451, 'DELIVERED', '2025-09-22 22:07:18', '2025-09-29 14:11:19', '2025-09-29 12:30:51', '2025-07-22 09:28:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (339, 242, 'DELIVERED', '2025-05-31 23:52:01', '2025-09-29 14:01:52', '2025-09-29 13:12:51', '2025-01-17 00:50:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (340, 52, 'PENDING', NULL, NULL, NULL, '2025-03-25 23:07:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (341, 899, 'OUT_FOR_DELIVERY', '2025-07-21 15:04:31', NULL, '2025-09-29 12:26:24', '2025-07-12 05:27:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (342, 911, 'ASSIGNED', '2025-05-09 12:43:22', NULL, '2025-09-29 12:31:00', '2025-04-28 04:48:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (343, 138, 'ASSIGNED', '2025-09-26 22:22:46', NULL, '2025-09-29 13:20:57', '2025-05-24 02:48:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (344, 669, 'PENDING', NULL, NULL, NULL, '2025-02-15 04:07:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (345, 337, 'ASSIGNED', '2025-06-11 20:44:34', NULL, '2025-09-29 12:52:52', '2025-09-06 13:18:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (346, 603, 'OUT_FOR_DELIVERY', '2025-02-18 18:52:38', NULL, '2025-09-29 12:33:08', '2025-09-17 06:34:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (347, 200, 'DELIVERED', '2025-08-14 23:48:45', '2025-09-29 13:43:40', '2025-09-29 12:36:50', '2025-01-01 20:30:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (348, 932, 'CANCELLED', NULL, NULL, NULL, '2025-05-28 02:26:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (349, 321, 'OUT_FOR_DELIVERY', '2025-09-12 04:52:51', NULL, '2025-09-29 12:58:39', '2025-08-22 07:47:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (350, 514, 'DELIVERED', '2025-07-13 06:26:19', '2025-09-29 13:55:34', '2025-09-29 13:26:03', '2025-08-13 16:10:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (351, 846, 'OUT_FOR_DELIVERY', '2025-07-27 19:07:03', NULL, '2025-09-29 13:13:55', '2025-07-22 13:57:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (352, 680, 'DELIVERED', '2025-06-23 19:14:23', '2025-09-29 14:32:25', '2025-09-29 13:08:46', '2025-08-10 04:07:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (353, 538, 'DELIVERED', '2025-02-09 14:40:30', '2025-09-29 14:38:42', '2025-09-29 12:54:06', '2025-01-31 20:20:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (354, 793, 'CANCELLED', NULL, NULL, NULL, '2025-05-02 23:50:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (355, 975, 'CANCELLED', NULL, NULL, NULL, '2025-03-28 18:42:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (356, 48, 'DELIVERED', '2025-04-22 18:48:56', '2025-09-29 13:24:38', '2025-09-29 13:20:32', '2025-03-25 05:37:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (357, 147, 'OUT_FOR_DELIVERY', '2025-06-10 22:23:31', NULL, '2025-09-29 13:06:17', '2025-04-28 22:52:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (358, 754, 'ASSIGNED', '2025-07-01 20:25:06', NULL, '2025-09-29 13:13:32', '2025-03-23 16:37:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (359, 221, 'CANCELLED', NULL, NULL, NULL, '2025-07-02 20:02:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (360, 528, 'ASSIGNED', '2025-08-15 11:21:30', NULL, '2025-09-29 13:10:14', '2025-05-27 21:02:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (361, 201, 'DELIVERED', '2025-03-07 23:12:16', '2025-09-29 14:28:50', '2025-09-29 12:51:03', '2025-04-03 05:55:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (362, 131, 'DELIVERED', '2025-07-31 20:16:41', '2025-09-29 13:37:28', '2025-09-29 12:35:02', '2025-07-12 02:18:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (363, 416, 'PENDING', NULL, NULL, NULL, '2025-08-11 19:02:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (364, 276, 'PENDING', NULL, NULL, NULL, '2025-01-16 21:46:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (365, 688, 'PENDING', NULL, NULL, NULL, '2025-02-09 08:56:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (366, 389, 'PENDING', NULL, NULL, NULL, '2025-06-06 15:30:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (367, 543, 'ASSIGNED', '2025-04-29 22:06:31', NULL, '2025-09-29 12:40:10', '2025-04-15 04:23:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (368, 388, 'ASSIGNED', '2025-07-22 01:54:34', NULL, '2025-09-29 12:40:09', '2025-01-03 19:04:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (369, 882, 'CANCELLED', NULL, NULL, NULL, '2025-01-18 06:37:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (370, 168, 'DELIVERED', '2025-01-20 18:16:22', '2025-09-29 13:20:45', '2025-09-29 13:04:05', '2025-02-14 01:34:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (371, 485, 'OUT_FOR_DELIVERY', '2025-01-10 12:59:01', NULL, '2025-09-29 12:40:18', '2025-04-12 09:23:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (372, 834, 'CANCELLED', NULL, NULL, NULL, '2025-06-20 08:50:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (373, 794, 'ASSIGNED', '2025-05-12 14:40:21', NULL, '2025-09-29 13:05:28', '2025-08-13 05:57:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (374, 234, 'OUT_FOR_DELIVERY', '2025-02-20 23:02:08', NULL, '2025-09-29 12:46:51', '2025-08-16 00:30:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (375, 518, 'DELIVERED', '2025-04-11 09:10:33', '2025-09-29 14:51:38', '2025-09-29 13:22:09', '2025-07-16 05:45:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (376, 33, 'DELIVERED', '2025-09-08 08:22:23', '2025-09-29 13:41:06', '2025-09-29 13:16:40', '2025-02-21 00:36:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (377, 571, 'OUT_FOR_DELIVERY', '2025-03-18 14:19:36', NULL, '2025-09-29 13:23:08', '2025-07-30 07:35:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (378, 810, 'DELIVERED', '2025-04-30 00:51:20', '2025-09-29 14:41:34', '2025-09-29 12:52:23', '2025-09-27 22:08:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (379, 859, 'ASSIGNED', '2025-04-11 10:36:29', NULL, '2025-09-29 13:19:47', '2025-02-16 08:50:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (380, 962, 'PENDING', NULL, NULL, NULL, '2025-07-05 23:38:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (381, 804, 'PENDING', NULL, NULL, NULL, '2025-01-12 03:50:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (382, 850, 'OUT_FOR_DELIVERY', '2025-04-03 15:40:23', NULL, '2025-09-29 12:49:45', '2025-06-22 14:55:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (383, 24, 'PENDING', NULL, NULL, NULL, '2025-07-23 07:39:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (384, 747, 'CANCELLED', NULL, NULL, NULL, '2025-07-03 07:31:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (385, 869, 'ASSIGNED', '2025-06-11 04:28:25', NULL, '2025-09-29 12:50:17', '2025-08-06 04:34:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (386, 572, 'PENDING', NULL, NULL, NULL, '2025-08-31 04:23:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (387, 135, 'PENDING', NULL, NULL, NULL, '2025-03-09 14:28:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (388, 363, 'ASSIGNED', '2025-09-23 18:19:11', NULL, '2025-09-29 12:31:02', '2025-04-26 17:42:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (389, 342, 'PENDING', NULL, NULL, NULL, '2025-07-07 23:59:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (390, 128, 'PENDING', NULL, NULL, NULL, '2025-01-10 19:52:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (391, 8, 'PENDING', NULL, NULL, NULL, '2025-05-11 20:35:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (392, 392, 'PENDING', NULL, NULL, NULL, '2025-05-07 20:34:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (393, 766, 'DELIVERED', '2025-06-23 05:04:17', '2025-09-29 14:40:51', '2025-09-29 12:29:28', '2025-05-25 21:29:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (394, 956, 'DELIVERED', '2025-03-23 17:48:59', '2025-09-29 13:19:20', '2025-09-29 13:05:19', '2025-09-24 01:49:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (395, 480, 'OUT_FOR_DELIVERY', '2025-09-16 20:13:30', NULL, '2025-09-29 12:46:37', '2025-03-01 14:43:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (396, 533, 'ASSIGNED', '2025-05-30 22:30:40', NULL, '2025-09-29 12:51:15', '2025-02-14 20:16:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (397, 80, 'CANCELLED', NULL, NULL, NULL, '2025-05-25 23:20:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (398, 489, 'DELIVERED', '2025-04-08 12:42:48', '2025-09-29 14:14:49', '2025-09-29 13:11:39', '2025-03-17 04:46:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (399, 726, 'PENDING', NULL, NULL, NULL, '2025-09-12 09:07:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (400, 585, 'DELIVERED', '2025-03-11 10:40:52', '2025-09-29 13:23:28', '2025-09-29 13:11:25', '2025-09-23 00:17:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (401, 502, 'ASSIGNED', '2025-01-17 13:57:25', NULL, '2025-09-29 13:25:11', '2025-06-07 05:53:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (402, 589, 'DELIVERED', '2025-06-05 16:46:06', '2025-09-29 13:57:11', '2025-09-29 13:23:54', '2025-04-11 06:04:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (403, 797, 'OUT_FOR_DELIVERY', '2025-04-28 12:03:02', NULL, '2025-09-29 12:27:07', '2025-06-21 10:18:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (404, 552, 'OUT_FOR_DELIVERY', '2025-06-04 10:40:35', NULL, '2025-09-29 13:25:11', '2025-05-09 06:46:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (405, 411, 'DELIVERED', '2025-01-22 02:25:42', '2025-09-29 13:54:28', '2025-09-29 12:48:11', '2025-08-07 20:45:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (406, 188, 'ASSIGNED', '2025-01-11 01:37:17', NULL, '2025-09-29 12:29:32', '2025-05-21 23:43:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (407, 798, 'PENDING', NULL, NULL, NULL, '2025-01-18 09:12:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (408, 58, 'OUT_FOR_DELIVERY', '2025-03-04 00:09:01', NULL, '2025-09-29 12:51:34', '2025-03-24 20:19:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (409, 584, 'PENDING', NULL, NULL, NULL, '2025-06-07 21:16:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (410, 552, 'ASSIGNED', '2025-09-11 12:29:05', NULL, '2025-09-29 12:34:45', '2025-03-08 16:20:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (411, 494, 'OUT_FOR_DELIVERY', '2025-03-12 22:48:51', NULL, '2025-09-29 12:42:51', '2025-04-11 05:09:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (412, 661, 'ASSIGNED', '2025-03-10 12:25:20', NULL, '2025-09-29 12:59:49', '2025-02-10 18:46:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (413, 409, 'CANCELLED', NULL, NULL, NULL, '2025-03-06 14:43:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (414, 590, 'DELIVERED', '2025-02-24 06:19:01', '2025-09-29 13:02:28', '2025-09-29 13:19:21', '2025-06-23 14:50:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (415, 914, 'OUT_FOR_DELIVERY', '2025-05-17 10:04:17', NULL, '2025-09-29 13:15:16', '2025-07-06 17:47:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (416, 83, 'ASSIGNED', '2025-06-05 21:54:04', NULL, '2025-09-29 13:14:06', '2025-01-13 12:59:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (417, 705, 'DELIVERED', '2025-01-23 18:18:28', '2025-09-29 13:59:50', '2025-09-29 13:21:32', '2025-03-05 21:41:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (418, 493, 'ASSIGNED', '2025-09-07 09:48:39', NULL, '2025-09-29 12:54:21', '2025-04-21 09:15:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (419, 73, 'ASSIGNED', '2025-02-07 23:12:16', NULL, '2025-09-29 13:01:46', '2025-06-24 03:12:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (420, 473, 'CANCELLED', NULL, NULL, NULL, '2025-02-09 17:40:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (421, 682, 'ASSIGNED', '2025-06-06 13:59:26', NULL, '2025-09-29 12:27:08', '2025-03-24 10:41:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (422, 145, 'CANCELLED', NULL, NULL, NULL, '2025-07-01 06:01:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (423, 942, 'CANCELLED', NULL, NULL, NULL, '2025-05-11 16:56:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (424, 656, 'DELIVERED', '2025-05-10 14:02:24', '2025-09-29 13:05:59', '2025-09-29 12:40:10', '2025-03-24 17:29:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (425, 883, 'DELIVERED', '2025-01-02 00:48:17', '2025-09-29 14:15:30', '2025-09-29 12:41:22', '2025-07-28 03:42:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (426, 179, 'ASSIGNED', '2025-03-06 18:26:37', NULL, '2025-09-29 13:00:43', '2025-07-07 06:20:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (427, 292, 'PENDING', NULL, NULL, NULL, '2025-08-29 10:13:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (428, 903, 'CANCELLED', NULL, NULL, NULL, '2025-09-06 04:27:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (429, 631, 'ASSIGNED', '2025-01-01 08:54:48', NULL, '2025-09-29 13:03:30', '2025-09-02 11:19:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (430, 199, 'CANCELLED', NULL, NULL, NULL, '2025-09-12 09:48:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (431, 100, 'PENDING', NULL, NULL, NULL, '2025-08-26 23:20:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (432, 374, 'PENDING', NULL, NULL, NULL, '2025-05-24 19:28:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (433, 74, 'OUT_FOR_DELIVERY', '2025-09-09 19:37:42', NULL, '2025-09-29 13:19:47', '2025-06-25 01:30:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (434, 489, 'DELIVERED', '2025-08-30 12:11:34', '2025-09-29 13:18:20', '2025-09-29 13:15:08', '2025-09-15 02:53:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (435, 828, 'ASSIGNED', '2025-01-22 01:13:40', NULL, '2025-09-29 12:28:27', '2025-03-07 20:48:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (436, 957, 'CANCELLED', NULL, NULL, NULL, '2025-02-22 23:54:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (437, 313, 'DELIVERED', '2025-08-21 12:05:30', '2025-09-29 14:39:29', '2025-09-29 12:57:21', '2025-04-09 02:30:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (438, 990, 'DELIVERED', '2025-04-07 15:15:17', '2025-09-29 13:18:27', '2025-09-29 13:24:19', '2025-08-02 11:45:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (439, 115, 'ASSIGNED', '2025-05-17 05:20:22', NULL, '2025-09-29 12:41:07', '2025-01-24 12:07:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (440, 533, 'OUT_FOR_DELIVERY', '2025-03-27 04:17:04', NULL, '2025-09-29 13:19:40', '2025-01-21 04:01:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (441, 242, 'ASSIGNED', '2025-08-29 22:01:03', NULL, '2025-09-29 13:04:22', '2025-01-21 19:34:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (442, 615, 'CANCELLED', NULL, NULL, NULL, '2025-02-12 15:36:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (443, 473, 'CANCELLED', NULL, NULL, NULL, '2025-05-21 13:21:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (444, 21, 'DELIVERED', '2025-04-20 04:26:11', '2025-09-29 13:59:42', '2025-09-29 13:01:46', '2025-05-06 19:11:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (445, 398, 'ASSIGNED', '2025-07-03 14:40:30', NULL, '2025-09-29 13:12:51', '2025-09-15 10:45:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (446, 936, 'DELIVERED', '2025-05-03 15:51:12', '2025-09-29 13:03:36', '2025-09-29 12:45:55', '2025-08-21 03:36:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (447, 710, 'PENDING', NULL, NULL, NULL, '2025-02-05 21:55:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (448, 578, 'ASSIGNED', '2025-02-09 18:07:55', NULL, '2025-09-29 13:06:59', '2025-01-16 00:08:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (449, 3, 'PENDING', NULL, NULL, NULL, '2025-08-11 01:35:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (450, 158, 'DELIVERED', '2025-02-18 20:35:12', '2025-09-29 13:36:05', '2025-09-29 13:16:42', '2025-02-04 05:57:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (451, 629, 'OUT_FOR_DELIVERY', '2025-04-05 19:48:41', NULL, '2025-09-29 13:25:55', '2025-04-20 10:05:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (452, 817, 'DELIVERED', '2025-05-09 07:24:35', '2025-09-29 14:10:46', '2025-09-29 12:34:18', '2025-06-29 13:10:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (453, 451, 'DELIVERED', '2025-05-24 18:04:28', '2025-09-29 13:54:13', '2025-09-29 12:40:47', '2025-03-30 09:51:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (454, 58, 'DELIVERED', '2025-07-04 09:16:16', '2025-09-29 13:02:22', '2025-09-29 12:49:40', '2025-08-31 02:54:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (455, 598, 'OUT_FOR_DELIVERY', '2025-01-15 01:14:50', NULL, '2025-09-29 12:46:24', '2025-01-31 22:46:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (456, 443, 'DELIVERED', '2025-05-06 16:17:31', '2025-09-29 13:06:28', '2025-09-29 12:33:18', '2025-01-03 08:07:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (457, 106, 'DELIVERED', '2025-04-29 17:56:32', '2025-09-29 13:33:15', '2025-09-29 12:38:28', '2025-03-27 08:34:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (458, 615, 'CANCELLED', NULL, NULL, NULL, '2025-02-26 16:27:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (459, 746, 'ASSIGNED', '2025-07-01 05:47:13', NULL, '2025-09-29 13:02:04', '2025-01-22 22:30:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (460, 850, 'ASSIGNED', '2025-05-01 05:01:14', NULL, '2025-09-29 12:43:29', '2025-08-07 09:32:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (461, 494, 'CANCELLED', NULL, NULL, NULL, '2025-01-25 10:51:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (462, 818, 'DELIVERED', '2025-05-19 14:38:01', '2025-09-29 13:26:27', '2025-09-29 12:58:05', '2025-01-22 06:37:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (463, 96, 'OUT_FOR_DELIVERY', '2025-06-27 00:37:46', NULL, '2025-09-29 12:43:30', '2025-01-19 12:02:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (464, 21, 'DELIVERED', '2025-03-01 10:04:33', '2025-09-29 13:41:01', '2025-09-29 12:37:57', '2025-07-01 09:25:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (465, 906, 'ASSIGNED', '2025-05-08 13:24:38', NULL, '2025-09-29 13:18:42', '2025-01-03 06:16:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (466, 214, 'CANCELLED', NULL, NULL, NULL, '2025-08-07 13:14:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (467, 862, 'PENDING', NULL, NULL, NULL, '2025-06-04 19:54:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (468, 689, 'CANCELLED', NULL, NULL, NULL, '2025-07-12 15:36:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (469, 516, 'DELIVERED', '2025-06-14 07:47:34', '2025-09-29 14:06:36', '2025-09-29 12:31:47', '2025-07-16 02:58:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (470, 343, 'DELIVERED', '2025-05-06 03:36:11', '2025-09-29 14:02:14', '2025-09-29 13:14:10', '2025-09-10 12:32:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (471, 231, 'PENDING', NULL, NULL, NULL, '2025-01-23 11:46:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (472, 512, 'DELIVERED', '2025-02-09 12:46:16', '2025-09-29 14:05:10', '2025-09-29 13:16:28', '2025-08-10 19:40:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (473, 68, 'PENDING', NULL, NULL, NULL, '2025-07-14 15:17:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (474, 952, 'PENDING', NULL, NULL, NULL, '2025-02-12 02:00:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (475, 646, 'CANCELLED', NULL, NULL, NULL, '2025-04-20 12:34:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (476, 139, 'PENDING', NULL, NULL, NULL, '2025-05-19 11:11:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (477, 786, 'DELIVERED', '2025-08-19 18:42:45', '2025-09-29 13:23:29', '2025-09-29 12:40:05', '2025-06-24 01:53:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (478, 80, 'PENDING', NULL, NULL, NULL, '2025-04-20 16:41:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (479, 786, 'OUT_FOR_DELIVERY', '2025-09-17 01:24:46', NULL, '2025-09-29 12:51:45', '2025-04-03 15:43:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (480, 62, 'CANCELLED', NULL, NULL, NULL, '2025-05-06 06:37:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (481, 944, 'PENDING', NULL, NULL, NULL, '2025-01-20 03:32:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (482, 86, 'ASSIGNED', '2025-09-01 12:27:14', NULL, '2025-09-29 12:29:11', '2025-06-22 22:01:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (483, 449, 'DELIVERED', '2025-06-06 12:57:00', '2025-09-29 12:57:58', '2025-09-29 13:04:30', '2025-06-14 23:23:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (484, 107, 'ASSIGNED', '2025-09-01 02:55:53', NULL, '2025-09-29 13:20:43', '2025-04-21 05:09:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (485, 884, 'ASSIGNED', '2025-04-26 00:39:46', NULL, '2025-09-29 13:15:59', '2025-05-22 14:13:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (486, 356, 'CANCELLED', NULL, NULL, NULL, '2025-02-23 21:59:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (487, 780, 'PENDING', NULL, NULL, NULL, '2025-03-01 02:57:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (488, 390, 'DELIVERED', '2025-08-16 19:53:53', '2025-09-29 13:33:21', '2025-09-29 12:31:09', '2025-02-26 21:10:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (489, 661, 'ASSIGNED', '2025-06-20 01:56:25', NULL, '2025-09-29 13:14:40', '2025-08-20 17:24:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (490, 67, 'OUT_FOR_DELIVERY', '2025-02-05 01:23:32', NULL, '2025-09-29 13:09:12', '2025-07-06 20:56:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (491, 894, 'PENDING', NULL, NULL, NULL, '2025-08-25 02:07:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (492, 504, 'DELIVERED', '2025-02-01 01:47:12', '2025-09-29 14:13:24', '2025-09-29 12:28:03', '2025-07-07 00:41:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (493, 598, 'DELIVERED', '2025-04-15 21:10:34', '2025-09-29 13:24:29', '2025-09-29 13:25:01', '2025-01-31 09:36:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (494, 300, 'CANCELLED', NULL, NULL, NULL, '2025-03-09 03:39:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (495, 812, 'ASSIGNED', '2025-02-26 15:56:16', NULL, '2025-09-29 13:08:40', '2025-08-10 20:06:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (496, 295, 'PENDING', NULL, NULL, NULL, '2025-03-10 07:02:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (497, 748, 'DELIVERED', '2025-06-19 14:50:43', '2025-09-29 13:10:12', '2025-09-29 13:25:51', '2025-04-10 16:51:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (498, 495, 'ASSIGNED', '2025-08-11 11:13:31', NULL, '2025-09-29 12:30:25', '2025-09-17 13:24:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (499, 860, 'CANCELLED', NULL, NULL, NULL, '2025-03-31 07:35:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (500, 507, 'DELIVERED', '2025-08-13 01:43:12', '2025-09-29 14:04:31', '2025-09-29 12:51:56', '2025-03-14 06:10:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (501, 564, 'OUT_FOR_DELIVERY', '2025-05-08 10:30:15', NULL, '2025-09-29 12:36:06', '2025-09-05 04:28:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (502, 199, 'DELIVERED', '2025-04-22 11:48:18', '2025-09-29 14:25:20', '2025-09-29 12:35:43', '2025-07-06 07:26:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (503, 448, 'ASSIGNED', '2025-07-14 13:45:43', NULL, '2025-09-29 12:49:28', '2025-09-26 10:59:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (504, 546, 'PENDING', NULL, NULL, NULL, '2025-05-20 07:40:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (505, 871, 'ASSIGNED', '2025-05-27 18:15:40', NULL, '2025-09-29 12:30:48', '2025-01-14 15:03:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (506, 945, 'ASSIGNED', '2025-04-16 03:52:45', NULL, '2025-09-29 13:11:34', '2025-07-02 16:24:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (507, 618, 'CANCELLED', NULL, NULL, NULL, '2025-02-19 04:01:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (508, 737, 'DELIVERED', '2025-08-12 11:15:12', '2025-09-29 14:47:48', '2025-09-29 13:20:13', '2025-08-15 12:26:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (509, 804, 'OUT_FOR_DELIVERY', '2025-06-06 10:06:31', NULL, '2025-09-29 12:30:34', '2025-02-14 17:04:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (510, 555, 'OUT_FOR_DELIVERY', '2025-03-27 08:40:24', NULL, '2025-09-29 13:18:25', '2025-06-13 11:48:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (511, 983, 'CANCELLED', NULL, NULL, NULL, '2025-05-03 04:35:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (512, 914, 'PENDING', NULL, NULL, NULL, '2025-01-19 08:30:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (513, 434, 'DELIVERED', '2025-01-22 19:05:00', '2025-09-29 14:30:48', '2025-09-29 12:53:37', '2025-03-06 19:43:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (514, 724, 'OUT_FOR_DELIVERY', '2025-01-20 19:28:21', NULL, '2025-09-29 13:11:23', '2025-09-24 05:19:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (515, 558, 'CANCELLED', NULL, NULL, NULL, '2025-05-21 12:05:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (516, 793, 'CANCELLED', NULL, NULL, NULL, '2025-06-29 08:26:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (517, 830, 'CANCELLED', NULL, NULL, NULL, '2025-07-08 17:56:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (518, 619, 'CANCELLED', NULL, NULL, NULL, '2025-08-29 00:10:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (519, 174, 'OUT_FOR_DELIVERY', '2025-04-04 07:29:02', NULL, '2025-09-29 13:25:55', '2025-03-30 08:07:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (520, 895, 'DELIVERED', '2025-04-18 03:35:58', '2025-09-29 13:57:17', '2025-09-29 12:27:13', '2025-06-16 07:14:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (521, 992, 'CANCELLED', NULL, NULL, NULL, '2025-03-10 00:31:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (522, 92, 'CANCELLED', NULL, NULL, NULL, '2025-06-18 02:24:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (523, 926, 'OUT_FOR_DELIVERY', '2025-04-21 10:47:09', NULL, '2025-09-29 13:05:53', '2025-07-23 10:58:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (524, 978, 'CANCELLED', NULL, NULL, NULL, '2025-03-23 05:46:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (525, 111, 'PENDING', NULL, NULL, NULL, '2025-07-13 15:08:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (526, 72, 'PENDING', NULL, NULL, NULL, '2025-06-01 19:30:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (527, 404, 'DELIVERED', '2025-01-06 10:55:09', '2025-09-29 12:57:33', '2025-09-29 13:07:24', '2025-01-04 12:52:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (528, 252, 'CANCELLED', NULL, NULL, NULL, '2025-02-23 06:06:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (529, 397, 'ASSIGNED', '2025-01-24 17:09:53', NULL, '2025-09-29 12:54:42', '2025-03-21 10:22:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (530, 224, 'ASSIGNED', '2025-04-15 23:00:41', NULL, '2025-09-29 12:38:27', '2025-02-25 21:12:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (531, 1000, 'PENDING', NULL, NULL, NULL, '2025-06-06 04:29:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (532, 717, 'PENDING', NULL, NULL, NULL, '2025-05-24 09:22:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (533, 15, 'PENDING', NULL, NULL, NULL, '2025-04-05 10:25:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (534, 561, 'OUT_FOR_DELIVERY', '2025-03-11 21:39:26', NULL, '2025-09-29 12:55:36', '2025-08-15 02:36:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (535, 481, 'OUT_FOR_DELIVERY', '2025-02-14 13:10:40', NULL, '2025-09-29 12:40:02', '2025-01-01 11:02:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (536, 865, 'CANCELLED', NULL, NULL, NULL, '2025-09-01 22:04:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (537, 780, 'OUT_FOR_DELIVERY', '2025-08-25 07:30:26', NULL, '2025-09-29 12:45:00', '2025-08-03 12:16:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (538, 810, 'OUT_FOR_DELIVERY', '2025-02-22 18:51:50', NULL, '2025-09-29 12:57:55', '2025-07-07 08:36:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (539, 29, 'ASSIGNED', '2025-04-05 01:04:41', NULL, '2025-09-29 12:40:20', '2025-07-15 12:39:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (540, 576, 'ASSIGNED', '2025-07-17 23:33:40', NULL, '2025-09-29 12:30:40', '2025-05-19 13:49:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (541, 218, 'OUT_FOR_DELIVERY', '2025-02-27 11:51:15', NULL, '2025-09-29 12:35:52', '2025-04-05 23:01:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (542, 472, 'CANCELLED', NULL, NULL, NULL, '2025-09-03 11:22:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (543, 575, 'ASSIGNED', '2025-02-05 01:46:52', NULL, '2025-09-29 12:33:08', '2025-05-10 09:18:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (544, 977, 'ASSIGNED', '2025-03-31 13:33:16', NULL, '2025-09-29 12:54:47', '2025-08-31 10:44:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (545, 235, 'ASSIGNED', '2025-05-11 06:19:28', NULL, '2025-09-29 13:19:27', '2025-01-10 01:48:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (546, 562, 'ASSIGNED', '2025-03-15 21:27:43', NULL, '2025-09-29 13:09:01', '2025-09-21 07:35:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (547, 605, 'PENDING', NULL, NULL, NULL, '2025-04-07 16:44:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (548, 632, 'DELIVERED', '2025-07-04 00:57:41', '2025-09-29 13:31:47', '2025-09-29 12:51:53', '2025-08-05 21:01:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (549, 405, 'CANCELLED', NULL, NULL, NULL, '2025-05-20 08:26:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (550, 503, 'OUT_FOR_DELIVERY', '2025-04-25 15:20:59', NULL, '2025-09-29 13:04:32', '2025-07-27 12:34:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (551, 734, 'OUT_FOR_DELIVERY', '2025-01-17 19:28:47', NULL, '2025-09-29 13:23:15', '2025-06-12 05:14:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (552, 785, 'DELIVERED', '2025-08-26 12:22:15', '2025-09-29 14:20:06', '2025-09-29 13:12:50', '2025-04-29 01:06:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (553, 359, 'DELIVERED', '2025-01-18 08:44:01', '2025-09-29 14:14:06', '2025-09-29 13:07:34', '2025-08-09 17:52:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (554, 232, 'ASSIGNED', '2025-05-12 16:31:23', NULL, '2025-09-29 13:00:46', '2025-07-10 02:08:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (555, 470, 'PENDING', NULL, NULL, NULL, '2025-03-28 21:18:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (556, 624, 'ASSIGNED', '2025-09-24 18:11:22', NULL, '2025-09-29 13:08:53', '2025-09-20 18:56:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (557, 677, 'CANCELLED', NULL, NULL, NULL, '2025-05-15 02:54:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (558, 245, 'CANCELLED', NULL, NULL, NULL, '2025-03-11 10:15:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (559, 725, 'CANCELLED', NULL, NULL, NULL, '2025-05-10 21:16:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (560, 629, 'CANCELLED', NULL, NULL, NULL, '2025-04-24 22:50:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (561, 408, 'ASSIGNED', '2025-06-24 17:45:25', NULL, '2025-09-29 13:04:58', '2025-09-28 17:53:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (562, 841, 'ASSIGNED', '2025-06-30 12:55:17', NULL, '2025-09-29 12:53:09', '2025-05-02 19:38:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (563, 655, 'PENDING', NULL, NULL, NULL, '2025-02-06 23:27:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (564, 948, 'CANCELLED', NULL, NULL, NULL, '2025-02-22 11:12:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (565, 328, 'DELIVERED', '2025-02-19 11:10:31', '2025-09-29 14:55:11', '2025-09-29 12:53:02', '2025-08-19 10:24:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (566, 519, 'PENDING', NULL, NULL, NULL, '2025-03-25 20:03:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (567, 175, 'DELIVERED', '2025-04-23 13:46:29', '2025-09-29 13:21:28', '2025-09-29 12:47:13', '2025-04-29 17:14:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (568, 359, 'PENDING', NULL, NULL, NULL, '2025-02-02 16:48:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (569, 373, 'CANCELLED', NULL, NULL, NULL, '2025-04-15 08:50:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (570, 601, 'PENDING', NULL, NULL, NULL, '2025-07-16 08:47:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (571, 557, 'OUT_FOR_DELIVERY', '2025-09-29 01:33:32', NULL, '2025-09-29 12:52:27', '2025-02-01 09:27:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (572, 244, 'PENDING', NULL, NULL, NULL, '2025-08-05 12:26:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (573, 822, 'ASSIGNED', '2025-04-14 22:45:26', NULL, '2025-09-29 13:20:19', '2025-05-19 23:28:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (574, 575, 'ASSIGNED', '2025-09-13 16:51:32', NULL, '2025-09-29 13:11:44', '2025-04-02 01:17:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (575, 592, 'ASSIGNED', '2025-02-01 15:51:46', NULL, '2025-09-29 13:21:54', '2025-04-04 09:40:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (576, 903, 'PENDING', NULL, NULL, NULL, '2025-03-31 00:19:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (577, 151, 'ASSIGNED', '2025-04-04 11:40:21', NULL, '2025-09-29 12:53:35', '2025-04-29 23:20:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (578, 363, 'CANCELLED', NULL, NULL, NULL, '2025-08-13 20:34:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (579, 237, 'CANCELLED', NULL, NULL, NULL, '2025-07-06 07:25:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (580, 559, 'PENDING', NULL, NULL, NULL, '2025-09-12 23:58:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (581, 396, 'ASSIGNED', '2025-06-25 03:36:43', NULL, '2025-09-29 13:10:20', '2025-08-21 11:32:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (582, 983, 'PENDING', NULL, NULL, NULL, '2025-01-09 12:15:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (583, 679, 'OUT_FOR_DELIVERY', '2025-08-21 00:02:06', NULL, '2025-09-29 13:03:47', '2025-05-17 04:05:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (584, 154, 'CANCELLED', NULL, NULL, NULL, '2025-07-29 08:07:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (585, 32, 'DELIVERED', '2025-05-03 15:11:53', '2025-09-29 14:00:41', '2025-09-29 12:43:58', '2025-04-11 02:31:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (586, 910, 'ASSIGNED', '2025-06-08 10:20:03', NULL, '2025-09-29 12:42:02', '2025-04-16 15:29:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (587, 645, 'ASSIGNED', '2025-09-08 15:01:27', NULL, '2025-09-29 12:58:41', '2025-07-23 21:43:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (588, 359, 'OUT_FOR_DELIVERY', '2025-06-05 18:14:40', NULL, '2025-09-29 12:34:31', '2025-07-06 18:45:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (589, 291, 'CANCELLED', NULL, NULL, NULL, '2025-04-06 11:27:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (590, 184, 'CANCELLED', NULL, NULL, NULL, '2025-06-22 19:51:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (591, 861, 'OUT_FOR_DELIVERY', '2025-05-03 15:44:03', NULL, '2025-09-29 13:20:56', '2025-05-09 15:39:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (592, 362, 'PENDING', NULL, NULL, NULL, '2025-06-05 07:44:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (593, 440, 'ASSIGNED', '2025-09-22 05:58:57', NULL, '2025-09-29 12:39:56', '2025-06-17 22:33:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (594, 316, 'DELIVERED', '2025-03-09 00:14:24', '2025-09-29 14:28:32', '2025-09-29 12:58:23', '2025-01-29 17:17:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (595, 903, 'PENDING', NULL, NULL, NULL, '2025-03-01 02:38:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (596, 608, 'DELIVERED', '2025-03-28 09:19:38', '2025-09-29 14:24:13', '2025-09-29 13:10:15', '2025-04-23 07:33:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (597, 667, 'CANCELLED', NULL, NULL, NULL, '2025-09-01 21:48:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (598, 680, 'OUT_FOR_DELIVERY', '2025-06-16 20:05:19', NULL, '2025-09-29 13:21:11', '2025-01-17 04:13:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (599, 312, 'ASSIGNED', '2025-02-08 09:00:33', NULL, '2025-09-29 13:02:02', '2025-06-14 20:32:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (600, 603, 'OUT_FOR_DELIVERY', '2025-02-21 09:42:12', NULL, '2025-09-29 13:14:04', '2025-03-04 01:24:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (601, 449, 'DELIVERED', '2025-02-23 01:13:13', '2025-09-29 14:10:31', '2025-09-29 12:43:42', '2025-04-06 14:02:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (602, 840, 'ASSIGNED', '2025-01-21 09:06:16', NULL, '2025-09-29 13:12:04', '2025-07-26 16:56:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (603, 683, 'CANCELLED', NULL, NULL, NULL, '2025-04-19 03:23:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (604, 555, 'OUT_FOR_DELIVERY', '2025-07-22 19:56:40', NULL, '2025-09-29 12:56:58', '2025-07-28 13:32:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (605, 184, 'OUT_FOR_DELIVERY', '2025-02-02 22:52:17', NULL, '2025-09-29 12:50:29', '2025-06-05 07:11:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (606, 780, 'DELIVERED', '2025-09-21 05:23:30', '2025-09-29 14:40:25', '2025-09-29 13:14:22', '2025-06-15 10:21:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (607, 825, 'CANCELLED', NULL, NULL, NULL, '2025-07-22 23:47:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (608, 165, 'DELIVERED', '2025-07-26 16:10:19', '2025-09-29 14:55:34', '2025-09-29 12:56:07', '2025-03-24 19:08:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (609, 467, 'ASSIGNED', '2025-09-23 12:20:27', NULL, '2025-09-29 12:49:03', '2025-05-03 11:11:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (610, 188, 'CANCELLED', NULL, NULL, NULL, '2025-01-23 17:19:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (611, 962, 'CANCELLED', NULL, NULL, NULL, '2025-04-20 15:38:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (612, 671, 'CANCELLED', NULL, NULL, NULL, '2025-07-27 22:02:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (613, 788, 'OUT_FOR_DELIVERY', '2025-01-03 22:01:10', NULL, '2025-09-29 12:33:08', '2025-04-20 03:30:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (614, 771, 'CANCELLED', NULL, NULL, NULL, '2025-07-22 16:20:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (615, 564, 'ASSIGNED', '2025-04-06 05:01:06', NULL, '2025-09-29 13:07:28', '2025-04-04 08:21:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (616, 359, 'OUT_FOR_DELIVERY', '2025-05-18 01:56:37', NULL, '2025-09-29 12:59:45', '2025-05-20 11:23:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (617, 973, 'OUT_FOR_DELIVERY', '2025-08-06 13:37:50', NULL, '2025-09-29 13:25:09', '2025-06-23 13:09:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (618, 656, 'CANCELLED', NULL, NULL, NULL, '2025-03-23 21:53:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (619, 562, 'PENDING', NULL, NULL, NULL, '2025-09-18 13:29:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (620, 674, 'DELIVERED', '2025-04-04 04:06:58', '2025-09-29 13:06:22', '2025-09-29 12:27:29', '2025-07-31 00:13:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (621, 206, 'PENDING', NULL, NULL, NULL, '2025-02-21 09:39:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (622, 185, 'DELIVERED', '2025-03-29 15:26:57', '2025-09-29 14:04:47', '2025-09-29 12:53:39', '2025-01-02 10:57:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (623, 31, 'ASSIGNED', '2025-01-23 11:40:56', NULL, '2025-09-29 12:41:45', '2025-08-06 05:51:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (624, 569, 'PENDING', NULL, NULL, NULL, '2025-07-26 18:41:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (625, 936, 'ASSIGNED', '2025-02-03 20:25:35', NULL, '2025-09-29 12:51:44', '2025-01-25 04:59:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (626, 864, 'CANCELLED', NULL, NULL, NULL, '2025-09-22 13:43:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (627, 50, 'CANCELLED', NULL, NULL, NULL, '2025-07-20 22:08:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (628, 920, 'DELIVERED', '2025-06-03 04:08:06', '2025-09-29 14:29:11', '2025-09-29 13:15:19', '2025-05-18 02:45:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (629, 647, 'PENDING', NULL, NULL, NULL, '2025-07-18 06:54:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (630, 924, 'ASSIGNED', '2025-03-30 08:42:38', NULL, '2025-09-29 12:57:44', '2025-05-16 14:50:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (631, 941, 'PENDING', NULL, NULL, NULL, '2025-04-15 01:54:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (632, 30, 'OUT_FOR_DELIVERY', '2025-07-18 17:15:56', NULL, '2025-09-29 13:12:01', '2025-08-17 06:00:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (633, 813, 'PENDING', NULL, NULL, NULL, '2025-07-26 23:03:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (634, 615, 'ASSIGNED', '2025-07-15 23:16:47', NULL, '2025-09-29 13:25:44', '2025-05-30 01:07:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (635, 676, 'CANCELLED', NULL, NULL, NULL, '2025-07-27 22:18:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (636, 536, 'PENDING', NULL, NULL, NULL, '2025-07-27 05:24:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (637, 358, 'CANCELLED', NULL, NULL, NULL, '2025-01-11 13:37:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (638, 639, 'DELIVERED', '2025-03-09 21:23:17', '2025-09-29 13:00:01', '2025-09-29 12:31:22', '2025-04-25 03:17:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (639, 55, 'OUT_FOR_DELIVERY', '2025-06-04 18:47:45', NULL, '2025-09-29 13:21:39', '2025-01-30 04:01:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (640, 599, 'PENDING', NULL, NULL, NULL, '2025-07-05 00:31:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (641, 614, 'DELIVERED', '2025-05-07 05:59:32', '2025-09-29 14:51:35', '2025-09-29 12:41:19', '2025-05-29 11:14:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (642, 758, 'DELIVERED', '2025-08-12 15:36:13', '2025-09-29 14:33:17', '2025-09-29 12:50:58', '2025-02-08 17:43:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (643, 547, 'DELIVERED', '2025-07-06 00:46:24', '2025-09-29 13:47:25', '2025-09-29 13:22:32', '2025-07-21 01:58:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (644, 244, 'DELIVERED', '2025-07-05 03:39:38', '2025-09-29 13:34:55', '2025-09-29 12:38:49', '2025-01-21 18:27:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (645, 378, 'OUT_FOR_DELIVERY', '2025-08-26 19:36:05', NULL, '2025-09-29 12:39:20', '2025-09-25 05:52:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (646, 809, 'DELIVERED', '2025-04-28 09:42:01', '2025-09-29 14:42:26', '2025-09-29 13:02:46', '2025-05-21 06:51:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (647, 38, 'PENDING', NULL, NULL, NULL, '2025-07-07 16:36:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (648, 435, 'PENDING', NULL, NULL, NULL, '2025-08-23 20:22:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (649, 771, 'ASSIGNED', '2025-02-13 00:35:00', NULL, '2025-09-29 13:18:46', '2025-05-17 07:33:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (650, 787, 'DELIVERED', '2025-08-08 00:09:41', '2025-09-29 14:55:06', '2025-09-29 12:37:41', '2025-07-03 20:50:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (651, 288, 'CANCELLED', NULL, NULL, NULL, '2025-08-08 03:12:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (652, 120, 'OUT_FOR_DELIVERY', '2025-05-11 20:14:37', NULL, '2025-09-29 12:45:42', '2025-07-20 04:05:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (653, 201, 'CANCELLED', NULL, NULL, NULL, '2025-01-09 11:56:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (654, 124, 'CANCELLED', NULL, NULL, NULL, '2025-04-26 12:39:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (655, 40, 'ASSIGNED', '2025-07-11 23:00:46', NULL, '2025-09-29 12:31:21', '2025-07-02 06:05:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (656, 486, 'OUT_FOR_DELIVERY', '2025-02-25 02:18:46', NULL, '2025-09-29 12:56:27', '2025-05-31 21:32:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (657, 133, 'PENDING', NULL, NULL, NULL, '2025-05-10 00:33:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (658, 494, 'ASSIGNED', '2025-04-24 07:19:07', NULL, '2025-09-29 12:56:48', '2025-04-09 12:38:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (659, 242, 'OUT_FOR_DELIVERY', '2025-01-08 07:36:10', NULL, '2025-09-29 13:11:01', '2025-07-22 17:01:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (660, 203, 'ASSIGNED', '2025-05-05 17:33:36', NULL, '2025-09-29 12:30:25', '2025-06-03 23:19:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (661, 458, 'ASSIGNED', '2025-06-21 15:27:35', NULL, '2025-09-29 13:02:53', '2025-01-15 05:16:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (662, 736, 'DELIVERED', '2025-01-19 09:15:43', '2025-09-29 13:37:16', '2025-09-29 13:16:49', '2025-03-25 14:22:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (663, 640, 'DELIVERED', '2025-05-17 04:51:02', '2025-09-29 13:36:12', '2025-09-29 12:36:27', '2025-01-13 10:58:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (664, 15, 'DELIVERED', '2025-09-14 03:27:32', '2025-09-29 13:31:00', '2025-09-29 13:03:10', '2025-06-01 14:51:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (665, 928, 'CANCELLED', NULL, NULL, NULL, '2025-04-18 21:00:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (666, 649, 'OUT_FOR_DELIVERY', '2025-01-27 00:59:41', NULL, '2025-09-29 12:33:33', '2025-09-14 00:38:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (667, 477, 'DELIVERED', '2025-06-13 15:48:33', '2025-09-29 13:10:08', '2025-09-29 12:51:40', '2025-01-17 21:29:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (668, 684, 'CANCELLED', NULL, NULL, NULL, '2025-08-12 05:06:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (669, 598, 'ASSIGNED', '2025-05-13 16:13:41', NULL, '2025-09-29 12:39:19', '2025-07-05 21:09:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (670, 352, 'CANCELLED', NULL, NULL, NULL, '2025-08-17 17:37:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (671, 77, 'CANCELLED', NULL, NULL, NULL, '2025-08-04 03:03:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (672, 916, 'DELIVERED', '2025-03-20 01:49:54', '2025-09-29 14:19:22', '2025-09-29 12:29:13', '2025-09-26 04:09:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (673, 110, 'CANCELLED', NULL, NULL, NULL, '2025-04-04 09:01:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (674, 545, 'PENDING', NULL, NULL, NULL, '2025-09-18 10:05:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (675, 11, 'OUT_FOR_DELIVERY', '2025-05-12 00:17:12', NULL, '2025-09-29 12:48:14', '2025-06-25 16:46:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (676, 642, 'ASSIGNED', '2025-04-07 06:45:46', NULL, '2025-09-29 13:14:14', '2025-06-09 00:43:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (677, 601, 'DELIVERED', '2025-02-22 19:14:53', '2025-09-29 13:24:35', '2025-09-29 13:19:41', '2025-03-09 17:00:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (678, 678, 'DELIVERED', '2025-03-27 21:18:36', '2025-09-29 14:05:13', '2025-09-29 13:07:38', '2025-03-01 03:38:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (679, 463, 'CANCELLED', NULL, NULL, NULL, '2025-02-25 23:03:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (680, 697, 'ASSIGNED', '2025-03-12 10:32:28', NULL, '2025-09-29 13:00:17', '2025-05-08 10:36:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (681, 837, 'DELIVERED', '2025-08-04 07:01:05', '2025-09-29 14:46:51', '2025-09-29 12:57:27', '2025-01-09 06:37:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (682, 322, 'CANCELLED', NULL, NULL, NULL, '2025-01-04 19:12:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (683, 144, 'CANCELLED', NULL, NULL, NULL, '2025-04-07 13:28:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (684, 637, 'ASSIGNED', '2025-09-03 09:34:28', NULL, '2025-09-29 13:10:51', '2025-09-01 20:31:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (685, 723, 'ASSIGNED', '2025-01-05 02:19:11', NULL, '2025-09-29 12:56:10', '2025-04-20 04:42:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (686, 218, 'CANCELLED', NULL, NULL, NULL, '2025-03-01 16:18:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (687, 466, 'OUT_FOR_DELIVERY', '2025-06-04 03:16:16', NULL, '2025-09-29 12:27:24', '2025-08-11 16:01:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (688, 225, 'ASSIGNED', '2025-04-07 03:56:06', NULL, '2025-09-29 12:28:46', '2025-08-15 07:33:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (689, 476, 'CANCELLED', NULL, NULL, NULL, '2025-06-30 09:23:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (690, 143, 'CANCELLED', NULL, NULL, NULL, '2025-01-14 17:58:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (691, 739, 'CANCELLED', NULL, NULL, NULL, '2025-01-12 13:04:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (692, 864, 'DELIVERED', '2025-07-02 19:18:25', '2025-09-29 13:59:32', '2025-09-29 12:44:19', '2025-06-22 04:46:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (693, 534, 'OUT_FOR_DELIVERY', '2025-05-12 07:34:08', NULL, '2025-09-29 13:01:42', '2025-03-19 15:14:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (694, 511, 'ASSIGNED', '2025-03-14 05:56:53', NULL, '2025-09-29 12:53:24', '2025-08-12 05:39:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (695, 538, 'PENDING', NULL, NULL, NULL, '2025-02-24 12:37:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (696, 863, 'ASSIGNED', '2025-09-04 01:35:33', NULL, '2025-09-29 12:28:25', '2025-01-13 07:40:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (697, 236, 'CANCELLED', NULL, NULL, NULL, '2025-06-21 10:37:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (698, 286, 'ASSIGNED', '2025-02-12 10:42:04', NULL, '2025-09-29 12:28:29', '2025-01-03 17:06:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (699, 105, 'CANCELLED', NULL, NULL, NULL, '2025-03-07 00:59:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (700, 358, 'DELIVERED', '2025-05-22 11:54:33', '2025-09-29 13:56:27', '2025-09-29 13:13:43', '2025-04-25 20:44:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (701, 110, 'OUT_FOR_DELIVERY', '2025-07-14 04:24:56', NULL, '2025-09-29 13:21:07', '2025-02-03 20:43:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (702, 483, 'CANCELLED', NULL, NULL, NULL, '2025-01-06 22:31:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (703, 591, 'ASSIGNED', '2025-07-19 19:26:47', NULL, '2025-09-29 13:06:33', '2025-06-16 11:09:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (704, 996, 'OUT_FOR_DELIVERY', '2025-08-05 12:49:17', NULL, '2025-09-29 12:29:10', '2025-07-08 19:06:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (705, 782, 'OUT_FOR_DELIVERY', '2025-05-31 02:13:44', NULL, '2025-09-29 12:47:20', '2025-07-31 01:30:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (706, 844, 'CANCELLED', NULL, NULL, NULL, '2025-03-21 11:56:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (707, 24, 'PENDING', NULL, NULL, NULL, '2025-06-19 08:46:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (708, 271, 'DELIVERED', '2025-09-04 10:22:37', '2025-09-29 14:27:19', '2025-09-29 13:19:25', '2025-03-08 01:57:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (709, 418, 'CANCELLED', NULL, NULL, NULL, '2025-04-08 17:13:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (710, 356, 'OUT_FOR_DELIVERY', '2025-06-28 02:57:51', NULL, '2025-09-29 12:30:33', '2025-07-27 02:18:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (711, 234, 'ASSIGNED', '2025-09-21 16:18:17', NULL, '2025-09-29 13:25:51', '2025-03-07 19:20:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (712, 345, 'PENDING', NULL, NULL, NULL, '2025-08-31 08:27:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (713, 646, 'ASSIGNED', '2025-06-02 19:08:25', NULL, '2025-09-29 13:03:06', '2025-02-26 07:01:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (714, 954, 'ASSIGNED', '2025-03-23 01:25:14', NULL, '2025-09-29 12:55:24', '2025-03-27 02:59:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (715, 564, 'OUT_FOR_DELIVERY', '2025-02-19 22:46:40', NULL, '2025-09-29 12:55:43', '2025-01-18 07:09:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (716, 397, 'PENDING', NULL, NULL, NULL, '2025-05-16 17:48:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (717, 455, 'CANCELLED', NULL, NULL, NULL, '2025-01-26 18:59:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (718, 559, 'ASSIGNED', '2025-01-15 07:56:38', NULL, '2025-09-29 13:11:27', '2025-01-17 01:23:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (719, 453, 'OUT_FOR_DELIVERY', '2025-08-27 11:02:05', NULL, '2025-09-29 12:37:33', '2025-03-20 11:05:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (720, 379, 'ASSIGNED', '2025-06-26 21:43:14', NULL, '2025-09-29 12:57:59', '2025-04-10 07:46:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (721, 372, 'DELIVERED', '2025-02-17 13:55:06', '2025-09-29 14:34:18', '2025-09-29 12:54:22', '2025-01-16 01:37:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (722, 156, 'ASSIGNED', '2025-08-14 21:57:33', NULL, '2025-09-29 13:25:16', '2025-01-12 17:12:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (723, 230, 'CANCELLED', NULL, NULL, NULL, '2025-03-12 02:09:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (724, 324, 'CANCELLED', NULL, NULL, NULL, '2025-07-07 13:45:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (725, 842, 'PENDING', NULL, NULL, NULL, '2025-07-21 16:41:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (726, 831, 'PENDING', NULL, NULL, NULL, '2025-03-06 14:06:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (727, 386, 'PENDING', NULL, NULL, NULL, '2025-06-15 12:46:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (728, 870, 'ASSIGNED', '2025-04-23 09:14:59', NULL, '2025-09-29 13:26:02', '2025-02-28 22:41:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (729, 459, 'PENDING', NULL, NULL, NULL, '2025-06-17 08:13:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (730, 778, 'PENDING', NULL, NULL, NULL, '2025-03-13 06:44:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (731, 984, 'OUT_FOR_DELIVERY', '2025-05-05 21:18:55', NULL, '2025-09-29 12:59:00', '2025-01-31 15:16:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (732, 507, 'ASSIGNED', '2025-03-29 11:22:03', NULL, '2025-09-29 13:11:11', '2025-08-01 04:40:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (733, 777, 'PENDING', NULL, NULL, NULL, '2025-05-28 20:23:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (734, 820, 'DELIVERED', '2025-09-25 14:58:02', '2025-09-29 14:27:27', '2025-09-29 12:45:56', '2025-09-02 19:45:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (735, 992, 'PENDING', NULL, NULL, NULL, '2025-06-26 05:00:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (736, 556, 'CANCELLED', NULL, NULL, NULL, '2025-03-20 09:20:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (737, 180, 'PENDING', NULL, NULL, NULL, '2025-07-28 19:03:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (738, 848, 'CANCELLED', NULL, NULL, NULL, '2025-04-01 04:35:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (739, 449, 'CANCELLED', NULL, NULL, NULL, '2025-06-22 19:44:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (740, 653, 'DELIVERED', '2025-08-15 00:40:32', '2025-09-29 14:22:47', '2025-09-29 12:30:38', '2025-02-09 04:37:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (741, 415, 'DELIVERED', '2025-03-11 17:52:18', '2025-09-29 13:35:17', '2025-09-29 13:17:34', '2025-03-09 15:38:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (742, 186, 'DELIVERED', '2025-01-09 00:42:03', '2025-09-29 13:05:53', '2025-09-29 13:05:11', '2025-09-06 10:20:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (743, 240, 'OUT_FOR_DELIVERY', '2025-04-28 08:24:26', NULL, '2025-09-29 12:48:44', '2025-06-06 20:21:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (744, 812, 'CANCELLED', NULL, NULL, NULL, '2025-03-13 09:43:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (745, 948, 'DELIVERED', '2025-09-26 00:27:27', '2025-09-29 13:57:53', '2025-09-29 13:21:27', '2025-09-14 21:11:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (746, 189, 'PENDING', NULL, NULL, NULL, '2025-08-09 19:03:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (747, 394, 'PENDING', NULL, NULL, NULL, '2025-07-01 11:56:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (748, 191, 'OUT_FOR_DELIVERY', '2025-04-10 12:48:47', NULL, '2025-09-29 13:04:56', '2025-01-29 14:54:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (749, 778, 'DELIVERED', '2025-04-11 15:14:25', '2025-09-29 14:34:26', '2025-09-29 12:51:15', '2025-08-24 05:21:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (750, 3, 'OUT_FOR_DELIVERY', '2025-02-27 19:17:42', NULL, '2025-09-29 13:25:05', '2025-06-11 15:59:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (751, 992, 'ASSIGNED', '2025-08-20 05:36:32', NULL, '2025-09-29 13:00:35', '2025-04-21 08:07:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (752, 574, 'ASSIGNED', '2025-04-10 15:38:58', NULL, '2025-09-29 12:26:24', '2025-05-01 14:19:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (753, 398, 'CANCELLED', NULL, NULL, NULL, '2025-08-28 00:50:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (754, 439, 'DELIVERED', '2025-01-19 20:44:45', '2025-09-29 13:30:42', '2025-09-29 12:56:05', '2025-05-18 12:52:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (755, 465, 'OUT_FOR_DELIVERY', '2025-04-14 22:22:11', NULL, '2025-09-29 13:22:34', '2025-04-09 06:05:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (756, 617, 'PENDING', NULL, NULL, NULL, '2025-09-19 05:14:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (757, 907, 'DELIVERED', '2025-08-13 16:49:28', '2025-09-29 13:26:26', '2025-09-29 12:33:48', '2025-09-10 10:39:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (758, 54, 'OUT_FOR_DELIVERY', '2025-05-29 17:03:49', NULL, '2025-09-29 13:11:37', '2025-06-16 03:49:02');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (759, 777, 'DELIVERED', '2025-08-13 06:41:21', '2025-09-29 13:31:14', '2025-09-29 13:02:27', '2025-03-07 19:20:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (760, 700, 'OUT_FOR_DELIVERY', '2025-05-02 06:26:46', NULL, '2025-09-29 12:51:58', '2025-01-16 16:04:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (761, 837, 'CANCELLED', NULL, NULL, NULL, '2025-03-12 00:56:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (762, 115, 'ASSIGNED', '2025-09-18 04:34:48', NULL, '2025-09-29 12:42:11', '2025-07-08 14:20:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (763, 110, 'CANCELLED', NULL, NULL, NULL, '2025-03-24 04:01:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (764, 804, 'PENDING', NULL, NULL, NULL, '2025-06-24 01:11:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (765, 464, 'OUT_FOR_DELIVERY', '2025-07-29 16:51:16', NULL, '2025-09-29 13:20:13', '2025-04-13 09:55:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (766, 612, 'CANCELLED', NULL, NULL, NULL, '2025-02-19 10:24:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (767, 755, 'OUT_FOR_DELIVERY', '2025-03-15 12:31:02', NULL, '2025-09-29 12:57:49', '2025-07-03 07:22:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (768, 827, 'CANCELLED', NULL, NULL, NULL, '2025-08-28 06:56:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (769, 319, 'OUT_FOR_DELIVERY', '2025-03-27 17:23:03', NULL, '2025-09-29 13:25:49', '2025-08-24 15:36:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (770, 6, 'ASSIGNED', '2025-05-04 17:35:23', NULL, '2025-09-29 13:25:56', '2025-09-08 15:40:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (771, 277, 'DELIVERED', '2025-04-12 19:21:50', '2025-09-29 13:14:24', '2025-09-29 12:47:35', '2025-05-18 02:14:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (772, 448, 'DELIVERED', '2025-01-10 17:12:29', '2025-09-29 12:57:26', '2025-09-29 12:49:27', '2025-03-14 23:57:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (773, 761, 'DELIVERED', '2025-09-26 05:32:05', '2025-09-29 13:06:21', '2025-09-29 13:00:03', '2025-06-22 03:35:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (774, 347, 'CANCELLED', NULL, NULL, NULL, '2025-03-20 17:44:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (775, 77, 'DELIVERED', '2025-06-12 15:11:45', '2025-09-29 14:55:47', '2025-09-29 13:21:14', '2025-03-02 08:52:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (776, 248, 'DELIVERED', '2025-07-30 03:23:06', '2025-09-29 14:20:10', '2025-09-29 13:09:03', '2025-09-19 12:32:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (777, 104, 'CANCELLED', NULL, NULL, NULL, '2025-09-07 01:47:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (778, 415, 'OUT_FOR_DELIVERY', '2025-01-25 07:14:27', NULL, '2025-09-29 12:59:53', '2025-09-03 04:13:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (779, 119, 'CANCELLED', NULL, NULL, NULL, '2025-05-24 18:53:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (780, 665, 'CANCELLED', NULL, NULL, NULL, '2025-07-05 09:51:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (781, 417, 'DELIVERED', '2025-03-05 22:57:16', '2025-09-29 13:38:11', '2025-09-29 13:14:59', '2025-04-17 18:53:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (782, 145, 'DELIVERED', '2025-05-09 13:00:56', '2025-09-29 13:30:30', '2025-09-29 13:21:14', '2025-07-17 17:56:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (783, 601, 'PENDING', NULL, NULL, NULL, '2025-04-11 03:54:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (784, 767, 'DELIVERED', '2025-07-23 10:24:00', '2025-09-29 13:14:02', '2025-09-29 13:06:25', '2025-06-24 18:42:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (785, 830, 'DELIVERED', '2025-08-15 09:27:32', '2025-09-29 14:41:00', '2025-09-29 12:52:24', '2025-01-03 14:33:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (786, 904, 'ASSIGNED', '2025-06-25 17:50:53', NULL, '2025-09-29 12:56:59', '2025-08-05 03:56:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (787, 591, 'DELIVERED', '2025-07-08 15:27:31', '2025-09-29 13:53:31', '2025-09-29 12:45:09', '2025-09-27 20:44:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (788, 364, 'ASSIGNED', '2025-04-28 21:20:49', NULL, '2025-09-29 12:50:11', '2025-06-07 16:40:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (789, 856, 'CANCELLED', NULL, NULL, NULL, '2025-08-26 15:13:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (790, 384, 'CANCELLED', NULL, NULL, NULL, '2025-07-01 12:50:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (791, 655, 'ASSIGNED', '2025-04-13 00:45:42', NULL, '2025-09-29 13:00:03', '2025-03-14 09:25:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (792, 980, 'CANCELLED', NULL, NULL, NULL, '2025-09-27 21:45:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (793, 597, 'OUT_FOR_DELIVERY', '2025-05-03 13:09:00', NULL, '2025-09-29 13:05:46', '2025-03-22 13:18:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (794, 517, 'DELIVERED', '2025-01-03 06:33:11', '2025-09-29 14:21:44', '2025-09-29 13:14:04', '2025-09-03 10:36:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (795, 379, 'PENDING', NULL, NULL, NULL, '2025-06-04 05:22:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (796, 641, 'ASSIGNED', '2025-08-23 15:38:15', NULL, '2025-09-29 13:06:16', '2025-02-03 20:18:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (797, 83, 'CANCELLED', NULL, NULL, NULL, '2025-07-13 14:31:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (798, 120, 'DELIVERED', '2025-03-16 13:57:17', '2025-09-29 13:55:53', '2025-09-29 12:55:36', '2025-01-07 11:38:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (799, 765, 'CANCELLED', NULL, NULL, NULL, '2025-09-13 17:01:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (800, 562, 'PENDING', NULL, NULL, NULL, '2025-08-04 06:36:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (801, 865, 'PENDING', NULL, NULL, NULL, '2025-03-29 19:46:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (802, 674, 'ASSIGNED', '2025-02-17 13:48:48', NULL, '2025-09-29 12:57:52', '2025-01-19 12:17:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (803, 560, 'PENDING', NULL, NULL, NULL, '2025-03-13 22:16:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (804, 275, 'OUT_FOR_DELIVERY', '2025-04-10 21:12:34', NULL, '2025-09-29 12:56:22', '2025-05-02 18:41:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (805, 250, 'OUT_FOR_DELIVERY', '2025-09-06 18:08:11', NULL, '2025-09-29 13:08:34', '2025-04-14 05:03:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (806, 389, 'DELIVERED', '2025-06-21 03:11:38', '2025-09-29 13:25:24', '2025-09-29 13:09:15', '2025-05-30 03:58:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (807, 219, 'PENDING', NULL, NULL, NULL, '2025-08-20 16:46:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (808, 546, 'DELIVERED', '2025-07-04 04:55:46', '2025-09-29 14:55:13', '2025-09-29 12:43:28', '2025-06-15 21:01:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (809, 134, 'CANCELLED', NULL, NULL, NULL, '2025-04-24 11:04:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (810, 715, 'ASSIGNED', '2025-04-21 01:29:10', NULL, '2025-09-29 13:00:29', '2025-07-25 05:11:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (811, 203, 'CANCELLED', NULL, NULL, NULL, '2025-04-07 07:41:40');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (812, 130, 'ASSIGNED', '2025-09-06 10:09:04', NULL, '2025-09-29 13:21:22', '2025-03-07 16:21:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (813, 444, 'ASSIGNED', '2025-01-05 09:10:50', NULL, '2025-09-29 12:42:10', '2025-04-11 03:55:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (814, 500, 'CANCELLED', NULL, NULL, NULL, '2025-09-02 13:30:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (815, 558, 'PENDING', NULL, NULL, NULL, '2025-07-10 09:39:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (816, 955, 'DELIVERED', '2025-05-23 06:40:47', '2025-09-29 13:24:12', '2025-09-29 13:16:36', '2025-06-11 05:41:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (817, 490, 'DELIVERED', '2025-09-27 15:38:51', '2025-09-29 13:43:48', '2025-09-29 12:33:19', '2025-05-29 01:13:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (818, 9, 'DELIVERED', '2025-08-04 06:43:16', '2025-09-29 13:19:33', '2025-09-29 13:18:49', '2025-05-11 22:53:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (819, 112, 'ASSIGNED', '2025-06-30 13:11:59', NULL, '2025-09-29 12:26:52', '2025-08-18 06:35:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (820, 879, 'DELIVERED', '2025-02-05 06:52:25', '2025-09-29 12:59:42', '2025-09-29 13:12:30', '2025-02-02 05:58:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (821, 35, 'DELIVERED', '2025-06-23 06:57:15', '2025-09-29 12:58:14', '2025-09-29 13:02:06', '2025-05-29 20:28:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (822, 243, 'DELIVERED', '2025-08-20 21:26:51', '2025-09-29 14:53:02', '2025-09-29 12:35:40', '2025-03-26 16:14:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (823, 161, 'ASSIGNED', '2025-01-18 02:07:14', NULL, '2025-09-29 13:24:56', '2025-01-19 09:41:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (824, 714, 'DELIVERED', '2025-05-03 23:12:22', '2025-09-29 14:46:01', '2025-09-29 13:20:43', '2025-07-17 20:17:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (825, 743, 'CANCELLED', NULL, NULL, NULL, '2025-01-13 17:11:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (826, 153, 'ASSIGNED', '2025-06-26 03:07:06', NULL, '2025-09-29 13:17:14', '2025-04-21 08:14:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (827, 246, 'DELIVERED', '2025-01-26 06:08:03', '2025-09-29 14:47:36', '2025-09-29 13:24:17', '2025-09-06 09:34:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (828, 737, 'PENDING', NULL, NULL, NULL, '2025-03-07 22:48:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (829, 740, 'CANCELLED', NULL, NULL, NULL, '2025-06-11 16:36:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (830, 241, 'PENDING', NULL, NULL, NULL, '2025-01-06 20:37:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (831, 642, 'CANCELLED', NULL, NULL, NULL, '2025-05-30 00:26:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (832, 398, 'CANCELLED', NULL, NULL, NULL, '2025-05-28 04:42:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (833, 773, 'DELIVERED', '2025-01-02 05:13:40', '2025-09-29 13:06:38', '2025-09-29 12:42:56', '2025-02-20 09:16:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (834, 529, 'ASSIGNED', '2025-04-20 11:05:46', NULL, '2025-09-29 12:31:04', '2025-09-28 08:38:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (835, 596, 'ASSIGNED', '2025-03-10 23:43:23', NULL, '2025-09-29 12:27:59', '2025-08-13 04:53:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (836, 667, 'CANCELLED', NULL, NULL, NULL, '2025-08-25 13:27:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (837, 438, 'OUT_FOR_DELIVERY', '2025-04-01 21:28:41', NULL, '2025-09-29 13:25:10', '2025-09-05 17:56:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (838, 939, 'DELIVERED', '2025-04-10 05:59:02', '2025-09-29 14:07:51', '2025-09-29 13:15:17', '2025-04-02 03:09:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (839, 551, 'PENDING', NULL, NULL, NULL, '2025-04-01 00:29:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (840, 685, 'DELIVERED', '2025-06-26 16:05:49', '2025-09-29 14:12:11', '2025-09-29 12:39:31', '2025-06-27 03:18:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (841, 508, 'PENDING', NULL, NULL, NULL, '2025-04-05 03:47:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (842, 174, 'CANCELLED', NULL, NULL, NULL, '2025-09-24 02:35:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (843, 158, 'ASSIGNED', '2025-06-24 20:34:33', NULL, '2025-09-29 12:29:54', '2025-06-09 23:04:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (844, 739, 'CANCELLED', NULL, NULL, NULL, '2025-08-14 14:18:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (845, 497, 'DELIVERED', '2025-02-22 15:48:46', '2025-09-29 14:50:15', '2025-09-29 13:25:29', '2025-08-29 11:56:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (846, 624, 'PENDING', NULL, NULL, NULL, '2025-04-26 05:37:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (847, 544, 'CANCELLED', NULL, NULL, NULL, '2025-07-26 23:18:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (848, 620, 'PENDING', NULL, NULL, NULL, '2025-06-13 17:28:50');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (849, 948, 'OUT_FOR_DELIVERY', '2025-04-02 22:57:51', NULL, '2025-09-29 12:33:58', '2025-04-20 10:16:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (850, 989, 'ASSIGNED', '2025-06-21 01:50:20', NULL, '2025-09-29 12:42:55', '2025-07-20 14:33:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (851, 404, 'ASSIGNED', '2025-03-06 04:47:03', NULL, '2025-09-29 13:08:49', '2025-06-20 15:50:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (852, 290, 'OUT_FOR_DELIVERY', '2025-08-14 05:57:35', NULL, '2025-09-29 13:13:49', '2025-09-22 18:52:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (853, 119, 'CANCELLED', NULL, NULL, NULL, '2025-08-04 00:41:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (854, 78, 'ASSIGNED', '2025-03-20 05:25:44', NULL, '2025-09-29 12:27:05', '2025-07-16 19:15:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (855, 17, 'PENDING', NULL, NULL, NULL, '2025-01-12 22:09:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (856, 568, 'PENDING', NULL, NULL, NULL, '2025-05-09 11:18:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (857, 657, 'ASSIGNED', '2025-03-31 03:49:58', NULL, '2025-09-29 12:26:45', '2025-02-18 04:48:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (858, 924, 'DELIVERED', '2025-06-06 03:46:02', '2025-09-29 14:51:18', '2025-09-29 12:57:27', '2025-04-02 16:06:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (859, 590, 'PENDING', NULL, NULL, NULL, '2025-01-24 00:11:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (860, 641, 'ASSIGNED', '2025-03-19 04:59:10', NULL, '2025-09-29 13:24:17', '2025-06-02 05:35:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (861, 315, 'PENDING', NULL, NULL, NULL, '2025-09-13 23:28:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (862, 570, 'DELIVERED', '2025-07-22 04:22:30', '2025-09-29 13:16:39', '2025-09-29 12:45:37', '2025-05-17 09:11:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (863, 137, 'DELIVERED', '2025-07-06 04:49:04', '2025-09-29 14:51:14', '2025-09-29 13:06:21', '2025-04-21 21:57:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (864, 866, 'ASSIGNED', '2025-01-20 22:56:48', NULL, '2025-09-29 13:22:52', '2025-05-06 12:35:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (865, 569, 'ASSIGNED', '2025-09-14 08:38:33', NULL, '2025-09-29 13:11:08', '2025-07-23 03:38:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (866, 193, 'DELIVERED', '2025-08-10 13:31:56', '2025-09-29 14:34:34', '2025-09-29 12:52:29', '2025-03-26 06:01:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (867, 662, 'CANCELLED', NULL, NULL, NULL, '2025-07-08 08:38:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (868, 184, 'OUT_FOR_DELIVERY', '2025-08-02 18:12:11', NULL, '2025-09-29 12:47:27', '2025-04-05 10:46:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (869, 139, 'DELIVERED', '2025-05-02 03:57:55', '2025-09-29 13:07:04', '2025-09-29 12:50:58', '2025-09-08 09:47:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (870, 194, 'CANCELLED', NULL, NULL, NULL, '2025-04-10 12:39:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (871, 166, 'OUT_FOR_DELIVERY', '2025-04-14 09:56:40', NULL, '2025-09-29 13:10:11', '2025-08-31 06:40:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (872, 974, 'PENDING', NULL, NULL, NULL, '2025-04-01 02:57:36');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (873, 778, 'ASSIGNED', '2025-08-25 07:40:04', NULL, '2025-09-29 12:59:43', '2025-04-19 03:28:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (874, 825, 'CANCELLED', NULL, NULL, NULL, '2025-02-16 05:21:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (875, 581, 'OUT_FOR_DELIVERY', '2025-05-12 05:58:31', NULL, '2025-09-29 13:20:42', '2025-01-24 10:53:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (876, 911, 'ASSIGNED', '2025-04-02 12:26:39', NULL, '2025-09-29 12:32:46', '2025-05-27 16:53:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (877, 899, 'DELIVERED', '2025-03-22 06:29:25', '2025-09-29 14:26:14', '2025-09-29 13:06:40', '2025-04-12 14:24:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (878, 254, 'OUT_FOR_DELIVERY', '2025-01-08 17:29:02', NULL, '2025-09-29 12:37:55', '2025-09-22 23:47:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (879, 359, 'DELIVERED', '2025-04-20 01:37:42', '2025-09-29 14:38:47', '2025-09-29 13:24:51', '2025-07-10 10:16:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (880, 281, 'OUT_FOR_DELIVERY', '2025-01-24 06:22:50', NULL, '2025-09-29 12:49:48', '2025-09-16 00:44:20');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (881, 33, 'ASSIGNED', '2025-07-04 15:48:13', NULL, '2025-09-29 13:19:19', '2025-05-07 23:40:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (882, 436, 'OUT_FOR_DELIVERY', '2025-01-12 05:00:44', NULL, '2025-09-29 13:20:09', '2025-07-01 18:50:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (883, 652, 'DELIVERED', '2025-08-26 09:34:50', '2025-09-29 13:31:14', '2025-09-29 12:39:24', '2025-05-07 09:21:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (884, 37, 'PENDING', NULL, NULL, NULL, '2025-01-10 05:07:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (885, 134, 'OUT_FOR_DELIVERY', '2025-01-23 02:01:07', NULL, '2025-09-29 12:55:22', '2025-06-21 19:51:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (886, 484, 'PENDING', NULL, NULL, NULL, '2025-07-12 09:17:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (887, 32, 'DELIVERED', '2025-06-03 18:22:19', '2025-09-29 13:56:49', '2025-09-29 13:06:48', '2025-03-18 17:10:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (888, 341, 'DELIVERED', '2025-03-24 00:12:32', '2025-09-29 13:42:30', '2025-09-29 12:52:18', '2025-03-16 17:44:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (889, 301, 'ASSIGNED', '2025-03-08 00:04:49', NULL, '2025-09-29 13:22:55', '2025-02-04 00:59:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (890, 456, 'ASSIGNED', '2025-08-27 00:18:44', NULL, '2025-09-29 12:49:44', '2025-08-10 14:58:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (891, 151, 'PENDING', NULL, NULL, NULL, '2025-06-14 22:23:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (892, 889, 'CANCELLED', NULL, NULL, NULL, '2025-02-16 00:10:45');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (893, 105, 'DELIVERED', '2025-04-23 23:43:57', '2025-09-29 13:28:43', '2025-09-29 12:40:50', '2025-05-18 08:20:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (894, 83, 'PENDING', NULL, NULL, NULL, '2025-09-27 17:22:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (895, 466, 'CANCELLED', NULL, NULL, NULL, '2025-07-21 12:18:15');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (896, 819, 'ASSIGNED', '2025-08-18 06:51:42', NULL, '2025-09-29 12:30:18', '2025-02-13 06:07:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (897, 907, 'ASSIGNED', '2025-07-22 15:03:19', NULL, '2025-09-29 12:43:00', '2025-01-09 17:44:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (898, 932, 'ASSIGNED', '2025-09-22 03:37:59', NULL, '2025-09-29 13:18:46', '2025-04-28 06:03:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (899, 438, 'PENDING', NULL, NULL, NULL, '2025-03-12 15:47:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (900, 466, 'ASSIGNED', '2025-01-12 01:56:06', NULL, '2025-09-29 12:27:41', '2025-02-04 02:11:24');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (901, 659, 'ASSIGNED', '2025-03-16 03:20:49', NULL, '2025-09-29 12:38:58', '2025-03-14 09:40:29');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (902, 807, 'PENDING', NULL, NULL, NULL, '2025-09-13 22:51:31');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (903, 417, 'DELIVERED', '2025-08-29 03:21:39', '2025-09-29 14:23:20', '2025-09-29 12:35:14', '2025-09-25 15:20:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (904, 782, 'DELIVERED', '2025-08-14 13:20:54', '2025-09-29 13:56:24', '2025-09-29 13:22:25', '2025-02-19 19:44:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (905, 131, 'OUT_FOR_DELIVERY', '2025-07-16 19:39:07', NULL, '2025-09-29 12:34:02', '2025-09-20 22:08:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (906, 319, 'OUT_FOR_DELIVERY', '2025-02-27 23:52:25', NULL, '2025-09-29 12:48:43', '2025-07-03 20:13:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (907, 374, 'PENDING', NULL, NULL, NULL, '2025-08-23 18:45:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (908, 289, 'DELIVERED', '2025-01-04 10:30:55', '2025-09-29 13:21:11', '2025-09-29 12:48:54', '2025-06-29 19:38:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (909, 585, 'CANCELLED', NULL, NULL, NULL, '2025-05-15 13:34:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (910, 166, 'DELIVERED', '2025-01-16 09:48:13', '2025-09-29 13:16:04', '2025-09-29 13:07:09', '2025-02-28 13:52:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (911, 570, 'PENDING', NULL, NULL, NULL, '2025-05-10 05:28:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (912, 925, 'DELIVERED', '2025-08-11 09:28:24', '2025-09-29 13:55:15', '2025-09-29 13:06:39', '2025-03-04 05:59:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (913, 442, 'PENDING', NULL, NULL, NULL, '2025-04-09 21:27:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (914, 841, 'CANCELLED', NULL, NULL, NULL, '2025-09-12 14:00:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (915, 605, 'CANCELLED', NULL, NULL, NULL, '2025-09-05 21:58:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (916, 204, 'CANCELLED', NULL, NULL, NULL, '2025-06-01 10:24:12');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (917, 235, 'DELIVERED', '2025-03-11 15:11:32', '2025-09-29 14:26:02', '2025-09-29 12:37:35', '2025-08-18 19:08:07');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (918, 109, 'ASSIGNED', '2025-05-17 20:05:24', NULL, '2025-09-29 12:58:33', '2025-01-07 07:59:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (919, 868, 'ASSIGNED', '2025-05-24 20:43:44', NULL, '2025-09-29 12:54:25', '2025-07-02 14:35:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (920, 30, 'DELIVERED', '2025-01-08 01:51:07', '2025-09-29 13:17:46', '2025-09-29 13:12:04', '2025-07-13 13:55:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (921, 577, 'ASSIGNED', '2025-03-23 11:37:16', NULL, '2025-09-29 13:05:20', '2025-04-22 21:26:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (922, 220, 'CANCELLED', NULL, NULL, NULL, '2025-04-05 09:28:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (923, 128, 'PENDING', NULL, NULL, NULL, '2025-09-27 08:57:49');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (924, 125, 'OUT_FOR_DELIVERY', '2025-08-23 03:41:54', NULL, '2025-09-29 12:44:52', '2025-02-20 14:53:48');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (925, 889, 'CANCELLED', NULL, NULL, NULL, '2025-07-09 11:56:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (926, 457, 'OUT_FOR_DELIVERY', '2025-06-15 15:56:15', NULL, '2025-09-29 13:04:02', '2025-04-24 18:56:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (927, 109, 'PENDING', NULL, NULL, NULL, '2025-01-22 00:56:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (928, 774, 'PENDING', NULL, NULL, NULL, '2025-08-02 21:12:13');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (929, 131, 'OUT_FOR_DELIVERY', '2025-06-23 06:59:15', NULL, '2025-09-29 12:33:12', '2025-07-09 16:23:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (930, 833, 'OUT_FOR_DELIVERY', '2025-09-14 08:04:02', NULL, '2025-09-29 12:52:57', '2025-09-29 08:34:19');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (931, 188, 'ASSIGNED', '2025-08-21 17:10:34', NULL, '2025-09-29 13:12:06', '2025-05-07 19:16:16');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (932, 754, 'DELIVERED', '2025-03-31 05:10:11', '2025-09-29 14:18:20', '2025-09-29 12:36:11', '2025-07-04 04:18:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (933, 141, 'DELIVERED', '2025-08-30 03:28:44', '2025-09-29 14:12:16', '2025-09-29 13:18:00', '2025-06-12 19:15:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (934, 577, 'OUT_FOR_DELIVERY', '2025-05-16 20:14:40', NULL, '2025-09-29 13:03:21', '2025-05-12 01:32:01');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (935, 821, 'OUT_FOR_DELIVERY', '2025-08-05 12:44:11', NULL, '2025-09-29 12:28:31', '2025-03-10 20:43:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (936, 305, 'PENDING', NULL, NULL, NULL, '2025-02-17 15:40:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (937, 988, 'OUT_FOR_DELIVERY', '2025-04-14 15:25:27', NULL, '2025-09-29 12:57:13', '2025-08-06 17:11:34');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (938, 314, 'DELIVERED', '2025-09-28 04:42:37', '2025-09-29 13:27:22', '2025-09-29 13:00:21', '2025-05-25 14:52:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (939, 833, 'DELIVERED', '2025-01-26 03:58:38', '2025-09-29 14:45:10', '2025-09-29 12:53:41', '2025-02-11 00:18:30');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (940, 210, 'CANCELLED', NULL, NULL, NULL, '2025-03-16 02:05:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (941, 962, 'OUT_FOR_DELIVERY', '2025-07-25 22:12:34', NULL, '2025-09-29 12:36:43', '2025-03-22 22:59:03');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (942, 740, 'DELIVERED', '2025-07-25 18:46:15', '2025-09-29 13:47:20', '2025-09-29 12:45:43', '2025-07-13 06:08:52');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (943, 148, 'ASSIGNED', '2025-03-18 14:12:50', NULL, '2025-09-29 12:56:00', '2025-09-03 15:22:58');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (944, 269, 'OUT_FOR_DELIVERY', '2025-09-12 09:17:45', NULL, '2025-09-29 12:32:36', '2025-02-08 16:31:22');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (945, 828, 'OUT_FOR_DELIVERY', '2025-05-31 07:11:04', NULL, '2025-09-29 13:08:27', '2025-08-17 05:20:51');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (946, 754, 'PENDING', NULL, NULL, NULL, '2025-08-29 02:10:39');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (947, 192, 'OUT_FOR_DELIVERY', '2025-02-03 00:17:59', NULL, '2025-09-29 12:36:57', '2025-08-15 14:53:42');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (948, 488, 'ASSIGNED', '2025-06-14 16:58:04', NULL, '2025-09-29 13:09:38', '2025-08-02 10:54:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (949, 946, 'CANCELLED', NULL, NULL, NULL, '2025-08-02 12:01:54');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (950, 687, 'ASSIGNED', '2025-03-04 02:33:26', NULL, '2025-09-29 12:35:38', '2025-08-25 17:29:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (951, 521, 'DELIVERED', '2025-01-04 05:48:29', '2025-09-29 13:21:06', '2025-09-29 12:31:26', '2025-06-11 14:44:05');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (952, 486, 'PENDING', NULL, NULL, NULL, '2025-05-19 07:28:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (953, 646, 'ASSIGNED', '2025-01-24 11:29:54', NULL, '2025-09-29 13:14:48', '2025-04-27 22:23:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (954, 221, 'OUT_FOR_DELIVERY', '2025-04-25 04:34:05', NULL, '2025-09-29 12:38:26', '2025-07-01 08:10:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (955, 560, 'OUT_FOR_DELIVERY', '2025-08-22 23:56:29', NULL, '2025-09-29 12:27:59', '2025-02-18 19:27:27');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (956, 904, 'OUT_FOR_DELIVERY', '2025-02-25 04:53:55', NULL, '2025-09-29 12:34:08', '2025-04-16 11:53:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (957, 454, 'OUT_FOR_DELIVERY', '2025-04-27 06:05:52', NULL, '2025-09-29 12:43:31', '2025-03-26 22:30:41');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (958, 934, 'PENDING', NULL, NULL, NULL, '2025-08-20 10:53:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (959, 400, 'OUT_FOR_DELIVERY', '2025-01-06 10:28:07', NULL, '2025-09-29 13:00:35', '2025-09-26 16:17:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (960, 899, 'PENDING', NULL, NULL, NULL, '2025-06-04 10:46:25');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (961, 716, 'PENDING', NULL, NULL, NULL, '2025-07-04 00:16:10');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (962, 909, 'CANCELLED', NULL, NULL, NULL, '2025-04-19 17:12:56');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (963, 497, 'OUT_FOR_DELIVERY', '2025-02-23 14:41:29', NULL, '2025-09-29 12:53:16', '2025-08-26 23:25:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (964, 818, 'DELIVERED', '2025-07-13 22:36:20', '2025-09-29 14:29:54', '2025-09-29 12:27:07', '2025-02-07 03:54:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (965, 521, 'CANCELLED', NULL, NULL, NULL, '2025-03-25 18:49:46');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (966, 587, 'DELIVERED', '2025-06-13 06:49:36', '2025-09-29 13:25:50', '2025-09-29 12:55:40', '2025-01-01 23:36:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (967, 930, 'CANCELLED', NULL, NULL, NULL, '2025-09-27 08:19:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (968, 950, 'CANCELLED', NULL, NULL, NULL, '2025-05-07 13:11:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (969, 817, 'ASSIGNED', '2025-02-07 23:54:51', NULL, '2025-09-29 13:17:51', '2025-08-14 00:12:33');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (970, 4, 'DELIVERED', '2025-01-16 12:49:31', '2025-09-29 14:37:38', '2025-09-29 12:58:29', '2025-03-17 14:47:04');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (971, 330, 'PENDING', NULL, NULL, NULL, '2025-02-23 08:16:21');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (972, 955, 'DELIVERED', '2025-01-26 23:22:12', '2025-09-29 13:35:55', '2025-09-29 12:55:03', '2025-04-27 16:02:55');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (973, 634, 'OUT_FOR_DELIVERY', '2025-01-31 22:30:02', NULL, '2025-09-29 13:22:59', '2025-07-24 22:04:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (974, 198, 'DELIVERED', '2025-03-08 09:37:02', '2025-09-29 14:09:35', '2025-09-29 13:12:46', '2025-05-06 04:07:08');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (975, 771, 'ASSIGNED', '2025-07-06 15:32:44', NULL, '2025-09-29 13:09:24', '2025-01-24 11:34:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (976, 548, 'CANCELLED', NULL, NULL, NULL, '2025-09-25 02:31:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (977, 422, 'OUT_FOR_DELIVERY', '2025-06-16 04:30:47', NULL, '2025-09-29 13:01:17', '2025-05-29 06:18:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (978, 70, 'PENDING', NULL, NULL, NULL, '2025-01-25 18:12:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (979, 838, 'PENDING', NULL, NULL, NULL, '2025-05-01 02:11:57');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (980, 137, 'OUT_FOR_DELIVERY', '2025-01-17 05:12:39', NULL, '2025-09-29 12:32:42', '2025-01-27 20:38:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (981, 966, 'PENDING', NULL, NULL, NULL, '2025-07-14 16:20:26');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (982, 812, 'DELIVERED', '2025-07-15 06:32:00', '2025-09-29 13:48:10', '2025-09-29 13:05:58', '2025-04-09 14:13:38');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (983, 129, 'PENDING', NULL, NULL, NULL, '2025-07-05 22:56:47');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (984, 110, 'DELIVERED', '2025-06-02 00:29:25', '2025-09-29 14:06:57', '2025-09-29 13:04:19', '2025-04-28 09:19:28');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (985, 515, 'OUT_FOR_DELIVERY', '2025-02-28 09:52:27', NULL, '2025-09-29 13:24:14', '2025-03-04 20:35:09');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (986, 871, 'DELIVERED', '2025-06-06 12:09:52', '2025-09-29 12:58:23', '2025-09-29 12:50:37', '2025-03-06 19:27:53');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (987, 818, 'ASSIGNED', '2025-07-04 08:12:09', NULL, '2025-09-29 12:47:27', '2025-07-03 05:11:59');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (988, 334, 'PENDING', NULL, NULL, NULL, '2025-08-28 22:54:43');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (989, 357, 'CANCELLED', NULL, NULL, NULL, '2025-06-24 19:59:44');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (990, 750, 'CANCELLED', NULL, NULL, NULL, '2025-06-13 06:48:18');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (991, 573, 'CANCELLED', NULL, NULL, NULL, '2025-03-09 03:06:32');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (992, 766, 'OUT_FOR_DELIVERY', '2025-04-24 18:19:34', NULL, '2025-09-29 12:40:34', '2025-09-05 13:02:37');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (993, 670, 'ASSIGNED', '2025-08-01 23:08:10', NULL, '2025-09-29 13:15:06', '2025-03-21 16:21:14');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (994, 856, 'ASSIGNED', '2025-03-04 16:43:55', NULL, '2025-09-29 13:16:38', '2025-05-19 00:50:11');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (995, 591, 'OUT_FOR_DELIVERY', '2025-09-16 20:46:34', NULL, '2025-09-29 12:32:01', '2025-09-10 07:03:17');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (996, 260, 'DELIVERED', '2025-05-30 15:18:28', '2025-09-29 14:17:39', '2025-09-29 12:49:10', '2025-08-19 08:37:35');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (997, 462, 'ASSIGNED', '2025-03-03 11:05:01', NULL, '2025-09-29 13:26:05', '2025-04-25 23:06:06');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (998, 297, 'ASSIGNED', '2025-07-21 14:18:22', NULL, '2025-09-29 12:50:47', '2025-03-03 13:31:23');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (999, 613, 'ASSIGNED', '2025-03-11 22:26:14', NULL, '2025-09-29 12:39:02', '2025-07-18 20:12:00');
INSERT INTO deliveries 
        (order_id, rider_id, delivery_status, picked_up_at, delivered_at, estimated_delivery_time, created_at)
        VALUES (1000, 716, 'OUT_FOR_DELIVERY', '2025-06-20 21:01:26', NULL, '2025-09-29 13:21:56', '2025-09-09 10:08:23');
