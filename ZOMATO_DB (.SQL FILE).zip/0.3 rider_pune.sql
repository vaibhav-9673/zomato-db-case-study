INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upasna Rout', '2024-01-14', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rohan Rao', '2024-11-23', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Priya Savant', '2023-04-20', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balendra Wable', '2021-05-20', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saksham Khanna', '2023-04-19', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rehaan Ratti', '2022-02-10', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vamakshi Dave', '2023-12-12', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Udyati Bansal', '2021-05-15', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aachal Sekhon', '2021-12-28', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Waida Madan', '2022-05-11', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Chaudhry', '2023-01-26', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lajita Lad', '2023-09-17', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Kala', '2020-07-12', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeet Parmar', '2024-04-30', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Thomas Hora', '2022-01-22', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wazir Morar', '2020-03-28', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rehaan Misra', '2024-06-01', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gayathri Sharma', '2021-12-27', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ikshita Bhandari', '2021-03-17', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Raman', '2025-06-29', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ikshita Rout', '2024-08-16', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wridesh Palla', '2023-07-27', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Indrajit Hora', '2021-11-27', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Alexander Buch', '2024-11-12', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eiravati Cheema', '2022-03-17', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Om Krishnamurthy', '2023-12-20', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chasmum Dave', '2023-12-28', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Unnati Deol', '2023-11-21', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatura Aurora', '2021-08-14', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Idika Sawhney', '2022-01-07', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Laban Bala', '2020-08-14', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harrison Guha', '2021-06-03', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Agastya Bhatia', '2020-06-16', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Watika Rajagopal', '2022-08-20', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeevika Hayer', '2020-07-28', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samesh Sachar', '2022-06-17', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balhaar Zachariah', '2021-01-22', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Prisha Tata', '2022-05-02', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vivaan Sinha', '2020-04-22', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Elijah Kar', '2022-07-07', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upma Kaur', '2022-02-03', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sarthak Bahri', '2025-08-10', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omisha Bhasin', '2023-11-14', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashawini Upadhyay', '2023-04-21', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Maya Sura', '2025-08-27', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Deepa Dua', '2025-04-05', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rayaan Chaudhry', '2024-03-28', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Warhi Rajagopalan', '2021-09-06', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zayan Korpal', '2021-01-17', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vyanjana Dar', '2024-11-30', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Thomas Pillai', '2023-02-14', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Udyati Dixit', '2025-04-21', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sai Solanki', '2025-08-05', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harita Khanna', '2022-12-15', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vedant Butala', '2022-07-29', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aahana Hari', '2022-02-07', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charvi Hayre', '2021-11-01', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saanvi Bail', '2023-02-06', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemal Mani', '2021-09-30', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saksham Dewan', '2020-08-04', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Meghana Atwal', '2024-05-24', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balvan Mitra', '2023-08-28', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekaja Dewan', '2024-12-21', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Libni Bawa', '2022-10-09', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeevika Dass', '2021-06-13', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aishani Sandhu', '2022-12-09', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oscar Guha', '2020-07-18', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanay Sachar', '2024-09-12', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Siya Khalsa', '2023-09-24', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saksham Bains', '2021-05-23', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanveer Jhaveri', '2023-10-30', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemangini Nayar', '2020-12-28', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Devansh Vohra', '2025-09-14', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurangi Mukherjee', '2023-05-09', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jasmit Mani', '2021-02-01', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sanya Raj', '2023-03-05', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rachita Raja', '2020-09-02', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rishi Brahmbhatt', '2023-07-10', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jyoti Kant', '2024-07-05', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Parth Bassi', '2022-11-13', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oni Lad', '2023-04-25', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wyatt Agrawal', '2023-07-11', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gavin Taneja', '2020-05-08', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charles Mutti', '2022-03-29', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemal Venkataraman', '2020-04-04', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samar Lala', '2025-02-14', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janya Khalsa', '2023-11-18', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ryan Oommen', '2023-03-05', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ryan Uppal', '2023-11-03', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mohammed Hayre', '2022-12-21', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ucchal Babu', '2020-08-13', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Akshay Dani', '2023-09-18', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Warinder Saraf', '2025-09-02', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aadhya Pau', '2025-08-07', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vedhika Lata', '2022-10-02', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Azaan Narula', '2022-02-13', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shaurya Pandya', '2024-09-29', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darpan Savant', '2021-01-18', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zaitra Viswanathan', '2025-07-05', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vansha Soni', '2024-11-17', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wriddhish Dave', '2023-01-07', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anvi Deo', '2024-03-24', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaitanya Chad', '2021-04-17', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omya Bhattacharyya', '2024-08-12', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Patrick Gala', '2022-06-13', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hritik Bhatnagar', '2021-02-05', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aryan Brahmbhatt', '2022-11-05', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aachal Raj', '2022-12-05', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oviya Varma', '2021-09-05', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dominic Sahota', '2024-05-20', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abeer Badal', '2021-08-01', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wriddhish Rajan', '2020-04-26', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Finn Din', '2020-05-13', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashvi Natarajan', '2020-04-12', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Om Ben', '2025-07-30', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mahika Krish', '2025-03-16', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dayita Dugar', '2021-02-23', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arjun Desai', '2021-06-09', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jairaj Jha', '2024-06-25', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nandini Gupta', '2025-02-03', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Alka Desai', '2023-11-25', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sai Rajagopal', '2025-02-12', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Baljiwan Sarma', '2021-01-09', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yatin Bawa', '2022-05-28', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anthony Balakrishnan', '2024-11-13', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lopa Din', '2020-05-26', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvi Mistry', '2025-08-04', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urmi Sankar', '2025-07-04', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yoshita Singh', '2025-09-01', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pahal Dalal', '2022-10-25', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anika Garg', '2021-12-22', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Shankar', '2025-05-10', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eiravati Palla', '2023-01-26', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omaja Babu', '2023-01-23', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qasim Sant', '2023-02-09', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Girik Manne', '2021-12-07', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vivaan Bawa', '2020-07-23', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanveer Pall', '2023-03-30', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Udarsh Ravel', '2023-05-13', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omkaar Dyal', '2020-09-24', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Victor Toor', '2020-10-20', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvi Sanghvi', '2024-02-25', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pallavi Sur', '2022-11-26', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tejas Bedi', '2023-11-21', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvi Sinha', '2024-03-02', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yochana Rao', '2020-09-07', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chandani Chanda', '2022-04-08', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abhiram Chandra', '2023-12-04', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Naksh Bajaj', '2021-06-30', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yutika Sekhon', '2025-05-13', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sanya Comar', '2025-09-12', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harrison Sagar', '2022-09-16', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yash Shenoy', '2025-02-04', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekani Naik', '2020-05-05', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amrita Gupta', '2024-07-13', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samar Jhaveri', '2023-03-21', 3.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oliver Sant', '2020-12-20', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pranav Borah', '2021-09-05', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Meera Bora', '2021-08-21', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Januja Karpe', '2022-05-06', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gunbir D’Alia', '2023-01-28', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurangi More', '2024-05-18', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yochana Jhaveri', '2023-07-17', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavna Kar', '2024-06-18', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balendra Nadig', '2020-07-17', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amol Hayer', '2023-05-21', 5.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amol Mukherjee', '2023-06-07', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dhruv Sampath', '2022-07-20', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatura Bava', '2025-03-11', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arunima Dugar', '2022-05-31', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anika Oommen', '2021-10-25', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chavvi Mitra', '2025-05-19', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upma Naidu', '2022-07-12', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yoshita Badal', '2025-09-19', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jagat Brahmbhatt', '2020-03-23', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aditya Singh', '2023-10-10', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sai Mall', '2023-09-24', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Radha Borde', '2022-12-25', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upkaar Kari', '2023-10-31', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sachi Gulati', '2023-03-20', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qarin Balasubramanian', '2020-01-05', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isaiah Iyengar', '2020-08-07', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lajita Kata', '2021-10-07', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zayan Dalal', '2020-10-11', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Farhan Pingle', '2022-03-23', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yamini Rastogi', '2024-10-04', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Krisha Divan', '2024-02-14', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasudha Verma', '2021-01-16', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darpan Tara', '2020-07-07', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janaki Bhatnagar', '2022-01-30', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Laban Ben', '2024-07-28', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Panini Chokshi', '2025-04-23', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chakradev Sunder', '2024-03-27', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Christopher Som', '2020-01-16', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Guneet Kohli', '2025-06-09', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vivaan Chaudhuri', '2024-08-04', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarna Mander', '2025-02-02', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vrishti Madan', '2021-11-18', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Osha Sidhu', '2023-04-14', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Raagini Sood', '2020-12-07', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojasvi Roy', '2023-08-31', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeremiah Oak', '2024-01-20', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eshana Gola', '2020-06-04', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishwar Dalal', '2023-05-09', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Forum Uppal', '2024-02-15', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anvi Bhavsar', '2024-05-07', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arya Barad', '2024-11-02', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanish Vohra', '2023-12-27', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chandresh Agarwal', '2023-01-03', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rushil Devan', '2020-10-14', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavya Buch', '2022-04-14', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Unni Sathe', '2022-08-02', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Quincy Mall', '2021-08-22', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darsh Pant', '2020-12-05', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Brijesh Nagy', '2024-08-15', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saanvi Dhingra', '2024-06-30', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gautami Deshmukh', '2021-12-20', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isaiah Hora', '2023-01-17', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arya Sethi', '2025-01-13', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vincent Rau', '2023-01-07', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavini Mani', '2025-07-27', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kalpit Nair', '2020-12-28', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Daksha Jha', '2025-04-20', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jack Mittal', '2024-08-06', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jatin Khare', '2021-10-15', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lakshmi Raja', '2022-04-02', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nilima Khanna', '2022-02-25', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lopa Dugal', '2023-08-26', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anya Varughese', '2023-11-01', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Idika Talwar', '2025-03-15', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Girish Bakshi', '2020-03-18', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojasvi Parmar', '2020-06-07', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Faras Garg', '2022-02-27', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Majumdar', '2020-11-26', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ayush Sane', '2020-07-06', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ati Ahuja', '2020-02-15', 5.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Turvi Deo', '2023-09-28', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eta Pandya', '2024-07-18', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dakshesh Pandya', '2024-10-07', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kiaan Nadig', '2023-01-08', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Madhavi Wadhwa', '2022-10-14', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vyanjana Wali', '2023-09-17', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wridesh Doshi', '2023-11-26', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vedhika Bhatnagar', '2022-10-04', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kavya Narayan', '2021-09-01', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tamanna Chacko', '2025-09-09', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mahika Chawla', '2021-08-25', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jalsa Patla', '2024-07-01', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saksham Nagarajan', '2020-04-21', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kamala Bora', '2023-04-06', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anjali Mall', '2024-04-30', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Patla', '2023-08-26', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yagnesh Ramakrishnan', '2022-09-04', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanmayi Mall', '2024-03-19', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mason Balakrishnan', '2022-10-14', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Patrick Grewal', '2021-05-19', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gopal Saini', '2020-05-31', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Barkha Saraf', '2021-08-29', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Matthew Pillay', '2022-12-12', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Girik Upadhyay', '2024-11-24', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ridhi Aggarwal', '2025-08-01', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Priya Chandra', '2022-09-14', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Neel Shroff', '2021-10-03', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Xavier Krishnan', '2021-01-29', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manbir Sanghvi', '2024-09-28', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Raghav Singhal', '2023-11-10', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Inaya Gola', '2024-01-16', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chasmum Choudhry', '2025-09-17', 3.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nathan Goda', '2022-11-17', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janya Biswas', '2025-01-30', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anusha Rajan', '2021-01-19', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojas Dani', '2023-07-19', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charan Banerjee', '2024-10-30', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dipta Ramakrishnan', '2020-09-21', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chasmum Thaman', '2021-09-14', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaman Dutt', '2020-03-31', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Kant', '2025-09-21', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Sawhney', '2021-09-19', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eiravati Grewal', '2022-11-14', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oscar Bath', '2023-09-11', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balendra Mallick', '2021-12-12', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jasmit Patil', '2024-12-15', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abha Badami', '2022-04-29', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zehaan Barad', '2025-05-09', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanvi Pingle', '2023-01-05', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nirja Shenoy', '2023-03-28', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Alexander Nadkarni', '2022-10-30', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yamini Saha', '2021-09-08', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anika Prashad', '2025-02-03', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manya Bala', '2023-11-22', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeremiah Seth', '2023-05-07', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Neelima Chowdhury', '2020-07-09', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aadhya Tella', '2020-08-10', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Virk', '2023-02-06', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yadavi Gala', '2020-09-05', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojas Chander', '2024-12-26', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nisha Shukla', '2021-12-10', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ira Cherian', '2020-02-20', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Akshay Cherian', '2025-04-30', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kala Sarin', '2024-03-09', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oscar Dutta', '2024-07-21', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekta Rau', '2022-05-26', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harini Hora', '2025-06-24', 5.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kai Amble', '2024-08-04', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Christopher Atwal', '2020-11-06', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Henry Bhat', '2022-03-24', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abdul Wagle', '2023-07-14', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rajata Kuruvilla', '2021-05-30', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manbir Banerjee', '2020-09-21', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasatika Sankaran', '2024-09-25', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hamsini Loke', '2022-02-21', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ansh Chhabra', '2025-09-27', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Riya Bumb', '2023-10-09', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tejas Nadkarni', '2022-10-23', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upadhriti Bhalla', '2024-07-10', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Caleb Sharaf', '2020-10-28', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ira Acharya', '2023-02-15', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aishani D’Alia', '2022-01-27', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Januja Dass', '2025-03-07', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sanaya Ratta', '2020-11-16', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Finn Agate', '2024-09-28', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Viraj Jain', '2022-05-28', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manya Buch', '2024-03-21', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Atharv Gour', '2020-02-02', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Riya Bora', '2023-10-24', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekaraj Raghavan', '2023-03-12', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Veda Sunder', '2020-02-02', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nirja Chhabra', '2022-12-12', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Radha Agate', '2021-07-17', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Udarsh Kannan', '2022-02-06', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Inaya Bala', '2020-08-30', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasudha Saini', '2022-04-21', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falak Johal', '2024-01-14', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ganga Parmar', '2022-01-17', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kabir Nath', '2023-07-28', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kashish Sarin', '2020-11-16', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sachi Vora', '2025-03-26', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ansh Basak', '2021-12-24', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashoda Natarajan', '2022-01-16', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kiaan Shere', '2020-10-15', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chakradev Cheema', '2025-07-30', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishita Andra', '2022-04-29', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Madhav Shankar', '2022-08-25', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Faras Subramaniam', '2021-07-19', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vinaya Singhal', '2023-06-01', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Brijesh Kurian', '2023-10-31', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Nadkarni', '2020-05-17', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemani Deo', '2025-05-16', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tejas Sharaf', '2024-10-28', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kritika Sanghvi', '2024-09-14', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tara Edwin', '2023-02-01', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zayan Jani', '2020-10-18', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nihal Tella', '2022-05-26', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omaja Guha', '2021-05-19', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vrinda Vaidya', '2023-08-15', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jackson Merchant', '2020-10-25', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vihaan Kara', '2023-08-28', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qushi Venkataraman', '2023-09-30', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zehaan Suri', '2023-06-05', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Naksh Walia', '2025-03-03', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rachita Madan', '2024-12-24', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shaurya Karan', '2025-08-22', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mitesh Mall', '2025-08-15', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qasim Chadha', '2023-10-18', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eiravati Ravel', '2025-05-19', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lakshit Jain', '2021-06-20', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zehaan Kumer', '2022-12-22', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arunima Sankar', '2020-02-27', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nathaniel Patel', '2020-06-06', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aachal Bajaj', '2021-06-16', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Avi Ahluwalia', '2022-01-13', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vritti Mani', '2022-05-10', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Orinder Bahl', '2021-10-11', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shivansh Boase', '2022-12-05', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Adya Sahni', '2022-03-11', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vivaan Reddy', '2020-02-01', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isaac Munshi', '2024-08-22', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Naveen Bali', '2025-09-26', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Varsha Morar', '2020-08-30', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rachit Sawhney', '2022-11-07', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavna Mutti', '2024-12-09', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Siddharth Pall', '2023-04-02', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ikbal Narasimhan', '2022-01-26', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rohan Keer', '2023-08-16', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Oza', '2022-09-05', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yash Gera', '2025-05-28', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gayathri Prabhu', '2023-12-23', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darpan Lanka', '2021-12-06', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anmol Khosla', '2022-02-27', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chakrika Sarna', '2020-10-24', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Banjeet Ahuja', '2024-11-03', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zashil Amble', '2023-10-25', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pavani Warrior', '2024-05-30', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Luke Som', '2022-04-20', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jyoti Varty', '2022-08-18', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeet Seshadri', '2021-03-22', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekani Karnik', '2020-12-06', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ira Mahajan', '2020-01-02', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojasvi Nagi', '2022-04-15', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yuvraj Ravi', '2023-01-02', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Varenya Mody', '2022-08-02', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvi Ratti', '2020-03-03', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeevika Kapadia', '2023-03-03', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Joshua Wadhwa', '2024-11-01', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeet Balakrishnan', '2021-06-13', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nirja Anne', '2022-01-22', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nandini Wadhwa', '2021-07-11', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mekhala Chaudhuri', '2024-06-15', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urmi Krishnan', '2023-09-05', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Veer Kulkarni', '2024-02-23', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Diya Sani', '2021-10-11', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saanvi Edwin', '2023-07-09', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Victor Pathak', '2020-02-22', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yash Pall', '2020-01-16', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jyoti Menon', '2020-09-10', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvashi Sridhar', '2021-11-20', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gautam Dhar', '2023-10-26', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Victor Sodhi', '2020-11-10', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chandani Hari', '2020-01-16', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Diya Sekhon', '2021-06-05', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Inaya Ahluwalia', '2024-07-09', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanveer Arora', '2024-07-13', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ayush Murty', '2023-06-17', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arya Chhabra', '2023-12-27', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abha Pant', '2022-06-01', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ansh Dyal', '2021-10-10', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gunbir Mahal', '2022-09-24', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Garg', '2023-04-24', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rajeshri Shan', '2020-05-01', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aadi Bhasin', '2025-02-01', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eshana Nagarajan', '2023-01-21', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kashvi Salvi', '2024-03-01', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Devika Kapadia', '2021-09-30', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Umang Patla', '2021-07-11', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Robert Bhatti', '2020-07-06', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abha Balakrishnan', '2020-11-06', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Unni Chander', '2023-10-05', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Atharv Bhatia', '2021-03-11', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shravya Sarraf', '2022-04-02', 3.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isha Andra', '2020-07-25', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Atharv Mall', '2023-01-12', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kevin Prakash', '2023-03-09', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Advik Patla', '2024-01-23', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pranit Ganesan', '2025-09-17', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eiravati Nagar', '2022-02-04', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gautami Mahajan', '2024-04-07', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Robert Dara', '2021-03-22', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekani Bhagat', '2021-10-21', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omisha Keer', '2020-10-01', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Damini Oza', '2023-01-07', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dipta Dyal', '2025-03-28', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Megha Gour', '2020-08-05', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arya Shere', '2021-08-03', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Libni Sekhon', '2025-09-16', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eta Prashad', '2021-02-08', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ijaya Bhasin', '2021-05-07', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Edhitha Sane', '2024-04-03', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nakul Kalita', '2022-08-07', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jhalak Sane', '2021-10-26', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('George Mittal', '2022-05-16', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frado Lanka', '2020-01-31', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zayan Pant', '2024-06-30', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashawini Oommen', '2020-04-26', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojas Sawhney', '2021-11-24', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oeshi Nagy', '2020-05-08', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vincent Date', '2022-04-18', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Krishna Sidhu', '2022-03-22', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upkaar Narain', '2020-03-30', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kai Malhotra', '2023-12-01', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekavir Boase', '2023-06-04', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Viraj Ravi', '2021-10-19', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatresh Dua', '2020-12-23', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Umang Tara', '2023-09-08', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shaurya Suri', '2022-06-02', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gagan Narasimhan', '2025-09-02', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Damyanti Oommen', '2020-05-23', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasana Kari', '2020-04-30', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Sane', '2021-01-04', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Laban Seshadri', '2023-10-15', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Khatri', '2021-12-20', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jai Keer', '2023-03-26', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lakshit Shroff', '2024-07-16', 5.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bimala Chauhan', '2021-09-08', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dominic Venkataraman', '2025-07-09', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jacob Kari', '2023-06-21', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omya Kale', '2023-02-03', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Unni Samra', '2024-10-20', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nihal Shah', '2022-01-06', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lajita Gupta', '2021-09-02', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eshana Bhatt', '2024-12-19', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sachi Khalsa', '2023-06-12', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pushti Som', '2022-05-05', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Faraj Goyal', '2024-06-30', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gauri Gole', '2020-12-29', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chanakya Sura', '2024-05-28', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harini Ramesh', '2020-04-05', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manan Borah', '2020-12-29', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bina Koshy', '2022-05-21', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nitara Kapadia', '2023-03-05', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Warrior', '2024-08-03', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Kothari', '2020-09-17', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aishani Mahal', '2021-08-09', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urmi Kale', '2020-08-21', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rushil Rajan', '2022-12-08', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hamsini Bawa', '2024-07-24', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Niharika Ramakrishnan', '2021-05-29', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bakhshi Ratta', '2022-12-08', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Prisha Krishnamurthy', '2023-07-23', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Adweta Saha', '2025-03-28', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yatin Cherian', '2023-02-14', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Turvi Sunder', '2024-04-01', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abeer Shukla', '2022-04-27', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upasna Sanghvi', '2025-08-09', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavani Goel', '2022-08-05', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vanya Parikh', '2022-05-13', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rishi Mitra', '2024-09-03', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Patrick Patla', '2024-04-12', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aryan Sarkar', '2021-05-30', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Daniel Mall', '2020-08-16', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Champak Gola', '2021-06-12', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Naksh Chauhan', '2021-12-14', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Atharv Yadav', '2024-04-27', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Balasubramanian', '2024-01-23', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashawini Bhattacharyya', '2023-04-19', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatura Bhakta', '2023-07-23', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Triveni Edwin', '2023-07-24', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasatika Mangal', '2023-12-05', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mohini Chadha', '2020-06-17', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Widisha Sawhney', '2020-01-25', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bishakha Pal', '2023-01-01', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhanumati Kamdar', '2020-07-20', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekalinga Iyer', '2023-09-10', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Udant Yohannan', '2022-05-09', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ronith Goswami', '2025-08-13', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Girik Divan', '2022-11-17', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Krish Aurora', '2021-12-25', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaitanya Manda', '2024-10-10', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omaja Bhat', '2023-03-11', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qabil Bala', '2024-09-24', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zilmil Sur', '2025-04-23', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darpan Oza', '2025-04-03', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Turvi Sehgal', '2025-04-05', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shivani Srivastava', '2024-07-30', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Krisha Agarwal', '2020-01-17', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Michael Biswas', '2021-06-19', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dakshesh Sood', '2025-04-12', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aashi Mistry', '2023-07-25', 2.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vedant Ramanathan', '2023-01-29', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Riya Konda', '2021-04-18', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lakshit Pathak', '2025-06-12', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavika Narasimhan', '2020-12-06', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekbal Rao', '2024-01-16', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Nanda', '2023-10-06', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekantika Vig', '2020-09-04', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Warinder Chana', '2023-07-20', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lucky Sen', '2021-02-19', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Champak Vasa', '2022-05-01', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nitara Vasa', '2024-10-25', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nakul Johal', '2020-03-22', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sudiksha Biswas', '2023-10-14', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ranveer Sheth', '2024-11-28', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatura Pall', '2025-08-06', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Megha Choudhry', '2023-01-15', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eshana Narang', '2024-11-20', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemangini Dyal', '2021-05-05', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Osha Devi', '2021-08-28', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Agastya Shah', '2021-04-29', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aayush Gera', '2020-03-13', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dayita Merchant', '2020-12-30', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saumya Bajaj', '2022-04-17', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Netra Srivastava', '2024-05-01', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mugdha Sharaf', '2020-08-30', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shivansh Dyal', '2021-01-22', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Forum Ramachandran', '2024-02-25', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Geetika Bera', '2022-10-14', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Fiyaz Kohli', '2021-02-27', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Advay Panchal', '2024-06-22', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Avi Batta', '2023-02-07', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saanvi Rout', '2020-04-15', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anya Gera', '2024-04-03', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvashi Cheema', '2023-10-25', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arin Khanna', '2020-01-23', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oeshi Srivastava', '2025-05-17', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gautami Tank', '2020-03-20', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeevika Pathak', '2025-01-21', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhanumati Divan', '2020-09-22', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ubika Setty', '2023-08-12', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavya Chandra', '2024-02-29', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarnav Chawla', '2025-07-12', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darsh Ramachandran', '2020-02-06', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anmol Pant', '2024-09-06', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anmol Pall', '2022-07-20', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mitali Bera', '2021-01-13', 3.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Osha Agate', '2022-10-11', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mitali Trivedi', '2020-06-08', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abhimanyu Modi', '2021-08-09', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Warjas Lad', '2024-10-13', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rudra Gara', '2025-04-15', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jeevika Arya', '2020-05-01', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvi Brahmbhatt', '2022-05-18', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aradhana Bal', '2020-07-28', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Geetika Agarwal', '2023-07-08', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nitara Bhalla', '2020-06-07', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vyanjana Sami', '2021-12-26', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anjali Sama', '2022-03-13', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wriddhish Venkatesh', '2020-04-04', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Teerth Vora', '2021-06-27', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Maanas Kar', '2022-05-15', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nimrat Kothari', '2025-07-04', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saanvi Iyengar', '2024-08-10', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Thomas Lata', '2025-08-06', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frederick Subramanian', '2023-03-17', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yochana Sani', '2023-06-15', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Ganesan', '2023-12-03', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaitaly Raja', '2023-03-23', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amol Balasubramanian', '2020-05-16', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chasmum Vala', '2020-09-16', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Keya Sule', '2023-06-04', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Mahajan', '2023-09-17', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Baria', '2020-01-02', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Diya Trivedi', '2021-09-11', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekantika Sahota', '2022-11-16', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zinal Biswas', '2020-04-20', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Edhitha Gola', '2023-09-11', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yadavi Chakrabarti', '2022-08-25', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rachana Baria', '2021-09-19', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Brinda Morar', '2020-12-25', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tamanna Bala', '2021-09-24', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavya Sunder', '2023-04-16', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aryan Johal', '2021-02-24', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Kara', '2024-03-29', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vincent Tak', '2020-01-21', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekbal Vaidya', '2022-08-29', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ucchal Hari', '2020-02-24', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gautam Jha', '2022-03-14', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Neelima Sane', '2024-12-18', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Geetika Tella', '2021-09-25', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Patrick Ahuja', '2023-05-19', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarnav Rastogi', '2022-03-24', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yash Manda', '2024-03-01', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yamini Palla', '2020-12-10', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kiaan Korpal', '2023-05-11', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jagvi Yadav', '2022-10-03', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Fiyaz Prabhakar', '2021-08-28', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lila Buch', '2020-07-12', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Varsha Keer', '2024-10-14', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Turvi Mohan', '2022-07-02', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ubika Loyal', '2020-05-01', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Joshua Korpal', '2022-09-28', 1.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Brijesh Kapadia', '2020-03-06', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charvi Kalita', '2022-10-12', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ria Bedi', '2023-01-07', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nidhi Lanka', '2023-11-22', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hamsini Rajagopalan', '2021-03-20', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ryan Vaidya', '2024-12-29', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jairaj Hegde', '2020-11-06', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Varenya Sandhu', '2024-02-01', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lila Palla', '2023-01-27', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Suhani Basak', '2024-10-15', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frado Srinivasan', '2020-06-10', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Dave', '2020-03-06', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojas Kar', '2021-01-16', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zilmil Mane', '2021-10-20', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rajata De', '2021-10-27', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falan Taneja', '2021-03-08', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aditya Kapoor', '2025-09-19', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nisha Kamdar', '2023-10-24', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashodhara Choudhry', '2022-01-29', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samesh Datta', '2023-03-26', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Irya Gaba', '2020-04-25', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hema Saran', '2021-10-21', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zashil Tara', '2020-10-04', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zehaan Krishna', '2025-02-11', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jacob Pall', '2020-08-23', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yutika Chaudry', '2020-10-21', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jason Arya', '2021-11-20', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Riya Bava', '2021-05-25', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatura Magar', '2022-09-17', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tarak Dhar', '2020-04-15', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falak Prashad', '2021-07-09', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mekhala Setty', '2022-10-13', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Madhavi Atwal', '2024-09-02', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavna Raju', '2024-05-22', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mitesh Vasa', '2024-10-21', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Urvashi Walla', '2023-05-10', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Alexander Mittal', '2023-03-22', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavani Om', '2023-10-14', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anthony Date', '2023-06-21', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wahab Chowdhury', '2024-12-04', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upasna Karnik', '2022-11-07', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oeshi Dave', '2022-03-15', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pavani Menon', '2023-08-15', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vihaan Balakrishnan', '2024-05-31', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aryan Kohli', '2020-10-08', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Advika Khalsa', '2023-11-04', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yatin Gera', '2021-01-19', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oni Mane', '2024-02-09', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hiral Nagy', '2023-06-15', 2.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ijaya Shanker', '2020-01-13', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Barkha Rege', '2023-11-24', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekalinga Puri', '2021-10-13', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zehaan Kala', '2020-07-02', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishita Boase', '2021-07-02', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Prashad', '2023-10-09', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ranveer Bansal', '2023-03-19', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ryan Verma', '2024-02-23', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isaac Patel', '2024-02-11', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vaishnavi Zachariah', '2024-03-23', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Prisha Karpe', '2023-12-05', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hiral Kohli', '2022-11-22', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vrinda Prashad', '2023-01-11', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ethan Jhaveri', '2023-10-25', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Praneel Kapur', '2024-06-11', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sathvik Dutt', '2022-06-14', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sanya Ranganathan', '2024-03-11', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Meera Sagar', '2022-09-29', 1.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yagnesh Kalita', '2023-09-10', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bina Badami', '2025-05-25', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekantika Patil', '2025-04-11', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anjali Kuruvilla', '2021-11-04', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anay Varughese', '2023-11-19', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tamanna Saini', '2025-09-15', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manthan Rattan', '2025-04-22', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Avi Patla', '2024-10-22', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Garima Sen', '2020-10-12', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Acharya', '2021-02-13', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kamala Bail', '2022-07-25', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Agastya Hegde', '2022-10-10', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Quincy Handa', '2020-09-29', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Madhav Mall', '2024-01-11', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Liam Char', '2020-04-09', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Bhagat', '2023-08-30', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frederick Doctor', '2023-12-06', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Finn Mandal', '2020-11-25', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ikshita Bhasin', '2022-01-25', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omaja Mishra', '2025-09-04', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarav Gokhale', '2023-11-24', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mekhala Nagy', '2024-05-07', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jagrati Sengupta', '2020-04-21', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harinakshi Mitter', '2024-07-09', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falguni Morar', '2024-02-06', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nandini Tella', '2025-02-18', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Fiyaz Krishnamurthy', '2024-11-06', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chameli Dasgupta', '2020-03-18', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zarna Vyas', '2022-08-07', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Teerth Khurana', '2025-09-03', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jack Dash', '2025-03-30', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wakeeta Bera', '2022-08-21', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charita Iyengar', '2025-02-27', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Logan Purohit', '2025-04-18', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Darsh Virk', '2022-09-01', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sachi Nair', '2020-10-31', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Odika Rajagopal', '2022-06-06', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upasna Dhaliwal', '2025-07-17', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chameli Baral', '2024-10-25', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harshil Thakkar', '2025-03-12', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qabil Solanki', '2021-08-07', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jairaj Badal', '2025-06-11', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chandani Ganguly', '2022-05-22', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Alexander Balay', '2024-10-13', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Fariq Ramanathan', '2023-08-16', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Inaya Chandra', '2023-07-21', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falan Chad', '2024-04-18', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jagrati Chander', '2023-08-19', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charles Chaudhuri', '2025-06-20', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojasvi Bera', '2020-10-16', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Onkar Narula', '2024-03-27', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Eta Devan', '2021-11-16', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jasmit Panchal', '2022-12-02', 3.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lipika Kala', '2021-01-28', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nandini Agarwal', '2024-05-15', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janaki Jayaraman', '2022-04-28', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('David Edwin', '2022-12-30', 4.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dakshesh Savant', '2023-03-30', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemangini Hayer', '2022-08-12', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frederick Vora', '2024-11-19', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yadavi Mane', '2024-02-11', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Irya Date', '2023-07-02', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balvan Thakkar', '2023-04-21', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aashi Sha', '2021-05-27', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charles Dua', '2021-05-04', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Omisha Raja', '2020-11-06', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Isha Ranganathan', '2024-05-15', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Meera Butala', '2022-05-26', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janani Tiwari', '2022-12-28', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Nigam', '2025-05-04', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Advik Babu', '2023-07-26', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemani More', '2024-11-13', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarav Yohannan', '2021-02-22', 1.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Siya Dalal', '2022-01-11', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samar Nath', '2020-10-21', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amaira Nori', '2021-07-18', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Osha Shenoy', '2020-10-23', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Januja Nori', '2024-03-02', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Inaya Kanda', '2021-02-04', 3.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pahal Edwin', '2021-02-04', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charvi Sehgal', '2022-01-31', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Raagini Viswanathan', '2021-04-17', 1.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harini Mallick', '2022-09-02', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Elijah Sridhar', '2025-06-13', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kabir Loke', '2021-07-01', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Simon Basu', '2024-05-21', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Lalla', '2025-02-06', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aashi Bhagat', '2025-02-20', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amol Randhawa', '2021-11-22', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Saksham Ramesh', '2021-05-26', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sai Sarkar', '2025-09-22', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Guneet Kanda', '2021-07-16', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasana Padmanabhan', '2023-01-09', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aadi Sridhar', '2023-04-26', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amruta Munshi', '2021-03-03', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Girindra Saini', '2021-03-05', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Netra Bava', '2021-01-22', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Edhitha Vohra', '2022-01-22', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lucky Nath', '2021-12-21', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rajata Tailor', '2022-07-21', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balendra Toor', '2022-02-26', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tara Nadig', '2022-08-18', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Madhav Gour', '2023-05-04', 4.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bhavini Thakkar', '2024-03-26', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Liam Mittal', '2020-06-04', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nathaniel Prabhakar', '2020-11-19', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arin Barad', '2020-12-13', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ijaya Gupta', '2022-05-22', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Priya Nath', '2024-05-30', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sanaya Bali', '2024-04-21', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Teerth Patel', '2024-04-19', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasatika Varughese', '2021-08-18', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upadhriti Dora', '2020-09-13', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upasna Butala', '2025-05-05', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasana Sura', '2024-03-11', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaaya Setty', '2024-02-03', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aahana Kulkarni', '2020-04-23', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falguni Doctor', '2021-07-12', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harshil Palan', '2022-06-10', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vrinda Kibe', '2023-03-13', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kala Sinha', '2021-10-21', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ganga Bhatt', '2023-04-15', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Luke Padmanabhan', '2021-09-03', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishani Deshpande', '2020-07-03', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Peter Anand', '2023-01-19', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harinakshi Trivedi', '2023-05-16', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Fitan Batra', '2023-02-01', 1.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Om Brahmbhatt', '2022-10-06', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Quincy Sengupta', '2024-03-05', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aashi Mangat', '2023-03-10', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Keya Bumb', '2021-04-11', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hemani Dhingra', '2020-07-13', 5.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasudha Chaudhuri', '2021-09-27', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasana Malhotra', '2023-07-23', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Timothy Varughese', '2023-06-14', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nakul Kapoor', '2023-03-09', 1.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Logan Sachdev', '2025-04-01', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nikita Dhingra', '2021-06-02', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vanya Kaul', '2021-07-21', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Varsha Sharma', '2020-07-17', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kashvi Mann', '2021-08-30', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Caleb Tank', '2023-07-08', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarnav Sem', '2024-11-17', 2.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dalbir Gaba', '2024-11-02', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kamya Atwal', '2024-09-15', 2.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Timothy Handa', '2021-10-22', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harsh Ratti', '2022-09-28', 1.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bachittar Raju', '2022-10-19', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Upadhriti Kala', '2021-05-19', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wriddhish Bajaj', '2020-09-27', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yatan Kothari', '2022-05-10', 2.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jagvi Agate', '2025-09-24', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chaman Mander', '2024-08-14', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charvi Yadav', '2020-12-09', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mekhala Chanda', '2024-08-02', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Sai Batta', '2023-08-25', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pallavi Reddy', '2023-03-24', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anusha Gandhi', '2021-06-24', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanmayi Chandra', '2023-01-02', 4.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Oeshi Dugar', '2020-05-18', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Samaksh Bhatti', '2021-12-18', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Maanas Tailor', '2025-07-24', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dipta Chaudhry', '2023-05-13', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Raagini Balay', '2023-08-21', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arin Baral', '2023-08-20', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarav Taneja', '2023-12-19', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charvi Agate', '2022-07-15', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chatresh Bhalla', '2020-10-30', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojasvi Chauhan', '2020-06-23', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chameli Kala', '2022-07-01', 2.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekansh Swamy', '2022-04-11', 2.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jairaj Halder', '2024-02-02', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gaurang Khurana', '2025-01-03', 4.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ojas Shetty', '2022-11-29', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rishi Gopal', '2021-01-10', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yutika Ramaswamy', '2022-04-10', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Charita Mitter', '2025-07-13', 2.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vedika Ganguly', '2023-02-19', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mohini Brahmbhatt', '2021-04-10', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Kurian', '2023-06-02', 1.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Faras Chauhan', '2024-03-05', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Barkha Bumb', '2021-06-06', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Janya Brar', '2025-09-21', 1.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Imaran Ratti', '2025-09-01', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nisha Narang', '2022-09-04', 4.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Lakshmi Buch', '2025-03-16', 3.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Max Bhardwaj', '2023-07-14', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Triya Chacko', '2022-12-31', 2.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishaan Singh', '2020-06-15', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Zayan Sridhar', '2023-06-02', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ayaan Behl', '2022-10-05', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Januja Hora', '2020-10-12', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tara Mukhopadhyay', '2021-11-30', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arjun Roy', '2023-06-19', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yatan Dugar', '2021-01-17', 3.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Orinder Naidu', '2023-08-01', 4.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Suhani Thakur', '2024-04-27', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekta Sathe', '2021-04-23', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Devika Minhas', '2023-12-01', 1.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Utkarsh Bath', '2024-12-12', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gagan Barad', '2021-10-03', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Logan Dayal', '2025-03-16', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Raagini Oommen', '2023-09-14', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mitesh Tank', '2023-06-13', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Nimrat Varkey', '2022-04-08', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yadavi Bhardwaj', '2024-03-29', 5.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Triya Kade', '2023-08-25', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kamala Swaminathan', '2021-05-31', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Timothy Sule', '2022-04-25', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vasatika Chand', '2024-12-10', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekaja Chander', '2021-11-10', 1.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arjun Goswami', '2021-08-27', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tejas Natarajan', '2024-11-23', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ira Bir', '2025-08-17', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harinakshi Chawla', '2023-01-22', 3.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ijaya Kadakia', '2020-05-08', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Kai Divan', '2020-05-05', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Manbir Shankar', '2022-04-08', 2.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Dayamai Majumdar', '2020-06-27', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Vanya Lanka', '2022-10-05', 3.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Triveni Varghese', '2021-03-21', 4.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Abha Prabhu', '2025-03-11', 1.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anika Atwal', '2021-05-03', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jacob Nath', '2024-07-22', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashvi Bora', '2021-09-13', 1.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ansh Parmar', '2024-10-23', 2.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Daniel Bal', '2021-07-08', 3.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Deepa Gill', '2022-12-11', 4.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Hredhaan Kashyap', '2023-04-09', 4.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chakradhar Choudhary', '2023-01-02', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Imaran Tata', '2022-12-06', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aarnav Goda', '2024-08-04', 2.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Radha Sathe', '2021-09-20', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Laban Wason', '2025-03-06', 3.3, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bakhshi Master', '2020-11-05', 1.0, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ishita Baral', '2021-08-09', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Advika Tak', '2023-09-12', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aahana Krishna', '2020-09-19', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Wishi Kumar', '2020-01-22', 3.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ikshita Raju', '2024-05-30', 2.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Warjas Oommen', '2024-12-20', 3.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bahadurjit Raju', '2022-01-07', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shravya Dhaliwal', '2021-04-14', 4.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Falan Pall', '2024-10-19', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Watika Ratta', '2022-07-01', 1.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Orinder Bhattacharyya', '2020-02-18', 4.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Victor Seth', '2020-02-19', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Krishna Bala', '2020-08-11', 4.5, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aadhya Bhatt', '2023-08-30', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gabriel Setty', '2023-05-05', 3.0, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Chandani Jayaraman', '2022-05-02', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Harrison Rastogi', '2022-11-27', 3.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Frado Shah', '2024-10-05', 2.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ucchal Dave', '2023-08-04', 4.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Caleb Rajagopal', '2024-10-13', 3.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Thomas Pillay', '2022-09-10', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Mohammed Raman', '2025-08-15', 3.4, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Jyoti Gade', '2025-06-24', 4.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ayush Goda', '2020-11-01', 1.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Amara Behl', '2021-08-23', 2.8, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pranit Raghavan', '2022-05-09', 2.5, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shivansh Purohit', '2023-11-29', 3.8, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Tanveer Nayar', '2024-03-10', 4.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qabil Chaudhari', '2021-02-05', 4.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Bahadurjit Naik', '2022-05-29', 1.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Naksh Subramaniam', '2023-12-03', 2.6, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Xiti Mannan', '2022-12-02', 1.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gagan Bhandari', '2023-12-14', 1.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balvan Bera', '2020-10-26', 3.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Ekani Kapur', '2022-09-28', 2.2, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Anya Amble', '2022-01-06', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Pallavi Jayaraman', '2020-02-23', 2.2, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Rishi Dhillon', '2021-01-06', 3.3, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Henry Deo', '2022-06-27', 1.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Reyansh Kurian', '2022-01-25', 3.6, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Balendra Bhargava', '2020-06-03', 4.1, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Arjun Sodhi', '2020-11-04', 4.9, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Leena Mukherjee', '2022-12-17', 2.9, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Gauri Dewan', '2023-01-29', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Aryan Sheth', '2023-10-25', 4.1, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Netra Bhakta', '2020-12-30', 1.7, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Shivansh Pant', '2023-12-27', 3.7, 1);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Qasim Nazareth', '2024-09-01', 4.4, 0);
INSERT INTO riders (RIDER_NAME, SIGN_UP_DATE, RATING, IS_ACTIVE) 
                  VALUES ('Yashawini Chahal', '2025-05-19', 3.9, 0);