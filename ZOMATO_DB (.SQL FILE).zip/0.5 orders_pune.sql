INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (387, 79, '2025-07-06 10:38:50', 'DELIVERED', 1298.58, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (120, 104, '2025-12-10 05:27:45', 'PREPARING', 1307.77, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (943, 423, '2025-10-01 08:08:46', 'READY', 1294.28, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (780, 13, '2025-07-19 22:03:47', 'DELIVERED', 753.95, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (446, 33, '2025-11-04 04:53:39', 'OUT_FOR_DELIVERY', 1778.04, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (139, 700, '2025-12-30 10:13:48', 'OUT_FOR_DELIVERY', 320.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (329, 811, '2025-11-28 02:44:43', 'DELIVERED', 1069.62, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (377, 498, '2025-09-12 01:12:41', 'READY', 184.84, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (427, 364, '2025-12-20 01:41:50', 'PREPARING', 1501.53, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (169, 672, '2025-08-18 14:26:19', 'READY', 844.47, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (259, 417, '2025-05-26 20:35:53', 'PREPARING', 987.02, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (400, 583, '2025-01-05 10:36:29', 'CANCELLED', 296.39, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (466, 385, '2025-05-18 23:36:10', 'CANCELLED', 532.82, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (120, 545, '2025-07-29 08:16:56', 'PREPARING', 1295.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (938, 321, '2025-12-17 02:53:58', 'READY', 122.2, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 212, '2025-12-03 05:59:25', 'DELIVERED', 1292.6, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (155, 806, '2025-08-19 13:06:16', 'CANCELLED', 1586.21, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (905, 158, '2025-06-22 07:05:48', 'OUT_FOR_DELIVERY', 1520.59, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (522, 25, '2025-06-24 04:49:06', 'PLACED', 1225.07, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (164, 792, '2025-06-25 09:32:05', 'DELIVERED', 1042.69, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (432, 267, '2025-11-20 06:41:37', 'READY', 773.98, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (348, 359, '2025-11-01 01:09:40', 'PREPARING', 1626.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (227, 137, '2025-09-20 21:02:34', 'CANCELLED', 1994.44, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (945, 668, '2025-03-02 10:24:46', 'DELIVERED', 1358.3, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (109, 728, '2025-09-04 01:43:50', 'OUT_FOR_DELIVERY', 1598.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (174, 476, '2025-04-10 12:55:39', 'PLACED', 236.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (600, 985, '2025-02-03 23:29:00', 'CANCELLED', 455.87, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (774, 852, '2025-03-02 00:50:59', 'CANCELLED', 728.58, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (498, 763, '2025-01-13 05:08:26', 'CANCELLED', 1229.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (960, 169, '2025-02-25 10:28:05', 'PLACED', 1472.31, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (166, 883, '2025-09-17 22:57:54', 'CANCELLED', 842.06, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (771, 980, '2025-08-21 04:31:34', 'OUT_FOR_DELIVERY', 604.67, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (82, 104, '2025-12-14 09:43:20', 'PREPARING', 319.56, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (895, 161, '2025-06-01 03:05:35', 'OUT_FOR_DELIVERY', 1717.22, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (465, 273, '2025-12-07 06:44:22', 'DELIVERED', 864.81, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (596, 138, '2025-07-16 06:36:33', 'CANCELLED', 1033.19, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (613, 720, '2025-12-05 19:10:43', 'DELIVERED', 239.46, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (523, 19, '2025-10-07 10:38:32', 'OUT_FOR_DELIVERY', 616.14, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (89, 229, '2025-01-16 11:45:01', 'READY', 1694.88, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (993, 248, '2025-02-05 21:13:00', 'PREPARING', 623.12, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (716, 833, '2025-06-02 13:32:37', 'OUT_FOR_DELIVERY', 956.27, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (703, 117, '2025-12-01 03:53:53', 'PREPARING', 1485.82, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (689, 718, '2025-09-01 10:53:52', 'READY', 720.64, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (685, 992, '2025-05-08 19:06:26', 'OUT_FOR_DELIVERY', 586.91, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (218, 601, '2025-03-26 02:50:51', 'READY', 529.91, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (420, 175, '2025-03-28 20:18:00', 'PREPARING', 1966.5, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (635, 281, '2025-03-30 13:53:16', 'PREPARING', 664.74, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (468, 221, '2025-11-23 05:49:36', 'PREPARING', 636.71, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (300, 773, '2025-10-30 10:41:40', 'PREPARING', 763.48, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (358, 252, '2025-10-22 06:34:06', 'PLACED', 1852.61, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (163, 36, '2025-10-31 08:23:09', 'PLACED', 1922.42, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (905, 298, '2025-03-21 08:34:20', 'PLACED', 497.03, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (928, 928, '2025-09-15 19:40:42', 'DELIVERED', 1005.73, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (170, 22, '2025-03-02 04:53:03', 'DELIVERED', 1019.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (236, 327, '2025-10-19 09:35:08', 'OUT_FOR_DELIVERY', 915.35, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (440, 46, '2025-08-07 00:11:12', 'READY', 471.07, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (315, 623, '2025-02-01 13:48:22', 'DELIVERED', 1804.74, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (744, 263, '2025-12-10 04:56:20', 'OUT_FOR_DELIVERY', 435.49, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (475, 805, '2025-08-06 13:05:20', 'READY', 1252.89, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (470, 119, '2025-03-04 06:00:12', 'OUT_FOR_DELIVERY', 363.67, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (943, 564, '2025-05-22 13:21:41', 'DELIVERED', 1289.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (153, 25, '2025-05-13 01:51:14', 'PREPARING', 360.5, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (260, 461, '2025-10-22 01:00:56', 'CANCELLED', 431.62, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (111, 540, '2025-01-07 18:08:17', 'PLACED', 572.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (730, 197, '2025-03-03 23:58:42', 'CANCELLED', 312.79, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (839, 960, '2025-09-05 13:14:36', 'OUT_FOR_DELIVERY', 1775.68, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (357, 506, '2025-07-21 14:51:09', 'DELIVERED', 1366.25, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (75, 229, '2025-01-12 03:39:44', 'PLACED', 1362.53, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (23, 776, '2025-09-25 08:53:17', 'CANCELLED', 1364.87, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (727, 547, '2025-07-31 17:13:59', 'READY', 759.93, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (584, 450, '2025-05-06 15:41:34', 'PREPARING', 1708.51, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (662, 485, '2025-03-27 03:35:58', 'READY', 1030.96, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (589, 566, '2025-02-25 17:14:44', 'PLACED', 1984.57, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (204, 698, '2025-07-17 00:29:35', 'PLACED', 1692.9, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (529, 539, '2025-08-06 02:50:17', 'DELIVERED', 1871.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (725, 617, '2025-10-13 23:20:12', 'PLACED', 961.54, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (190, 363, '2025-11-24 00:42:57', 'PLACED', 1408.49, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (737, 729, '2025-02-23 01:28:11', 'CANCELLED', 368.17, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (132, 19, '2025-07-04 00:02:13', 'PREPARING', 777.79, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (647, 936, '2025-11-07 13:31:21', 'PLACED', 1457.94, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (518, 277, '2025-08-12 03:11:27', 'READY', 1901.09, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (727, 273, '2025-12-20 07:47:20', 'READY', 1692.45, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (187, 562, '2025-08-19 08:06:14', 'PREPARING', 1023.56, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (538, 277, '2025-08-06 17:23:52', 'PLACED', 1641.3, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (532, 167, '2025-11-12 05:20:46', 'DELIVERED', 1398.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (143, 354, '2025-09-22 20:46:48', 'DELIVERED', 802.27, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (424, 220, '2025-02-22 12:28:20', 'READY', 1548.88, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (496, 782, '2025-03-18 18:10:55', 'PLACED', 469.35, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (696, 276, '2025-12-05 23:42:31', 'PLACED', 1422.95, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (104, 886, '2025-01-04 10:07:06', 'OUT_FOR_DELIVERY', 186.55, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (260, 362, '2025-04-08 04:20:07', 'OUT_FOR_DELIVERY', 418.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (494, 708, '2025-11-30 10:06:55', 'PLACED', 1392.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (203, 198, '2025-07-23 13:19:26', 'CANCELLED', 1965.11, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (984, 705, '2025-07-28 05:34:12', 'PREPARING', 1769.38, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (739, 540, '2025-03-07 02:18:55', 'CANCELLED', 1778.92, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (26, 711, '2025-04-30 09:20:50', 'OUT_FOR_DELIVERY', 1270.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (549, 305, '2025-04-25 11:08:37', 'PREPARING', 661.54, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (214, 869, '2025-08-28 11:57:58', 'PLACED', 1443.28, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (36, 73, '2025-03-24 10:45:43', 'READY', 846.37, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (601, 387, '2025-03-07 23:50:35', 'CANCELLED', 410.41, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (935, 97, '2025-08-29 23:20:15', 'PLACED', 466.42, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (701, 807, '2025-06-04 07:42:09', 'PREPARING', 353.91, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (740, 34, '2025-12-30 20:23:47', 'PREPARING', 1798.77, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (543, 954, '2025-12-24 08:37:41', 'READY', 1975.79, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (595, 352, '2025-07-30 17:21:23', 'DELIVERED', 611.19, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (68, 663, '2025-03-17 20:10:39', 'READY', 330.87, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (578, 416, '2025-12-10 22:33:14', 'CANCELLED', 1695.85, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (397, 903, '2025-01-14 10:20:39', 'PLACED', 921.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (559, 1, '2025-11-08 08:50:12', 'PREPARING', 427.47, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (506, 907, '2025-02-13 18:00:19', 'OUT_FOR_DELIVERY', 1311.1, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (243, 329, '2025-01-26 07:34:48', 'PREPARING', 1509.95, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (46, 640, '2025-02-01 14:38:26', 'READY', 1375.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (44, 768, '2025-11-21 12:20:35', 'PLACED', 927.92, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (498, 829, '2025-05-06 20:18:36', 'PREPARING', 259.68, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (255, 901, '2025-02-23 14:26:59', 'DELIVERED', 339.84, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (944, 753, '2025-12-14 04:40:46', 'PREPARING', 1885.09, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (882, 279, '2025-02-24 23:38:52', 'OUT_FOR_DELIVERY', 459.15, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (302, 111, '2025-05-10 17:15:38', 'READY', 508.95, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (278, 78, '2025-05-20 20:57:57', 'READY', 1948.44, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (493, 25, '2025-07-28 05:52:13', 'CANCELLED', 668.96, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (461, 901, '2025-11-28 07:29:47', 'DELIVERED', 1070.42, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (209, 877, '2025-06-17 00:00:44', 'OUT_FOR_DELIVERY', 1440.57, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (32, 621, '2025-08-01 23:14:25', 'DELIVERED', 1955.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (876, 989, '2025-11-16 17:21:17', 'PREPARING', 1062.06, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (646, 588, '2025-10-06 09:28:01', 'PLACED', 1380.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (437, 369, '2025-03-11 06:30:05', 'OUT_FOR_DELIVERY', 115.92, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (361, 809, '2025-02-25 19:53:28', 'READY', 1315.14, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (450, 168, '2025-01-18 15:38:36', 'OUT_FOR_DELIVERY', 1319.28, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (210, 300, '2025-04-14 06:26:52', 'PLACED', 893.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (171, 839, '2025-08-01 18:29:03', 'CANCELLED', 484.14, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (795, 442, '2025-07-03 10:52:15', 'READY', 590.68, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (198, 866, '2025-02-20 00:42:28', 'CANCELLED', 1645.94, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (688, 640, '2025-10-08 08:32:47', 'OUT_FOR_DELIVERY', 878.22, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (31, 265, '2025-01-19 17:23:04', 'OUT_FOR_DELIVERY', 1735.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (259, 610, '2025-04-11 12:47:43', 'DELIVERED', 458.37, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (879, 922, '2025-06-30 10:45:38', 'READY', 419.73, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (732, 797, '2025-04-29 05:29:35', 'CANCELLED', 1413.03, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (579, 952, '2025-02-06 13:55:25', 'PREPARING', 774.34, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (435, 720, '2025-07-03 15:28:58', 'OUT_FOR_DELIVERY', 386.59, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (183, 711, '2025-04-11 00:11:01', 'OUT_FOR_DELIVERY', 1696.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (829, 426, '2025-07-30 02:39:08', 'CANCELLED', 1697.68, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (902, 116, '2025-09-05 19:30:35', 'CANCELLED', 413.66, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (410, 564, '2025-07-30 07:39:39', 'PREPARING', 924.09, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (456, 932, '2025-02-28 11:35:02', 'CANCELLED', 411.29, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (823, 421, '2025-06-17 13:38:00', 'READY', 1087.68, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (9, 707, '2025-06-20 19:03:18', 'PREPARING', 1730.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (457, 532, '2025-05-29 21:45:26', 'OUT_FOR_DELIVERY', 979.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (465, 901, '2025-10-22 19:20:49', 'PREPARING', 1551.83, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (162, 423, '2025-05-06 22:45:58', 'PREPARING', 1047.71, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (6, 383, '2025-02-01 03:51:18', 'PLACED', 976.34, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (106, 290, '2025-10-08 13:37:34', 'OUT_FOR_DELIVERY', 473.17, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (713, 973, '2025-11-28 01:42:50', 'READY', 1219.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (442, 692, '2025-11-04 15:54:02', 'CANCELLED', 1102.08, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (347, 326, '2025-07-19 17:26:08', 'DELIVERED', 369.45, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (146, 86, '2025-07-27 16:06:56', 'CANCELLED', 346.72, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (251, 381, '2025-06-08 03:51:29', 'READY', 1356.19, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (462, 202, '2025-02-20 17:50:47', 'READY', 375.26, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (724, 769, '2025-04-13 17:43:21', 'PREPARING', 761.75, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (125, 65, '2025-03-29 15:19:28', 'DELIVERED', 1986.97, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (582, 819, '2025-01-07 05:03:09', 'PLACED', 1701.86, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (410, 18, '2025-05-09 13:09:27', 'CANCELLED', 136.25, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (570, 713, '2025-10-07 06:46:59', 'CANCELLED', 1368.84, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (833, 288, '2025-06-10 06:58:40', 'OUT_FOR_DELIVERY', 1774.01, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (887, 905, '2025-04-05 03:47:27', 'CANCELLED', 1038.91, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (630, 231, '2025-11-16 03:36:19', 'PLACED', 1600.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (488, 560, '2025-06-03 21:47:29', 'PREPARING', 551.6, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (531, 430, '2025-07-16 23:30:08', 'READY', 1707.56, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (301, 972, '2025-09-06 02:41:52', 'PREPARING', 368.09, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (290, 23, '2025-02-20 09:31:40', 'DELIVERED', 689.34, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (603, 889, '2025-01-21 05:07:54', 'PLACED', 758.24, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (41, 691, '2025-11-28 08:23:10', 'OUT_FOR_DELIVERY', 1396.39, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (358, 705, '2025-04-10 05:04:22', 'PLACED', 1832.92, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (413, 409, '2025-05-15 14:16:23', 'OUT_FOR_DELIVERY', 405.33, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (712, 741, '2025-08-31 02:02:50', 'DELIVERED', 426.56, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (871, 800, '2025-06-10 07:32:14', 'OUT_FOR_DELIVERY', 1774.64, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (247, 551, '2025-06-14 10:25:13', 'PLACED', 973.78, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (111, 881, '2025-07-30 20:43:15', 'PLACED', 1721.45, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (740, 750, '2025-03-03 06:09:53', 'READY', 1758.21, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (243, 684, '2025-10-10 02:01:33', 'PLACED', 495.59, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (271, 549, '2025-07-06 01:05:30', 'DELIVERED', 1395.0, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (878, 204, '2025-05-27 07:06:24', 'DELIVERED', 563.2, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (434, 57, '2025-05-01 02:39:26', 'CANCELLED', 600.21, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (15, 39, '2025-12-22 16:53:56', 'PLACED', 537.24, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (422, 847, '2025-01-29 03:41:31', 'READY', 1979.13, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (820, 581, '2025-11-25 15:02:05', 'DELIVERED', 617.01, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (551, 57, '2025-11-12 13:46:44', 'PLACED', 1520.49, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (589, 480, '2025-09-10 19:43:54', 'READY', 273.97, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (609, 165, '2025-12-07 03:09:57', 'PREPARING', 975.04, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (794, 398, '2025-12-06 10:39:56', 'PREPARING', 1407.0, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (177, 57, '2025-08-24 03:11:41', 'DELIVERED', 170.75, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (618, 567, '2025-04-24 16:21:21', 'PREPARING', 1451.36, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (53, 79, '2025-06-05 17:59:35', 'PLACED', 1315.9, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (648, 322, '2025-02-13 21:13:14', 'DELIVERED', 528.62, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (680, 435, '2025-11-08 15:31:35', 'PLACED', 288.89, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (639, 92, '2025-12-11 23:51:43', 'PREPARING', 963.2, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (747, 336, '2025-10-27 18:50:04', 'OUT_FOR_DELIVERY', 1800.41, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (485, 767, '2025-06-12 16:24:51', 'READY', 137.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (792, 24, '2025-06-01 05:15:32', 'PREPARING', 437.99, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (25, 773, '2025-01-16 21:06:27', 'PLACED', 755.18, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (507, 598, '2025-03-12 12:26:15', 'PREPARING', 1420.68, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (907, 224, '2025-04-08 13:55:34', 'DELIVERED', 387.17, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (332, 526, '2025-03-04 07:47:05', 'READY', 661.81, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (547, 620, '2025-04-15 15:17:57', 'OUT_FOR_DELIVERY', 1922.66, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (252, 302, '2025-03-02 04:28:02', 'DELIVERED', 131.08, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (220, 319, '2025-01-26 16:55:33', 'CANCELLED', 721.01, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (186, 929, '2025-12-15 06:30:53', 'CANCELLED', 1061.49, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (368, 451, '2025-09-07 04:13:04', 'DELIVERED', 1211.43, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (447, 980, '2025-01-14 04:01:47', 'PREPARING', 1659.82, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (432, 324, '2025-03-05 12:52:49', 'DELIVERED', 1307.81, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (459, 117, '2025-07-01 17:18:12', 'READY', 733.28, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (262, 658, '2025-09-09 13:50:21', 'OUT_FOR_DELIVERY', 715.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (941, 105, '2025-07-11 22:29:19', 'PREPARING', 804.47, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (770, 339, '2025-11-18 09:05:39', 'DELIVERED', 193.31, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (758, 199, '2025-09-24 14:58:10', 'PREPARING', 1488.06, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (639, 695, '2025-12-21 04:31:44', 'READY', 783.18, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (871, 356, '2025-10-26 19:58:51', 'PREPARING', 319.24, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (948, 19, '2025-07-03 00:23:11', 'OUT_FOR_DELIVERY', 1501.48, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (894, 723, '2025-07-18 16:49:47', 'PLACED', 1164.01, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (104, 45, '2025-12-12 17:17:56', 'READY', 1852.77, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (680, 695, '2025-02-25 00:55:38', 'OUT_FOR_DELIVERY', 1867.73, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (10, 128, '2025-06-10 21:40:25', 'PLACED', 717.18, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (152, 353, '2025-10-15 18:30:49', 'PREPARING', 273.33, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (191, 184, '2025-02-07 05:21:42', 'READY', 249.61, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (423, 803, '2025-06-14 17:08:10', 'PLACED', 1066.62, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (398, 995, '2025-04-25 00:55:35', 'PREPARING', 1690.4, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (516, 875, '2025-10-06 10:04:54', 'READY', 418.93, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (49, 964, '2025-02-27 20:48:10', 'CANCELLED', 1924.97, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 344, '2025-02-07 20:23:34', 'PLACED', 1910.74, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (219, 783, '2025-07-03 10:42:25', 'PLACED', 455.16, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (954, 596, '2025-11-08 22:10:32', 'CANCELLED', 1820.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (349, 370, '2025-02-13 15:58:12', 'PREPARING', 927.76, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (562, 377, '2025-06-11 07:58:53', 'PREPARING', 1284.92, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (578, 848, '2025-10-25 13:17:11', 'CANCELLED', 670.84, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (313, 942, '2025-01-07 21:47:11', 'READY', 1288.32, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (313, 768, '2025-02-18 05:49:59', 'OUT_FOR_DELIVERY', 1344.74, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (34, 26, '2025-01-18 06:19:23', 'CANCELLED', 1406.08, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (365, 283, '2025-03-01 12:09:32', 'READY', 1666.93, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (616, 808, '2025-07-23 12:42:08', 'CANCELLED', 585.92, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (609, 821, '2025-06-18 14:00:20', 'READY', 256.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (425, 498, '2025-03-19 05:56:46', 'OUT_FOR_DELIVERY', 1517.58, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (182, 490, '2025-01-23 10:38:40', 'CANCELLED', 691.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (822, 445, '2025-09-27 18:11:17', 'CANCELLED', 901.07, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (610, 450, '2025-05-20 13:06:22', 'DELIVERED', 1978.41, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (100, 674, '2025-05-21 16:38:01', 'OUT_FOR_DELIVERY', 875.8, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (808, 515, '2025-10-26 04:09:18', 'PREPARING', 272.24, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (944, 580, '2025-10-17 22:20:14', 'CANCELLED', 1692.3, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (771, 337, '2025-09-12 04:04:48', 'PLACED', 1114.25, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (650, 994, '2025-03-29 03:02:44', 'READY', 1606.74, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (63, 609, '2025-01-27 11:49:27', 'CANCELLED', 468.66, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (386, 40, '2025-04-11 17:47:09', 'OUT_FOR_DELIVERY', 1606.33, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (447, 878, '2025-04-20 04:38:57', 'CANCELLED', 1177.97, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (652, 423, '2025-05-23 20:47:14', 'PLACED', 1014.58, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (203, 115, '2025-11-26 11:28:37', 'OUT_FOR_DELIVERY', 113.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (798, 980, '2025-08-02 22:29:18', 'DELIVERED', 1205.96, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (851, 51, '2025-04-04 09:50:19', 'CANCELLED', 494.98, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (346, 292, '2025-04-30 07:42:57', 'CANCELLED', 517.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (558, 51, '2025-11-21 03:14:43', 'PREPARING', 181.48, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (585, 918, '2025-02-08 21:21:16', 'READY', 678.38, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (406, 916, '2025-04-03 03:24:28', 'CANCELLED', 1087.43, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (140, 155, '2025-03-22 00:39:37', 'PREPARING', 816.38, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (332, 960, '2025-02-11 21:09:18', 'DELIVERED', 1929.47, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (172, 95, '2025-03-27 11:50:23', 'CANCELLED', 955.98, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (35, 659, '2025-12-18 06:17:17', 'PREPARING', 1349.48, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (970, 245, '2025-11-29 22:52:58', 'PLACED', 633.42, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (328, 110, '2025-01-13 19:25:49', 'PLACED', 339.54, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (840, 955, '2025-03-02 17:53:37', 'PREPARING', 1811.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (962, 526, '2025-04-23 00:49:08', 'READY', 1125.71, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (216, 972, '2025-05-29 17:35:58', 'CANCELLED', 317.78, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (919, 122, '2025-08-05 13:01:27', 'CANCELLED', 1466.52, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (937, 986, '2025-03-26 18:26:58', 'READY', 1706.04, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (845, 865, '2025-05-20 19:22:40', 'READY', 1640.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (500, 415, '2025-10-22 20:15:49', 'PLACED', 615.93, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (357, 646, '2025-04-27 08:33:59', 'OUT_FOR_DELIVERY', 218.48, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (913, 920, '2025-09-21 03:32:09', 'PLACED', 1830.94, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (990, 561, '2025-04-11 00:29:00', 'CANCELLED', 594.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (918, 416, '2025-09-04 11:41:16', 'OUT_FOR_DELIVERY', 1597.12, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (610, 936, '2025-07-08 20:32:19', 'READY', 1658.83, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (864, 695, '2025-11-04 15:20:17', 'OUT_FOR_DELIVERY', 1163.52, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (803, 811, '2025-03-24 13:36:28', 'PLACED', 1077.26, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (798, 145, '2025-10-14 14:17:38', 'CANCELLED', 539.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (308, 124, '2025-09-18 18:52:35', 'DELIVERED', 1800.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (203, 789, '2025-06-14 23:53:22', 'CANCELLED', 1263.99, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (303, 394, '2025-03-15 21:20:13', 'READY', 902.19, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (706, 761, '2025-06-17 15:24:34', 'PLACED', 1996.02, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (40, 548, '2025-05-29 14:20:57', 'PLACED', 1609.2, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (108, 192, '2025-11-17 17:08:04', 'OUT_FOR_DELIVERY', 684.3, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (755, 413, '2025-01-21 02:30:49', 'PREPARING', 1219.15, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (610, 355, '2025-06-28 21:56:02', 'CANCELLED', 1754.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (799, 688, '2025-12-30 04:47:32', 'OUT_FOR_DELIVERY', 1994.96, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (119, 123, '2025-04-02 10:33:18', 'PREPARING', 1523.09, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (467, 998, '2025-12-25 07:17:38', 'READY', 1358.67, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (230, 958, '2025-04-15 14:15:25', 'PREPARING', 970.66, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (904, 327, '2025-10-11 23:11:32', 'PLACED', 1835.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (577, 977, '2025-02-16 03:02:18', 'DELIVERED', 519.74, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (46, 815, '2025-08-19 16:23:01', 'PREPARING', 1542.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (906, 333, '2025-07-25 15:13:48', 'PLACED', 1199.69, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (716, 615, '2025-11-24 14:38:14', 'READY', 1689.35, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (240, 595, '2025-01-17 00:39:07', 'CANCELLED', 1589.69, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (764, 62, '2025-04-08 03:28:47', 'READY', 541.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (988, 210, '2025-06-17 22:15:48', 'PLACED', 105.92, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (73, 304, '2025-11-09 12:19:19', 'READY', 1152.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (375, 701, '2025-08-13 06:20:23', 'PLACED', 1966.06, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (20, 691, '2025-01-04 22:26:19', 'READY', 1161.94, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (201, 364, '2025-03-12 02:22:32', 'READY', 579.88, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (854, 377, '2025-09-13 12:57:38', 'PLACED', 904.95, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (484, 854, '2025-10-31 05:50:36', 'PLACED', 1641.95, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (791, 511, '2025-06-04 00:37:27', 'PREPARING', 1319.34, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (408, 165, '2025-05-18 18:59:38', 'OUT_FOR_DELIVERY', 711.76, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (621, 905, '2025-09-09 01:12:51', 'CANCELLED', 742.27, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (479, 490, '2025-10-18 02:55:56', 'DELIVERED', 1058.84, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (794, 891, '2025-04-16 23:24:40', 'CANCELLED', 547.15, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (89, 98, '2025-09-19 22:21:05', 'PLACED', 1867.44, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (273, 974, '2025-01-09 17:54:03', 'PLACED', 1261.5, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (12, 854, '2025-11-03 04:12:00', 'PLACED', 1933.29, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (386, 186, '2025-12-16 07:08:33', 'OUT_FOR_DELIVERY', 1314.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (798, 574, '2025-03-09 19:14:19', 'READY', 183.08, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (184, 550, '2025-12-27 01:13:56', 'PLACED', 880.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (46, 683, '2025-08-22 00:02:08', 'PREPARING', 1924.34, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (441, 230, '2025-05-06 08:02:16', 'OUT_FOR_DELIVERY', 1532.29, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (148, 864, '2025-04-13 23:06:01', 'PREPARING', 420.52, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (178, 750, '2025-04-03 04:56:09', 'PLACED', 1695.0, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (749, 163, '2025-07-21 09:29:25', 'READY', 536.9, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (320, 741, '2025-09-22 06:24:23', 'PREPARING', 796.6, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (681, 238, '2025-04-21 14:17:11', 'PREPARING', 333.9, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (306, 153, '2025-08-30 10:48:09', 'DELIVERED', 1660.88, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (884, 866, '2025-11-18 21:12:29', 'OUT_FOR_DELIVERY', 1893.99, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (149, 627, '2025-06-30 12:53:56', 'PLACED', 1617.2, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (223, 1000, '2025-01-22 13:21:09', 'PLACED', 1243.64, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (672, 457, '2025-06-20 22:58:49', 'READY', 1674.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (323, 302, '2025-09-13 05:57:18', 'DELIVERED', 1370.65, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (751, 424, '2025-09-06 09:53:38', 'OUT_FOR_DELIVERY', 1994.07, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (193, 964, '2025-05-13 10:44:29', 'READY', 934.99, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (873, 493, '2025-09-29 13:35:51', 'OUT_FOR_DELIVERY', 279.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (819, 367, '2025-11-25 00:51:35', 'READY', 1984.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (823, 198, '2025-04-16 13:15:26', 'PLACED', 1717.78, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (315, 342, '2025-08-31 08:36:16', 'OUT_FOR_DELIVERY', 1909.73, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (153, 810, '2025-04-09 22:38:34', 'OUT_FOR_DELIVERY', 1623.55, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (522, 11, '2025-03-26 17:19:35', 'OUT_FOR_DELIVERY', 471.91, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (368, 354, '2025-12-26 02:54:38', 'PREPARING', 1856.7, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (644, 889, '2025-03-04 16:54:00', 'OUT_FOR_DELIVERY', 1112.84, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (172, 675, '2025-03-11 18:49:52', 'OUT_FOR_DELIVERY', 1282.8, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (894, 551, '2025-09-18 12:52:08', 'CANCELLED', 848.47, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (734, 974, '2025-01-18 10:31:32', 'OUT_FOR_DELIVERY', 1643.93, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (510, 358, '2025-03-15 08:58:30', 'PREPARING', 714.41, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (399, 822, '2025-09-08 17:17:33', 'OUT_FOR_DELIVERY', 1687.88, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (673, 78, '2025-12-05 05:30:13', 'DELIVERED', 658.83, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (633, 865, '2025-04-02 14:03:47', 'DELIVERED', 1421.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (910, 922, '2025-12-04 18:59:25', 'CANCELLED', 1920.82, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (703, 174, '2025-12-30 20:22:11', 'CANCELLED', 267.33, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (195, 95, '2025-07-12 22:43:07', 'READY', 621.15, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (64, 72, '2025-11-06 09:55:50', 'PREPARING', 1562.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (644, 918, '2025-02-17 21:52:51', 'OUT_FOR_DELIVERY', 1630.28, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (370, 973, '2025-10-26 05:20:49', 'READY', 1159.85, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (884, 827, '2025-10-04 00:43:19', 'PLACED', 682.15, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (827, 801, '2025-01-27 16:57:17', 'PREPARING', 1880.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (689, 843, '2025-06-19 12:05:49', 'READY', 1292.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (490, 372, '2025-01-17 23:11:17', 'CANCELLED', 786.94, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (290, 429, '2025-06-15 02:56:54', 'DELIVERED', 126.42, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (130, 87, '2025-08-15 08:52:15', 'OUT_FOR_DELIVERY', 1593.77, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (501, 941, '2025-07-16 10:05:27', 'PLACED', 1396.1, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (275, 905, '2025-12-28 18:34:20', 'READY', 204.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (354, 856, '2025-09-08 11:56:49', 'PLACED', 1960.45, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (476, 528, '2025-02-06 22:11:59', 'OUT_FOR_DELIVERY', 463.87, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 435, '2025-01-09 18:58:40', 'PREPARING', 818.19, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (843, 74, '2025-06-17 07:54:08', 'DELIVERED', 1885.62, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (276, 470, '2025-01-14 08:27:26', 'PLACED', 310.09, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (633, 713, '2025-05-23 00:47:31', 'OUT_FOR_DELIVERY', 452.34, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (414, 852, '2025-12-25 04:34:25', 'CANCELLED', 941.53, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (968, 580, '2025-04-26 13:07:55', 'PREPARING', 1292.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (258, 670, '2025-11-25 03:56:36', 'PLACED', 183.41, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (89, 714, '2025-04-17 06:54:48', 'READY', 1514.48, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (491, 708, '2025-12-25 22:54:11', 'OUT_FOR_DELIVERY', 623.79, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (490, 973, '2025-12-09 10:41:37', 'READY', 1790.39, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (223, 366, '2025-03-14 16:53:54', 'READY', 1826.92, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (882, 375, '2025-11-20 08:47:01', 'PLACED', 495.09, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (700, 149, '2025-08-13 01:20:29', 'PREPARING', 410.87, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (906, 845, '2025-11-23 06:45:55', 'READY', 577.81, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (737, 600, '2025-07-04 15:16:57', 'OUT_FOR_DELIVERY', 1606.15, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (580, 190, '2025-01-08 02:56:53', 'CANCELLED', 295.63, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (822, 540, '2025-03-10 02:38:48', 'OUT_FOR_DELIVERY', 1508.58, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (323, 217, '2025-03-22 18:53:05', 'READY', 1734.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (959, 9, '2025-07-15 09:19:49', 'READY', 1103.18, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (193, 773, '2025-11-21 00:28:32', 'PLACED', 1248.91, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (933, 445, '2025-03-11 01:01:35', 'PREPARING', 397.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (815, 439, '2025-12-21 18:45:26', 'READY', 1898.8, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (595, 448, '2025-06-06 21:54:02', 'READY', 374.22, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (513, 304, '2025-04-30 01:55:24', 'DELIVERED', 1836.32, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (147, 455, '2025-07-04 07:48:53', 'CANCELLED', 1214.42, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (877, 317, '2025-06-22 08:06:39', 'OUT_FOR_DELIVERY', 1275.95, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (957, 186, '2025-07-23 19:40:01', 'CANCELLED', 949.66, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (260, 426, '2025-04-02 01:18:57', 'OUT_FOR_DELIVERY', 444.8, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (677, 951, '2025-02-06 15:05:42', 'PREPARING', 1056.97, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (364, 186, '2025-11-30 03:52:06', 'READY', 1289.88, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (753, 101, '2025-10-27 18:25:10', 'READY', 1380.71, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (306, 644, '2025-05-24 07:18:43', 'READY', 586.2, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (543, 30, '2025-04-06 00:48:11', 'OUT_FOR_DELIVERY', 1663.78, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (613, 834, '2025-05-29 22:27:57', 'PREPARING', 1118.64, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (866, 504, '2025-02-21 14:41:59', 'CANCELLED', 1430.33, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (149, 77, '2025-09-29 05:13:28', 'CANCELLED', 111.31, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (971, 188, '2025-11-02 07:43:14', 'PLACED', 1971.47, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (940, 40, '2025-10-25 13:40:38', 'OUT_FOR_DELIVERY', 1022.96, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (209, 214, '2025-07-29 03:43:18', 'DELIVERED', 796.0, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (38, 366, '2025-06-23 12:06:15', 'CANCELLED', 742.97, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (755, 765, '2025-10-12 14:16:57', 'PREPARING', 186.41, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (903, 90, '2025-10-13 09:08:31', 'CANCELLED', 770.44, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 641, '2025-09-28 21:07:45', 'DELIVERED', 1963.5, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (204, 666, '2025-12-30 21:32:21', 'PLACED', 355.42, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (206, 486, '2025-01-24 07:25:11', 'CANCELLED', 616.25, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (694, 788, '2025-02-11 19:46:55', 'PREPARING', 107.68, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (858, 603, '2025-10-03 19:42:23', 'DELIVERED', 1053.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (972, 635, '2025-07-29 17:58:10', 'OUT_FOR_DELIVERY', 933.54, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (512, 607, '2025-08-28 02:09:12', 'OUT_FOR_DELIVERY', 892.91, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (369, 179, '2025-05-01 19:37:55', 'PLACED', 1527.96, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (781, 388, '2025-05-08 18:22:10', 'OUT_FOR_DELIVERY', 1715.88, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (378, 567, '2025-06-15 02:39:03', 'PREPARING', 602.26, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (573, 526, '2025-11-22 17:00:00', 'DELIVERED', 1093.0, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (438, 143, '2025-04-12 21:50:34', 'OUT_FOR_DELIVERY', 1103.46, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (243, 484, '2025-04-11 12:44:16', 'DELIVERED', 832.54, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (940, 473, '2025-08-31 15:17:50', 'PLACED', 786.26, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (379, 855, '2025-05-09 16:41:06', 'PREPARING', 152.78, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (721, 77, '2025-10-05 10:39:28', 'READY', 1628.7, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (526, 285, '2025-08-30 21:49:39', 'PLACED', 1695.68, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (548, 131, '2025-12-29 03:47:41', 'DELIVERED', 1289.62, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (133, 328, '2025-02-28 20:46:52', 'PREPARING', 723.74, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (350, 222, '2025-03-07 12:00:02', 'DELIVERED', 1547.65, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (782, 927, '2025-12-29 18:39:03', 'DELIVERED', 930.91, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (453, 766, '2025-02-25 12:31:26', 'PLACED', 1296.64, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (199, 434, '2025-05-10 05:02:36', 'OUT_FOR_DELIVERY', 1911.91, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (49, 907, '2025-05-20 00:09:59', 'PREPARING', 586.26, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (821, 747, '2025-11-22 01:47:06', 'PREPARING', 564.03, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (42, 875, '2025-10-01 02:55:03', 'PLACED', 1267.29, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (596, 737, '2025-11-19 09:07:29', 'PLACED', 1940.25, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (951, 894, '2025-04-06 09:13:02', 'DELIVERED', 1639.6, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (842, 790, '2025-11-06 18:17:15', 'OUT_FOR_DELIVERY', 752.28, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (661, 546, '2025-07-22 15:43:17', 'OUT_FOR_DELIVERY', 1516.67, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (566, 483, '2025-02-22 06:52:53', 'OUT_FOR_DELIVERY', 1125.07, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (201, 175, '2025-01-22 11:08:10', 'PREPARING', 1591.44, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (222, 482, '2025-01-03 21:35:09', 'PLACED', 1786.11, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (240, 386, '2025-01-16 19:20:42', 'DELIVERED', 1418.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (615, 855, '2025-12-12 03:46:38', 'OUT_FOR_DELIVERY', 1676.15, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 423, '2025-06-30 06:23:52', 'DELIVERED', 813.11, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (732, 708, '2025-06-05 01:34:16', 'READY', 1703.94, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (89, 63, '2025-06-06 03:59:14', 'DELIVERED', 1369.7, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (728, 853, '2025-01-21 13:11:43', 'PREPARING', 1492.46, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (604, 109, '2025-05-14 21:07:33', 'DELIVERED', 1657.1, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (527, 757, '2025-03-19 02:24:29', 'DELIVERED', 826.64, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (873, 723, '2025-04-24 00:24:46', 'DELIVERED', 569.57, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (608, 484, '2025-10-21 16:38:23', 'PLACED', 619.93, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (984, 231, '2025-06-20 17:11:23', 'READY', 378.86, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (31, 71, '2025-01-07 16:32:59', 'DELIVERED', 1556.86, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (17, 461, '2025-07-07 16:52:38', 'CANCELLED', 1436.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (223, 425, '2025-01-22 00:19:55', 'PLACED', 1428.98, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (163, 800, '2025-01-12 06:04:08', 'PLACED', 765.23, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (171, 546, '2025-06-11 23:50:54', 'DELIVERED', 1837.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (316, 414, '2025-01-23 18:41:54', 'CANCELLED', 1450.17, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (232, 999, '2025-09-15 19:24:01', 'PREPARING', 1539.04, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (883, 64, '2025-02-27 08:32:50', 'READY', 1048.04, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (392, 925, '2025-06-27 10:48:36', 'CANCELLED', 1035.38, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (283, 172, '2025-05-29 19:55:22', 'DELIVERED', 612.48, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (949, 453, '2025-04-21 23:20:22', 'READY', 1384.1, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (127, 760, '2025-03-25 15:35:48', 'OUT_FOR_DELIVERY', 264.3, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (5, 415, '2025-10-06 09:45:35', 'DELIVERED', 695.11, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (307, 513, '2025-04-16 06:21:23', 'DELIVERED', 1079.22, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (796, 764, '2025-08-11 20:04:04', 'CANCELLED', 995.86, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (829, 326, '2025-06-05 06:32:23', 'DELIVERED', 431.5, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (626, 246, '2025-09-08 13:32:49', 'OUT_FOR_DELIVERY', 894.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (448, 182, '2025-09-04 17:31:38', 'CANCELLED', 508.46, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (580, 707, '2025-01-21 21:05:26', 'READY', 1546.87, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (515, 756, '2025-06-19 23:45:34', 'CANCELLED', 1800.23, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (519, 83, '2025-07-31 03:02:29', 'OUT_FOR_DELIVERY', 1543.03, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (119, 777, '2025-04-11 20:35:26', 'PREPARING', 523.77, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (571, 877, '2025-09-20 18:41:41', 'PREPARING', 716.39, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (140, 978, '2025-03-25 12:26:36', 'OUT_FOR_DELIVERY', 1169.26, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (211, 955, '2025-02-11 11:26:56', 'OUT_FOR_DELIVERY', 1729.98, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (9, 250, '2025-10-23 04:13:46', 'READY', 564.96, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (381, 62, '2025-02-05 05:25:21', 'PREPARING', 1773.84, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (738, 60, '2025-01-29 04:06:00', 'CANCELLED', 1606.43, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (682, 812, '2025-03-13 03:22:46', 'PLACED', 340.13, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (135, 69, '2025-05-12 01:08:37', 'OUT_FOR_DELIVERY', 404.08, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (530, 169, '2025-07-04 18:03:31', 'DELIVERED', 1234.57, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (561, 748, '2025-08-16 07:20:33', 'PREPARING', 115.81, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (322, 108, '2025-01-05 18:02:46', 'PLACED', 890.76, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (928, 642, '2025-12-31 05:12:44', 'OUT_FOR_DELIVERY', 1746.48, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (691, 982, '2025-03-26 23:00:17', 'PREPARING', 1106.13, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (622, 632, '2025-02-02 11:18:03', 'PREPARING', 429.08, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (164, 556, '2025-01-06 10:41:15', 'PLACED', 763.81, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (938, 619, '2025-10-26 22:30:27', 'CANCELLED', 1247.7, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (696, 767, '2025-06-20 12:17:05', 'READY', 810.9, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (28, 693, '2025-08-10 01:19:52', 'OUT_FOR_DELIVERY', 239.67, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (768, 879, '2025-08-18 07:37:13', 'DELIVERED', 368.76, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (16, 542, '2025-05-20 06:38:33', 'PLACED', 289.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (354, 806, '2025-04-07 21:52:28', 'OUT_FOR_DELIVERY', 1637.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (981, 367, '2025-01-19 13:07:37', 'READY', 1248.32, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (315, 564, '2025-02-03 14:17:37', 'OUT_FOR_DELIVERY', 1582.17, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (339, 76, '2025-11-29 12:54:05', 'DELIVERED', 1901.21, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (98, 108, '2025-03-10 00:52:07', 'CANCELLED', 848.11, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (160, 841, '2025-08-27 08:33:06', 'DELIVERED', 203.98, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (626, 928, '2025-09-19 06:21:17', 'CANCELLED', 1771.21, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (201, 71, '2025-12-11 18:56:56', 'PREPARING', 309.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (887, 720, '2025-01-23 02:17:56', 'CANCELLED', 540.33, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (421, 230, '2025-04-12 15:50:44', 'PREPARING', 1045.41, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (748, 391, '2025-07-23 18:56:51', 'DELIVERED', 1794.7, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (62, 96, '2025-02-11 17:20:16', 'OUT_FOR_DELIVERY', 1807.27, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (65, 773, '2025-11-17 08:06:55', 'PREPARING', 384.93, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (991, 290, '2025-10-02 16:58:36', 'READY', 1039.23, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (100, 273, '2025-08-27 01:21:18', 'READY', 1682.07, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (176, 491, '2025-12-25 05:49:05', 'OUT_FOR_DELIVERY', 1715.06, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (33, 816, '2025-08-09 11:53:28', 'OUT_FOR_DELIVERY', 260.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (114, 310, '2025-04-26 02:07:21', 'OUT_FOR_DELIVERY', 165.74, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (627, 683, '2025-09-13 12:53:36', 'PLACED', 1185.73, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (868, 634, '2025-12-18 22:14:16', 'READY', 1128.93, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (7, 682, '2025-05-27 15:27:58', 'OUT_FOR_DELIVERY', 1830.57, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (944, 648, '2025-06-22 09:37:56', 'PREPARING', 150.05, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (391, 543, '2025-09-30 21:26:55', 'READY', 1080.57, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (867, 205, '2025-02-19 01:31:14', 'PREPARING', 921.61, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (8, 625, '2025-07-16 12:42:48', 'CANCELLED', 1814.39, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (918, 113, '2025-08-14 00:10:49', 'OUT_FOR_DELIVERY', 288.88, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (426, 859, '2025-09-08 00:04:24', 'PLACED', 1106.8, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (182, 69, '2025-03-06 03:26:29', 'DELIVERED', 284.32, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (129, 711, '2025-08-14 08:35:48', 'CANCELLED', 242.01, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (30, 661, '2025-12-28 11:52:13', 'READY', 218.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (267, 425, '2025-03-24 14:33:40', 'PREPARING', 1146.79, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (441, 484, '2025-10-28 23:01:08', 'PLACED', 655.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (765, 58, '2025-10-12 05:34:15', 'CANCELLED', 381.44, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (240, 688, '2025-06-08 03:32:23', 'OUT_FOR_DELIVERY', 1936.83, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (635, 755, '2025-04-08 13:55:35', 'PLACED', 838.18, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (318, 146, '2025-07-13 06:27:50', 'PLACED', 1348.16, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (687, 540, '2025-03-27 22:54:49', 'CANCELLED', 1918.9, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (481, 143, '2025-03-01 09:27:39', 'READY', 1797.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (371, 19, '2025-04-17 02:56:42', 'DELIVERED', 1904.37, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (884, 882, '2025-12-04 09:47:34', 'READY', 907.76, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (587, 804, '2025-03-28 11:17:47', 'CANCELLED', 1901.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (379, 578, '2025-05-28 15:00:26', 'PLACED', 1745.23, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (998, 152, '2025-12-17 10:34:32', 'CANCELLED', 1142.94, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (277, 815, '2025-04-23 01:41:37', 'READY', 465.76, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (944, 718, '2025-05-19 08:16:27', 'PLACED', 1270.83, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (955, 57, '2025-08-30 02:50:47', 'DELIVERED', 295.11, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (713, 30, '2025-07-29 05:15:21', 'PREPARING', 711.81, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (867, 318, '2025-08-23 23:17:41', 'PLACED', 1248.39, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (400, 269, '2025-08-27 17:09:34', 'READY', 1889.97, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (763, 554, '2025-12-05 03:50:08', 'CANCELLED', 731.88, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (551, 570, '2025-11-03 00:39:25', 'CANCELLED', 1799.9, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (450, 329, '2025-08-17 10:58:41', 'PREPARING', 214.28, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (906, 516, '2025-03-14 18:43:29', 'OUT_FOR_DELIVERY', 1101.91, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (827, 866, '2025-04-26 22:22:19', 'PLACED', 894.21, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (956, 672, '2025-02-20 23:35:14', 'OUT_FOR_DELIVERY', 194.1, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (13, 797, '2025-04-05 07:03:33', 'DELIVERED', 119.77, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (539, 669, '2025-12-19 07:41:32', 'OUT_FOR_DELIVERY', 1123.2, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (874, 19, '2025-12-06 18:50:05', 'PLACED', 1131.55, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (654, 889, '2025-03-30 09:30:26', 'PLACED', 1020.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (879, 538, '2025-04-08 20:30:36', 'PREPARING', 338.29, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (916, 64, '2025-11-26 07:44:40', 'PLACED', 314.64, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (10, 420, '2025-04-01 12:37:15', 'PREPARING', 1409.15, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (860, 423, '2025-07-27 21:17:35', 'DELIVERED', 190.15, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (9, 495, '2025-05-07 16:40:01', 'OUT_FOR_DELIVERY', 221.88, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (795, 51, '2025-03-20 06:18:53', 'PLACED', 599.25, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (59, 897, '2025-01-27 09:08:56', 'CANCELLED', 1226.96, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (919, 453, '2025-04-20 01:14:35', 'READY', 472.8, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (509, 199, '2025-11-19 21:36:12', 'PREPARING', 1655.17, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (989, 32, '2025-10-02 08:12:45', 'PREPARING', 864.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (290, 121, '2025-03-24 12:24:30', 'CANCELLED', 489.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (690, 60, '2025-05-15 12:47:04', 'CANCELLED', 1086.28, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (347, 939, '2025-07-29 04:31:44', 'READY', 1209.83, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (624, 557, '2025-10-30 09:12:20', 'PREPARING', 199.37, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (946, 324, '2025-12-16 18:31:24', 'PLACED', 403.74, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (763, 35, '2025-12-10 02:13:32', 'PREPARING', 1155.98, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (532, 682, '2025-11-17 11:52:59', 'DELIVERED', 1940.75, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (197, 672, '2025-02-27 15:42:25', 'READY', 1739.81, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (337, 351, '2025-12-23 22:21:36', 'OUT_FOR_DELIVERY', 620.18, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (658, 484, '2025-05-13 19:57:50', 'CANCELLED', 1874.73, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (293, 126, '2025-12-11 03:06:27', 'PLACED', 1203.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (782, 366, '2025-05-27 01:42:39', 'PLACED', 1754.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (348, 175, '2025-01-14 09:23:25', 'PREPARING', 760.02, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (545, 294, '2025-05-07 06:04:19', 'CANCELLED', 921.34, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (361, 952, '2025-08-03 18:13:31', 'OUT_FOR_DELIVERY', 623.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (889, 802, '2025-03-18 17:51:11', 'PREPARING', 1715.94, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (24, 138, '2025-01-08 05:41:33', 'CANCELLED', 373.97, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (662, 904, '2025-08-26 20:00:17', 'PREPARING', 1413.51, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (691, 742, '2025-07-14 22:38:07', 'PREPARING', 1863.02, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (444, 561, '2025-02-07 15:57:08', 'PLACED', 226.0, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (100, 206, '2025-04-20 19:00:37', 'PLACED', 1793.43, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (287, 864, '2025-08-25 22:50:00', 'DELIVERED', 512.59, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (887, 876, '2025-01-10 19:14:54', 'CANCELLED', 1682.22, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (568, 189, '2025-11-09 05:09:43', 'PLACED', 1650.45, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (291, 379, '2025-07-02 12:36:51', 'CANCELLED', 251.17, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (587, 400, '2025-01-17 07:12:18', 'PREPARING', 916.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (75, 607, '2025-04-01 11:16:50', 'CANCELLED', 913.82, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (311, 952, '2025-11-11 08:25:31', 'OUT_FOR_DELIVERY', 1017.19, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (581, 313, '2025-04-01 22:19:46', 'CANCELLED', 822.22, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (270, 520, '2025-05-22 15:33:39', 'PREPARING', 1932.08, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (194, 84, '2025-02-16 13:14:19', 'DELIVERED', 1992.93, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (871, 266, '2025-05-26 09:48:16', 'CANCELLED', 1059.55, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (292, 229, '2025-12-21 03:58:13', 'PREPARING', 1717.23, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (306, 519, '2025-07-01 04:04:33', 'DELIVERED', 1865.83, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (937, 427, '2025-09-19 08:09:05', 'DELIVERED', 1716.98, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (797, 181, '2025-10-04 08:01:34', 'PLACED', 178.22, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (934, 216, '2025-05-29 19:07:14', 'PREPARING', 995.3, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (896, 953, '2025-03-12 12:05:02', 'OUT_FOR_DELIVERY', 1173.56, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (668, 688, '2025-01-16 08:10:10', 'PREPARING', 1041.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (909, 357, '2025-10-13 08:49:29', 'PLACED', 1249.18, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (179, 443, '2025-12-26 13:56:59', 'PLACED', 1160.94, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (313, 779, '2025-03-13 02:42:42', 'PREPARING', 1895.52, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (416, 431, '2025-11-29 02:59:44', 'PREPARING', 771.62, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (886, 60, '2025-08-14 03:37:08', 'DELIVERED', 1155.46, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (489, 391, '2025-02-06 21:42:03', 'CANCELLED', 244.72, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (676, 974, '2025-05-24 08:20:37', 'PLACED', 794.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (908, 714, '2025-01-08 13:31:22', 'PLACED', 910.08, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (579, 571, '2025-03-17 05:25:27', 'DELIVERED', 1848.71, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (779, 926, '2025-08-17 16:51:32', 'PREPARING', 1430.37, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (987, 611, '2025-02-28 19:29:48', 'PLACED', 1051.88, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (266, 113, '2025-11-19 13:45:55', 'READY', 156.17, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (328, 994, '2025-06-01 10:52:01', 'PLACED', 587.99, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (382, 861, '2025-10-25 05:37:13', 'PREPARING', 1283.09, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (695, 944, '2025-11-30 10:33:14', 'OUT_FOR_DELIVERY', 1704.51, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (844, 513, '2025-07-04 20:49:57', 'DELIVERED', 1484.56, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (617, 19, '2025-06-06 02:00:01', 'PREPARING', 943.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (771, 448, '2025-05-15 08:29:53', 'PREPARING', 164.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (912, 986, '2025-07-01 16:50:03', 'PREPARING', 1017.16, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (986, 40, '2025-10-16 03:34:45', 'DELIVERED', 1676.0, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (782, 870, '2025-08-22 23:54:17', 'PREPARING', 1143.06, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (823, 725, '2025-09-02 00:49:22', 'READY', 1251.52, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (643, 160, '2025-08-19 13:30:54', 'PREPARING', 1376.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (895, 669, '2025-10-25 20:59:21', 'OUT_FOR_DELIVERY', 378.78, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (48, 738, '2025-09-03 23:52:04', 'PLACED', 1817.66, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (932, 444, '2025-04-02 11:28:14', 'READY', 1378.36, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (109, 941, '2025-02-09 22:37:32', 'OUT_FOR_DELIVERY', 547.93, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (645, 178, '2025-12-23 12:10:20', 'PLACED', 783.33, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (646, 342, '2025-09-02 03:32:37', 'PLACED', 939.06, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (398, 731, '2025-05-08 06:49:28', 'OUT_FOR_DELIVERY', 1716.38, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (266, 516, '2025-02-25 11:06:14', 'PLACED', 829.92, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (352, 180, '2025-11-08 11:18:51', 'DELIVERED', 1694.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (255, 304, '2025-10-28 14:44:54', 'PREPARING', 834.26, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (973, 220, '2025-05-11 00:10:19', 'READY', 174.56, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (349, 429, '2025-05-29 01:32:19', 'PREPARING', 246.85, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (270, 664, '2025-12-28 05:23:51', 'CANCELLED', 888.25, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (413, 51, '2025-06-19 13:52:25', 'OUT_FOR_DELIVERY', 1225.0, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (333, 918, '2025-11-16 08:23:43', 'READY', 1534.46, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (798, 312, '2025-01-19 21:50:25', 'PLACED', 290.04, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (88, 576, '2025-02-17 22:38:56', 'OUT_FOR_DELIVERY', 1999.77, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (447, 94, '2025-10-01 22:49:15', 'DELIVERED', 1937.42, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (126, 611, '2025-07-06 15:43:09', 'CANCELLED', 1208.85, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (196, 266, '2025-05-19 00:17:08', 'PLACED', 908.29, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (928, 584, '2025-06-12 13:36:41', 'DELIVERED', 1164.12, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (177, 401, '2025-07-22 02:38:54', 'READY', 137.86, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (38, 96, '2025-03-22 22:35:27', 'OUT_FOR_DELIVERY', 1728.6, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (877, 118, '2025-01-23 04:31:20', 'PLACED', 696.53, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (692, 900, '2025-06-18 22:49:58', 'OUT_FOR_DELIVERY', 1249.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (133, 993, '2025-10-17 08:46:22', 'OUT_FOR_DELIVERY', 489.34, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (135, 62, '2025-10-30 17:13:06', 'READY', 388.88, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (419, 323, '2025-10-05 18:04:13', 'PREPARING', 192.65, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (903, 964, '2025-10-03 02:43:57', 'CANCELLED', 565.5, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (125, 746, '2025-09-26 05:50:29', 'CANCELLED', 190.33, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (74, 576, '2025-01-13 17:30:46', 'OUT_FOR_DELIVERY', 1019.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (966, 612, '2025-01-29 21:34:38', 'READY', 457.39, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (446, 865, '2025-08-26 01:27:03', 'PLACED', 1480.17, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (841, 341, '2025-06-19 18:35:30', 'CANCELLED', 418.97, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (614, 868, '2025-01-16 14:38:33', 'PLACED', 862.38, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (849, 149, '2025-01-19 16:38:32', 'PREPARING', 1027.78, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (417, 246, '2025-07-22 10:35:39', 'READY', 1955.58, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (904, 434, '2025-12-07 04:39:51', 'READY', 1639.98, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (108, 995, '2025-07-19 02:57:24', 'PLACED', 925.02, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (881, 572, '2025-10-23 00:06:56', 'DELIVERED', 1356.32, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (620, 887, '2025-09-08 14:01:58', 'PREPARING', 1126.4, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (827, 247, '2025-07-19 20:07:40', 'CANCELLED', 277.08, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (581, 851, '2025-06-13 14:06:31', 'PREPARING', 1596.96, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (505, 127, '2025-09-21 23:21:33', 'DELIVERED', 1163.31, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (176, 286, '2025-11-28 05:05:57', 'PLACED', 1439.97, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (84, 166, '2025-05-22 18:05:02', 'DELIVERED', 869.32, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (794, 547, '2025-11-19 16:02:33', 'DELIVERED', 1265.47, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (41, 710, '2025-03-22 16:25:00', 'READY', 656.5, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (193, 807, '2025-07-02 01:14:12', 'CANCELLED', 857.13, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (254, 813, '2025-02-27 23:32:40', 'OUT_FOR_DELIVERY', 1240.8, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (697, 26, '2025-12-10 04:57:54', 'OUT_FOR_DELIVERY', 1611.46, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (127, 107, '2025-05-27 15:28:22', 'READY', 1372.75, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (496, 462, '2025-11-04 18:46:57', 'DELIVERED', 1838.11, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (29, 395, '2025-01-18 09:25:28', 'DELIVERED', 1991.03, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (658, 547, '2025-05-30 22:29:05', 'PREPARING', 699.6, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (55, 423, '2025-05-20 08:43:26', 'OUT_FOR_DELIVERY', 937.57, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (565, 85, '2025-05-16 08:31:15', 'OUT_FOR_DELIVERY', 447.33, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (153, 865, '2025-06-07 00:40:43', 'READY', 549.1, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (780, 485, '2025-04-30 03:32:17', 'CANCELLED', 230.13, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (898, 826, '2025-07-22 01:48:12', 'READY', 284.9, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (591, 101, '2025-02-12 17:59:25', 'READY', 757.87, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (246, 736, '2025-06-20 13:28:02', 'DELIVERED', 1447.04, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (678, 65, '2025-07-07 13:40:48', 'READY', 1941.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (416, 637, '2025-05-09 22:26:40', 'READY', 1605.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (233, 598, '2025-11-13 02:27:55', 'PLACED', 1958.74, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (175, 362, '2025-09-20 09:42:20', 'READY', 1594.34, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (481, 881, '2025-08-02 20:00:22', 'PLACED', 781.82, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (12, 954, '2025-11-22 17:32:07', 'CANCELLED', 1719.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (478, 577, '2025-06-25 09:27:15', 'OUT_FOR_DELIVERY', 1843.21, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (807, 533, '2025-01-05 17:35:06', 'CANCELLED', 1809.31, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (545, 84, '2025-11-17 01:35:16', 'READY', 1123.03, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (349, 674, '2025-05-05 07:28:14', 'CANCELLED', 1871.37, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (897, 401, '2025-04-01 07:03:14', 'PREPARING', 976.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (595, 125, '2025-05-09 00:45:21', 'PLACED', 488.12, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (226, 776, '2025-07-13 07:59:07', 'PREPARING', 647.89, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (722, 842, '2025-09-13 02:06:28', 'DELIVERED', 1428.22, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (933, 180, '2025-07-20 13:54:13', 'PREPARING', 807.98, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (829, 712, '2025-08-30 06:17:52', 'PLACED', 705.94, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (655, 452, '2025-07-05 22:00:06', 'READY', 1166.77, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (701, 564, '2025-03-08 18:57:53', 'OUT_FOR_DELIVERY', 661.3, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (312, 981, '2025-07-22 00:17:08', 'PREPARING', 1598.52, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (75, 531, '2025-11-27 14:02:14', 'DELIVERED', 1841.78, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (420, 691, '2025-10-15 12:48:56', 'PLACED', 1446.94, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (173, 343, '2025-07-06 23:47:57', 'PREPARING', 1439.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (784, 831, '2025-11-12 04:41:14', 'PLACED', 1303.47, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (438, 25, '2025-02-12 16:40:20', 'PREPARING', 501.5, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (656, 946, '2025-11-17 21:13:28', 'CANCELLED', 1252.41, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (886, 809, '2025-09-19 06:53:22', 'OUT_FOR_DELIVERY', 1478.81, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (455, 713, '2025-06-13 07:48:44', 'PREPARING', 169.97, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (569, 771, '2025-09-21 11:19:05', 'READY', 1372.77, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (485, 803, '2025-01-08 03:28:33', 'CANCELLED', 1397.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (703, 351, '2025-07-09 03:24:00', 'PLACED', 646.78, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (162, 999, '2025-07-08 12:36:21', 'PLACED', 840.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (106, 236, '2025-11-04 11:08:33', 'CANCELLED', 832.39, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (169, 919, '2025-06-27 09:40:23', 'READY', 1774.2, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (790, 930, '2025-09-20 10:53:56', 'DELIVERED', 169.38, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (736, 932, '2025-05-12 10:31:23', 'PLACED', 585.58, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (41, 267, '2025-06-25 10:51:04', 'CANCELLED', 1516.12, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (623, 528, '2025-03-01 06:54:29', 'OUT_FOR_DELIVERY', 1089.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (278, 403, '2025-10-26 12:48:32', 'CANCELLED', 266.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (909, 591, '2025-03-17 03:03:04', 'CANCELLED', 1310.19, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (587, 500, '2025-05-20 14:48:01', 'PLACED', 1968.52, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (474, 547, '2025-02-23 03:31:48', 'PLACED', 248.68, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (134, 423, '2025-07-19 06:57:29', 'CANCELLED', 1385.3, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (463, 175, '2025-09-07 23:11:31', 'CANCELLED', 711.62, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (890, 675, '2025-05-29 20:01:19', 'DELIVERED', 1691.88, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (347, 86, '2025-04-27 15:14:56', 'PREPARING', 1398.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (679, 917, '2025-03-16 02:06:15', 'DELIVERED', 530.09, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (468, 49, '2025-10-20 12:13:21', 'CANCELLED', 1994.06, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (786, 701, '2025-02-12 23:07:59', 'PREPARING', 805.2, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (258, 852, '2025-10-05 17:55:33', 'PLACED', 1688.91, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (31, 261, '2025-04-03 09:49:01', 'DELIVERED', 673.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (861, 384, '2025-03-08 23:40:43', 'PLACED', 971.76, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (409, 236, '2025-05-04 13:37:17', 'READY', 1983.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (338, 63, '2025-09-08 16:48:08', 'OUT_FOR_DELIVERY', 1734.05, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (96, 869, '2025-10-21 16:22:10', 'OUT_FOR_DELIVERY', 1838.15, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (932, 412, '2025-03-06 08:12:18', 'READY', 1562.05, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (80, 32, '2025-03-13 03:21:45', 'DELIVERED', 565.96, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (157, 501, '2025-11-09 22:08:50', 'PLACED', 1847.96, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (141, 20, '2025-02-25 01:39:37', 'READY', 764.85, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (60, 48, '2025-05-06 17:35:38', 'DELIVERED', 899.51, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (360, 795, '2025-02-18 03:22:49', 'PLACED', 250.8, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (178, 368, '2025-03-30 09:39:15', 'CANCELLED', 458.81, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (323, 302, '2025-01-26 06:25:18', 'CANCELLED', 810.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (272, 847, '2025-05-01 08:42:51', 'PLACED', 633.98, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (636, 735, '2025-09-13 09:07:59', 'PREPARING', 1819.02, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (345, 737, '2025-10-31 06:15:59', 'DELIVERED', 1337.02, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (417, 982, '2025-08-12 00:04:22', 'DELIVERED', 1021.32, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (675, 122, '2025-07-12 15:52:11', 'PREPARING', 1606.64, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (134, 984, '2025-08-01 22:25:04', 'OUT_FOR_DELIVERY', 1720.32, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (783, 982, '2025-08-08 08:48:05', 'CANCELLED', 844.51, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (1, 338, '2025-06-14 07:31:15', 'READY', 248.21, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (571, 16, '2025-02-12 07:46:04', 'OUT_FOR_DELIVERY', 563.62, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (79, 924, '2025-10-14 06:02:10', 'OUT_FOR_DELIVERY', 1019.7, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (547, 642, '2025-11-03 22:18:42', 'CANCELLED', 1752.98, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (196, 295, '2025-01-09 19:32:58', 'READY', 141.91, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (933, 998, '2025-11-28 18:17:48', 'PREPARING', 1230.55, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (474, 269, '2025-01-01 14:57:23', 'PLACED', 1727.97, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (245, 506, '2025-09-08 21:41:06', 'OUT_FOR_DELIVERY', 254.65, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (695, 945, '2025-03-09 20:42:39', 'PLACED', 1379.51, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (885, 981, '2025-04-02 12:52:01', 'OUT_FOR_DELIVERY', 129.73, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (282, 209, '2025-04-30 02:19:48', 'READY', 1906.99, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (844, 970, '2025-04-09 23:02:55', 'CANCELLED', 538.69, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (988, 938, '2025-12-04 20:25:47', 'DELIVERED', 825.42, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (269, 97, '2025-09-22 04:44:49', 'READY', 464.25, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (527, 315, '2025-11-13 14:44:46', 'READY', 1185.76, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (512, 47, '2025-04-18 01:35:38', 'PREPARING', 1701.35, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (58, 535, '2025-10-08 16:32:06', 'OUT_FOR_DELIVERY', 1804.57, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (5, 863, '2025-08-26 07:38:25', 'DELIVERED', 287.1, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (752, 158, '2025-06-26 14:49:53', 'PREPARING', 959.26, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (862, 777, '2025-02-28 19:06:37', 'DELIVERED', 1426.07, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (798, 984, '2025-09-18 17:02:32', 'CANCELLED', 1451.32, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (72, 112, '2025-04-17 07:14:35', 'READY', 396.47, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (631, 658, '2025-08-06 14:17:29', 'CANCELLED', 1885.84, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (711, 304, '2025-06-02 01:16:13', 'OUT_FOR_DELIVERY', 1277.3, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (230, 708, '2025-11-23 03:57:02', 'PLACED', 1978.93, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (3, 192, '2025-07-24 17:37:55', 'DELIVERED', 1744.08, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (680, 129, '2025-09-15 06:24:19', 'OUT_FOR_DELIVERY', 1084.66, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (531, 744, '2025-07-15 22:03:21', 'PLACED', 1403.63, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (544, 613, '2025-12-15 22:37:03', 'OUT_FOR_DELIVERY', 1540.77, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (103, 125, '2025-04-05 11:23:58', 'PREPARING', 698.27, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (689, 907, '2025-01-24 04:03:39', 'OUT_FOR_DELIVERY', 772.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (316, 179, '2025-10-01 01:27:57', 'DELIVERED', 658.39, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (241, 648, '2025-06-20 18:35:57', 'CANCELLED', 1700.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (873, 662, '2025-02-27 14:52:18', 'READY', 1224.55, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (705, 267, '2025-02-23 01:21:19', 'READY', 255.22, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (18, 960, '2025-10-05 23:21:32', 'DELIVERED', 364.06, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (529, 963, '2025-02-19 03:32:22', 'PLACED', 1640.22, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (921, 593, '2025-04-16 23:04:47', 'READY', 980.54, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (918, 19, '2025-01-20 13:05:09', 'PREPARING', 690.55, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (995, 39, '2025-05-06 20:45:38', 'PLACED', 1320.58, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (497, 381, '2025-01-14 07:45:28', 'PREPARING', 1139.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (807, 950, '2025-01-14 19:03:21', 'PREPARING', 1594.31, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (755, 262, '2025-12-20 12:59:37', 'READY', 1251.84, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (558, 695, '2025-05-09 18:34:35', 'READY', 1145.39, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (881, 377, '2025-06-05 19:59:16', 'READY', 101.64, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (366, 620, '2025-11-17 23:36:23', 'DELIVERED', 1940.48, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (105, 835, '2025-07-11 15:39:31', 'DELIVERED', 497.89, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (577, 831, '2025-08-05 09:04:41', 'PREPARING', 1479.56, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (605, 746, '2025-01-09 10:28:25', 'CANCELLED', 1179.37, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (643, 7, '2025-02-14 16:45:35', 'PLACED', 1579.92, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (897, 115, '2025-02-02 02:41:17', 'READY', 501.86, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (430, 803, '2025-05-31 05:18:59', 'PLACED', 721.12, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (470, 854, '2025-02-07 17:26:34', 'CANCELLED', 1088.58, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (354, 823, '2025-09-23 04:00:50', 'OUT_FOR_DELIVERY', 1338.22, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (968, 715, '2025-11-21 14:26:08', 'PLACED', 672.88, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (664, 551, '2025-01-09 16:14:11', 'PREPARING', 610.29, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (421, 23, '2025-01-15 16:47:20', 'CANCELLED', 383.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (728, 40, '2025-03-28 22:59:31', 'READY', 891.49, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (474, 930, '2025-04-18 14:20:36', 'OUT_FOR_DELIVERY', 1402.24, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (325, 365, '2025-03-19 20:07:58', 'PREPARING', 390.05, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (664, 146, '2025-07-12 11:14:58', 'OUT_FOR_DELIVERY', 646.16, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (731, 449, '2025-03-06 00:38:11', 'PREPARING', 1858.84, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (444, 885, '2025-02-01 00:20:41', 'PLACED', 1583.63, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (659, 367, '2025-05-17 05:32:19', 'READY', 539.18, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (178, 730, '2025-08-22 03:04:59', 'PLACED', 965.22, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (718, 455, '2025-12-06 13:42:04', 'DELIVERED', 1160.78, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (193, 869, '2025-07-29 22:00:42', 'PLACED', 560.04, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (398, 872, '2025-09-02 02:31:18', 'CANCELLED', 1285.14, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (808, 887, '2025-03-25 20:57:12', 'READY', 1337.91, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (461, 969, '2025-04-16 17:52:16', 'READY', 465.81, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (282, 579, '2025-08-26 05:10:16', 'OUT_FOR_DELIVERY', 1396.14, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (273, 22, '2025-11-02 21:24:01', 'PREPARING', 272.93, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (946, 344, '2025-01-25 06:17:02', 'CANCELLED', 1660.61, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (55, 84, '2025-06-17 13:37:04', 'OUT_FOR_DELIVERY', 122.59, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (91, 53, '2025-10-04 22:43:50', 'PLACED', 942.21, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (514, 163, '2025-09-19 05:43:20', 'READY', 1717.43, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (28, 994, '2025-09-12 15:33:27', 'READY', 613.1, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (31, 143, '2025-01-10 11:58:13', 'PREPARING', 1938.73, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (562, 170, '2025-10-16 13:51:06', 'CANCELLED', 697.71, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (117, 942, '2025-04-23 17:53:32', 'DELIVERED', 1234.22, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (207, 282, '2025-04-22 14:19:12', 'CANCELLED', 823.34, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (661, 45, '2025-04-19 08:15:05', 'OUT_FOR_DELIVERY', 1492.23, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (966, 191, '2025-05-01 00:30:40', 'PREPARING', 1008.64, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (266, 59, '2025-08-17 11:19:43', 'PREPARING', 1099.36, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (603, 868, '2025-05-19 11:56:18', 'READY', 499.0, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (528, 55, '2025-10-25 03:05:58', 'PLACED', 650.87, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (723, 277, '2025-11-11 20:01:48', 'CANCELLED', 1324.4, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (822, 79, '2025-04-17 13:29:37', 'READY', 1872.69, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (45, 918, '2025-08-02 03:31:35', 'OUT_FOR_DELIVERY', 840.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (308, 53, '2025-06-03 11:21:08', 'PLACED', 1360.1, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (548, 911, '2025-06-13 19:54:12', 'PLACED', 348.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (586, 961, '2025-11-12 23:36:26', 'OUT_FOR_DELIVERY', 513.57, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (464, 562, '2025-10-15 00:08:49', 'CANCELLED', 1052.1, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (737, 713, '2025-09-09 15:29:13', 'PLACED', 1191.82, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (754, 652, '2025-05-01 13:10:01', 'READY', 872.19, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (804, 518, '2025-12-11 19:51:29', 'DELIVERED', 1837.29, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (277, 57, '2025-11-02 05:53:13', 'DELIVERED', 1326.02, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (239, 367, '2025-10-17 17:19:13', 'READY', 1408.17, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (844, 416, '2025-05-26 12:20:14', 'DELIVERED', 1478.24, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (315, 403, '2025-07-22 19:12:31', 'OUT_FOR_DELIVERY', 1272.66, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (808, 592, '2025-02-22 07:04:06', 'READY', 1701.94, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (1, 566, '2025-12-18 23:58:06', 'OUT_FOR_DELIVERY', 1103.0, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (741, 475, '2025-12-11 03:44:48', 'READY', 317.6, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (920, 334, '2025-07-15 22:16:28', 'CANCELLED', 1227.58, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (872, 776, '2025-01-12 02:10:30', 'PLACED', 480.03, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (714, 709, '2025-02-15 08:14:08', 'READY', 1869.58, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (189, 553, '2025-08-02 07:29:05', 'CANCELLED', 1728.64, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (87, 885, '2025-08-10 03:25:55', 'READY', 1518.86, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (997, 859, '2025-08-13 05:23:55', 'PLACED', 1770.18, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (836, 216, '2025-09-15 19:17:55', 'CANCELLED', 1219.33, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (957, 421, '2025-02-18 10:11:18', 'READY', 1880.72, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (198, 709, '2025-07-17 10:22:26', 'OUT_FOR_DELIVERY', 1558.99, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (116, 755, '2025-07-28 14:58:11', 'OUT_FOR_DELIVERY', 514.03, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (290, 879, '2025-09-18 22:00:13', 'CANCELLED', 867.44, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (94, 822, '2025-01-16 02:18:55', 'PREPARING', 1928.84, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (209, 404, '2025-04-23 15:30:13', 'CANCELLED', 223.17, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (875, 169, '2025-02-18 04:28:53', 'PLACED', 1578.31, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (163, 414, '2025-11-20 10:40:05', 'READY', 571.38, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (895, 842, '2025-07-30 22:52:39', 'READY', 786.66, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (215, 641, '2025-07-25 10:50:15', 'OUT_FOR_DELIVERY', 265.81, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (629, 256, '2025-12-03 19:37:07', 'PLACED', 856.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (729, 732, '2025-09-04 07:31:51', 'READY', 499.94, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (933, 503, '2025-05-10 14:57:38', 'PREPARING', 236.38, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (153, 791, '2025-03-18 18:47:42', 'CANCELLED', 1824.99, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (677, 763, '2025-08-13 23:03:34', 'CANCELLED', 1912.71, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (14, 424, '2025-04-16 05:29:19', 'OUT_FOR_DELIVERY', 1352.28, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (1, 872, '2025-12-30 21:01:35', 'CANCELLED', 918.02, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (656, 515, '2025-09-17 01:36:53', 'READY', 879.3, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (721, 226, '2025-07-03 22:10:39', 'CANCELLED', 1021.35, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (143, 48, '2025-01-07 19:23:47', 'READY', 1360.65, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (336, 746, '2025-09-16 15:16:01', 'PREPARING', 911.16, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (276, 877, '2025-10-21 20:58:07', 'CANCELLED', 667.35, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (763, 993, '2025-06-22 13:43:07', 'CANCELLED', 1129.01, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (322, 162, '2025-06-29 13:16:34', 'OUT_FOR_DELIVERY', 643.1, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (821, 774, '2025-07-19 06:23:58', 'DELIVERED', 974.84, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (557, 332, '2025-03-17 19:23:06', 'DELIVERED', 1663.21, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (290, 30, '2025-07-01 03:13:45', 'OUT_FOR_DELIVERY', 483.98, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (174, 316, '2025-05-16 17:02:57', 'DELIVERED', 1775.63, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (617, 838, '2025-05-10 16:27:31', 'PLACED', 113.92, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (767, 331, '2025-08-31 13:49:02', 'OUT_FOR_DELIVERY', 1762.11, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (621, 602, '2025-10-08 05:23:29', 'OUT_FOR_DELIVERY', 1091.72, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (617, 109, '2025-05-29 03:10:28', 'PLACED', 288.22, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (533, 687, '2025-10-08 09:07:11', 'PLACED', 1718.45, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (205, 224, '2025-09-04 13:36:12', 'READY', 631.02, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (976, 770, '2025-06-26 22:18:56', 'OUT_FOR_DELIVERY', 215.58, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (757, 288, '2025-07-26 03:40:46', 'DELIVERED', 197.67, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (737, 233, '2025-01-08 21:59:13', 'READY', 896.34, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (556, 835, '2025-03-15 18:19:19', 'READY', 1426.33, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (249, 860, '2025-09-04 23:18:42', 'PREPARING', 547.96, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (561, 110, '2025-08-07 01:54:05', 'OUT_FOR_DELIVERY', 1863.03, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (153, 527, '2025-12-31 07:39:20', 'DELIVERED', 1664.45, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (704, 576, '2025-11-07 13:21:49', 'DELIVERED', 657.07, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (133, 199, '2025-08-10 04:47:19', 'OUT_FOR_DELIVERY', 889.89, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (889, 454, '2025-10-25 10:24:01', 'READY', 849.59, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (551, 435, '2025-12-23 10:54:25', 'CANCELLED', 1872.86, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (159, 355, '2025-08-28 13:03:23', 'PREPARING', 1700.54, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (127, 251, '2025-01-20 12:05:16', 'READY', 783.31, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (287, 621, '2025-04-18 17:12:09', 'PREPARING', 1937.45, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (675, 610, '2025-02-21 06:24:05', 'OUT_FOR_DELIVERY', 547.43, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (204, 830, '2025-05-09 09:36:08', 'CANCELLED', 1253.74, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (736, 323, '2025-03-05 11:37:45', 'OUT_FOR_DELIVERY', 716.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (824, 881, '2025-07-27 13:32:52', 'PLACED', 1009.91, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (762, 870, '2025-07-09 13:14:46', 'READY', 1074.6, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (656, 638, '2025-06-16 16:43:27', 'OUT_FOR_DELIVERY', 790.23, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (785, 56, '2025-05-01 23:30:20', 'PLACED', 1636.75, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (16, 235, '2025-01-04 16:12:56', 'CANCELLED', 1404.36, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (597, 780, '2025-12-20 21:21:53', 'DELIVERED', 1921.24, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (104, 385, '2025-11-21 19:28:36', 'PREPARING', 1270.17, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (87, 524, '2025-08-22 02:23:54', 'PREPARING', 1417.09, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (363, 665, '2025-11-02 14:44:22', 'DELIVERED', 1992.96, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (671, 117, '2025-01-05 20:58:06', 'READY', 537.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (347, 265, '2025-11-30 00:16:21', 'CANCELLED', 1372.53, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (936, 60, '2025-03-12 06:35:32', 'PREPARING', 434.76, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (692, 824, '2025-04-08 11:49:36', 'PLACED', 109.26, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (511, 13, '2025-09-24 01:09:10', 'PREPARING', 323.42, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (405, 501, '2025-10-13 16:25:39', 'DELIVERED', 445.6, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (530, 523, '2025-11-29 08:16:00', 'PREPARING', 1319.3, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (528, 394, '2025-08-17 00:17:30', 'READY', 1739.21, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (884, 495, '2025-06-29 13:28:33', 'OUT_FOR_DELIVERY', 259.43, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (433, 403, '2025-05-07 14:10:44', 'PLACED', 784.83, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (268, 446, '2025-07-05 07:36:12', 'READY', 463.03, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (355, 552, '2025-09-06 13:27:29', 'CANCELLED', 1305.9, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (915, 602, '2025-05-05 10:00:08', 'PLACED', 1586.87, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (240, 553, '2025-10-19 23:10:00', 'OUT_FOR_DELIVERY', 1036.26, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (186, 615, '2025-06-24 18:12:27', 'OUT_FOR_DELIVERY', 1991.43, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (382, 601, '2025-06-02 09:19:03', 'PLACED', 1232.64, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (650, 531, '2025-03-20 16:05:06', 'CANCELLED', 426.16, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (612, 144, '2025-10-18 14:13:10', 'CANCELLED', 758.89, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (30, 876, '2025-02-20 01:11:34', 'DELIVERED', 1106.65, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (705, 963, '2025-05-19 16:28:29', 'PREPARING', 1365.45, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (797, 223, '2025-09-18 18:00:03', 'PREPARING', 534.65, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (974, 217, '2025-09-07 08:23:08', 'READY', 1009.95, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (189, 530, '2025-05-20 14:50:16', 'DELIVERED', 612.41, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (345, 897, '2025-03-02 04:30:14', 'DELIVERED', 709.84, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (115, 481, '2025-12-06 18:10:17', 'OUT_FOR_DELIVERY', 1084.76, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (345, 793, '2025-09-07 04:12:26', 'PREPARING', 1082.7, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (72, 638, '2025-11-25 04:06:06', 'READY', 1198.51, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (460, 590, '2025-11-05 07:50:00', 'PLACED', 809.41, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (69, 410, '2025-01-25 18:40:19', 'PLACED', 152.54, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (849, 575, '2025-01-24 05:33:06', 'DELIVERED', 1803.18, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (881, 45, '2025-01-31 01:04:20', 'OUT_FOR_DELIVERY', 1732.84, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (626, 620, '2025-06-02 19:56:19', 'OUT_FOR_DELIVERY', 1231.7, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (997, 579, '2025-01-25 09:36:18', 'PLACED', 112.14, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (351, 844, '2025-01-29 18:56:23', 'PREPARING', 817.82, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (829, 832, '2025-04-21 05:04:12', 'READY', 251.47, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (563, 22, '2025-06-10 06:18:28', 'CANCELLED', 720.65, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (104, 408, '2025-03-07 12:34:40', 'PLACED', 1159.03, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (756, 649, '2025-04-07 10:37:57', 'READY', 1566.24, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (852, 117, '2025-01-18 12:27:32', 'PREPARING', 1530.74, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (953, 257, '2025-07-31 07:18:12', 'OUT_FOR_DELIVERY', 1714.25, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (732, 32, '2025-01-30 20:11:28', 'DELIVERED', 1023.87, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (796, 62, '2025-05-08 20:38:29', 'READY', 1214.98, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (557, 681, '2025-12-27 21:49:55', 'PREPARING', 426.14, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (480, 353, '2025-12-30 18:20:32', 'CANCELLED', 189.6, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (188, 1, '2025-09-17 16:34:31', 'PLACED', 1849.4, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (885, 972, '2025-11-25 15:30:49', 'OUT_FOR_DELIVERY', 855.54, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (150, 194, '2025-03-15 10:18:37', 'PREPARING', 1558.82, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (898, 857, '2025-06-05 14:25:26', 'PLACED', 1911.38, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (193, 73, '2025-05-25 15:44:57', 'READY', 1616.73, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (382, 971, '2025-08-25 09:06:21', 'PLACED', 1462.35, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (336, 838, '2025-04-18 20:33:48', 'READY', 524.28, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (108, 183, '2025-02-02 12:42:12', 'PLACED', 499.08, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (112, 324, '2025-12-23 15:47:18', 'PLACED', 1214.7, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (269, 651, '2025-01-07 13:31:44', 'DELIVERED', 743.31, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (33, 175, '2025-03-24 20:02:10', 'OUT_FOR_DELIVERY', 1741.28, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (206, 501, '2025-09-09 20:06:00', 'PREPARING', 1181.94, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (308, 504, '2025-10-20 19:04:14', 'CANCELLED', 343.38, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (714, 836, '2025-09-05 14:34:50', 'OUT_FOR_DELIVERY', 1750.13, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (64, 914, '2025-05-17 21:20:47', 'CANCELLED', 518.24, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (68, 836, '2025-12-14 11:10:31', 'OUT_FOR_DELIVERY', 1741.8, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (679, 253, '2025-09-13 03:23:56', 'CANCELLED', 1931.64, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (754, 255, '2025-05-05 04:07:03', 'PREPARING', 1470.66, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (126, 396, '2025-06-01 22:27:02', 'READY', 182.36, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (491, 745, '2025-04-08 02:26:45', 'PREPARING', 772.38, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (466, 278, '2025-12-07 05:04:54', 'CANCELLED', 413.54, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (155, 781, '2025-03-22 23:07:48', 'OUT_FOR_DELIVERY', 1260.54, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (634, 710, '2025-11-05 01:59:07', 'READY', 720.1, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (146, 504, '2025-08-13 16:22:17', 'PLACED', 1024.21, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (315, 588, '2025-01-16 04:11:11', 'OUT_FOR_DELIVERY', 845.57, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (616, 286, '2025-12-27 06:18:07', 'PREPARING', 1161.7, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (63, 382, '2025-07-01 17:00:50', 'READY', 1327.73, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (65, 39, '2025-09-15 07:53:43', 'CANCELLED', 537.55, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (771, 153, '2025-06-26 04:24:34', 'READY', 1127.67, 'CARD', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (294, 994, '2025-12-02 18:57:38', 'PREPARING', 236.21, 'UPI', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (254, 990, '2025-08-09 12:48:17', 'DELIVERED', 1024.41, 'WALLET', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (526, 96, '2025-01-11 19:21:41', 'READY', 215.51, 'CASH', '2025-09-28 12:38:39');
INSERT INTO orders 
        (customer_id, restaurant_id, order_datetime, order_status, total_amount, payment_mode, created_at) 
        VALUES (187, 768, '2025-10-03 22:27:34', 'CANCELLED', 253.56, 'WALLET', '2025-09-28 12:38:39');
