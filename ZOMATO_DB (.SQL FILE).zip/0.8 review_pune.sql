INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (878, 251, 3, NULL, 'Recusandae beatae voluptatum quam aspernatur quasi corrupti.', '2022-04-10 21:42:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (881, 708, 4, NULL, 'Blanditiis quod odit cum nam vero dolores magni laborum quo.', '2023-04-03 11:28:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (537, 299, 4, 4, 'Fugiat nisi iste quibusdam quibusdam aperiam esse cupiditate animi quasi.', '2022-03-06 21:09:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (533, 7, 4, NULL, 'Quas accusantium repudiandae veniam officiis nulla rem praesentium fugiat dicta.', '2024-07-26 02:07:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (208, 799, 3, 1, 'Laboriosam repudiandae adipisci molestiae natus adipisci et quibusdam minus voluptas.', '2023-07-28 20:28:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (755, 124, 1, NULL, 'Sit ex nisi non hic asperiores et tenetur.', '2024-01-28 12:07:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (245, 727, 1, 4, 'Quisquam quasi incidunt voluptatum repellendus culpa.', '2022-10-30 23:02:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (679, 856, 2, 4, 'Dolor molestiae libero dolorum fuga beatae.', '2023-08-08 17:40:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (697, 576, 3, NULL, 'Perferendis reiciendis tempora voluptate sint consequuntur.', '2024-07-15 13:02:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (953, 782, 3, 2, 'Consequatur repellat vitae ad sit.', '2020-08-13 06:36:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (235, 960, 1, NULL, 'Doloremque modi autem dolorem suscipit maiores dolorem iusto.', '2023-12-17 20:32:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (345, 972, 3, 1, 'Amet repellendus est nam voluptatum molestias nihil esse molestias sint.', '2023-03-09 23:13:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (776, 944, 2, NULL, 'Praesentium hic necessitatibus cumque necessitatibus omnis.', '2024-01-11 18:12:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (794, 535, 2, 4, 'Unde unde magnam rerum odit et saepe fugit.', '2022-04-26 03:49:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (831, 786, 1, 4, 'Delectus quos assumenda neque magni repellat quos.', '2020-06-15 16:25:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (460, 485, 1, NULL, 'Expedita delectus nulla quidem et cupiditate temporibus commodi eum.', '2020-06-06 22:54:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (656, 850, 1, 1, 'Commodi architecto doloribus alias libero voluptatem porro.', '2025-06-21 05:29:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (842, 572, 4, 4, 'Est soluta laborum optio mollitia.', '2025-02-22 23:36:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (440, 982, 1, 4, 'Eum dicta debitis odio adipisci animi saepe qui.', '2024-11-18 17:52:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (988, 488, 3, 3, 'Minima sapiente debitis impedit est possimus magni eligendi velit.', '2022-09-18 22:37:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (130, 339, 5, 3, 'Nisi accusantium quas maiores tenetur quo blanditiis.', '2025-03-15 19:27:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (400, 1, 2, NULL, 'Aut dolore in aliquid cumque.', '2020-09-27 16:16:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (540, 946, 4, 1, 'Fugit fugiat assumenda earum rem.', '2025-01-21 15:56:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (544, 96, 4, 2, 'Earum ducimus impedit fugiat sint atque.', '2020-06-12 13:57:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (162, 42, 1, 5, 'Vel dolor vitae aliquam unde veritatis iusto doloribus nesciunt.', '2021-11-12 06:15:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (36, 912, 1, 3, 'Architecto vero ipsam velit iste accusantium natus quos.', '2024-02-17 06:49:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (326, 689, 3, NULL, 'Dolor incidunt reprehenderit iure accusantium autem soluta quos doloribus maxime.', '2021-04-23 12:58:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (580, 901, 2, 1, 'Reprehenderit magni ipsa amet iste itaque in dignissimos dignissimos et.', '2025-02-07 17:56:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (734, 354, 2, 4, 'Tempora deleniti libero ad minima eligendi.', '2023-05-10 23:52:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (421, 940, 5, NULL, 'Iste ipsum necessitatibus aspernatur quam autem maxime.', '2025-06-16 11:18:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (203, 847, 1, NULL, 'Est ratione id et illum.', '2022-07-02 04:32:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (766, 728, 3, 5, 'Officia natus nihil fuga laborum quos.', '2022-10-15 11:59:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (891, 480, 1, NULL, 'Voluptas dolore occaecati similique quaerat doloremque hic est aliquid.', '2025-08-23 08:06:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (423, 370, 1, NULL, 'Aut sapiente unde eveniet et veritatis error.', '2022-06-02 15:50:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (334, 635, 5, 5, 'Iure voluptates rem atque labore placeat molestiae.', '2025-03-14 13:34:33');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (281, 723, 5, 5, 'Ea officia veritatis tempora temporibus soluta illo sunt earum perspiciatis.', '2022-08-24 17:00:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (451, 593, 1, NULL, 'Eveniet autem quo nulla laborum.', '2022-02-25 18:22:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (243, 94, 3, NULL, 'Accusamus autem consequatur asperiores soluta accusamus.', '2023-03-26 10:58:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (8, 468, 1, NULL, 'Facere voluptates incidunt excepturi architecto ratione.', '2023-11-06 05:43:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (842, 73, 5, 3, 'Cupiditate et praesentium quam ab aut nobis.', '2021-02-17 09:04:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (639, 216, 2, 4, 'Sequi reiciendis adipisci magnam rerum.', '2023-03-09 22:12:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (687, 242, 2, 4, 'Labore fugiat ullam nihil culpa alias ipsum.', '2022-11-07 07:04:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (56, 388, 2, NULL, 'Provident exercitationem suscipit sit quibusdam.', '2022-06-30 21:31:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (361, 18, 5, 2, 'Quas cum deleniti ipsum quaerat quasi.', '2024-08-18 14:09:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (655, 937, 1, NULL, 'Itaque at doloribus sit praesentium placeat occaecati reprehenderit minus quas.', '2020-11-14 09:22:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (245, 315, 5, 4, 'Vitae expedita sequi eos sequi at ratione.', '2025-01-27 04:44:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (12, 681, 1, NULL, 'Culpa rerum repellat doloremque voluptatibus earum id corrupti error quasi.', '2021-06-11 05:22:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (52, 484, 5, NULL, 'Rerum enim sint tempore provident quae quidem.', '2024-01-28 06:49:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (451, 850, 2, 4, 'Porro assumenda beatae odit eos et blanditiis voluptatibus non.', '2021-09-03 07:10:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (802, 675, 1, 1, 'Ab nobis delectus fuga nulla repudiandae iure distinctio.', '2022-10-09 04:34:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (706, 918, 5, NULL, 'Rem assumenda rem praesentium consectetur minus tenetur blanditiis ipsam quo.', '2021-08-01 23:54:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (366, 749, 1, NULL, 'Consequuntur vero quaerat nihil dignissimos tempora.', '2023-12-28 05:52:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (565, 597, 5, NULL, 'Cumque dolor autem earum molestiae accusamus.', '2020-11-17 16:10:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (231, 426, 3, 5, 'In tenetur ad adipisci accusamus eveniet non voluptatibus iste.', '2024-10-25 11:38:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (371, 536, 4, 5, 'Iste iste odit officiis deserunt impedit eos.', '2020-09-25 21:27:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (190, 228, 4, NULL, 'Ab ex doloremque eligendi temporibus.', '2021-07-26 19:05:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (759, 663, 1, NULL, 'Deserunt debitis magni fuga dolore aliquid assumenda ad pariatur quam.', '2022-11-15 03:18:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (628, 533, 3, 4, 'Inventore eaque at ut aliquid iure.', '2023-07-05 22:12:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (613, 607, 3, 1, 'Mollitia mollitia necessitatibus quisquam quis omnis vel.', '2022-07-24 04:59:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (954, 307, 4, NULL, 'Voluptates dignissimos maiores nulla distinctio.', '2021-03-30 14:14:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (90, 321, 3, NULL, 'Suscipit fugiat incidunt dolor maxime error.', '2021-12-23 01:38:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (164, 26, 1, 4, 'Iusto consectetur deserunt neque assumenda magni et ab inventore reprehenderit.', '2021-01-01 19:01:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (734, 643, 2, NULL, 'Cumque adipisci est ea nemo ipsam tenetur dolorum dolor.', '2022-09-02 19:21:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (409, 610, 4, 1, 'Impedit quam provident aperiam possimus ipsa molestiae excepturi ratione corrupti neque.', '2023-09-26 04:33:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (173, 665, 1, NULL, 'Asperiores soluta repellat perspiciatis vel.', '2022-05-17 09:44:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (645, 84, 2, NULL, 'Aliquam aliquid cum quibusdam hic ut at rerum accusantium.', '2023-07-11 14:15:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (566, 470, 3, NULL, 'Unde tempore laudantium odio culpa.', '2023-12-19 04:32:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (316, 598, 4, 5, 'Expedita perferendis earum quidem assumenda reiciendis dicta vitae.', '2025-02-23 10:44:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (267, 617, 2, 2, 'Corporis qui aliquam consequuntur.', '2025-09-24 09:00:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (692, 137, 2, 2, 'Inventore laboriosam similique libero iste veritatis doloremque placeat.', '2024-09-29 12:59:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (331, 299, 4, 2, 'Id ea in nesciunt.', '2021-06-24 11:23:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (406, 816, 2, 4, 'Ipsam dolores sit voluptates.', '2020-01-21 14:14:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (371, 203, 3, NULL, 'Enim qui cupiditate recusandae aspernatur sit reprehenderit aperiam vel ipsa.', '2023-06-02 05:17:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (893, 93, 4, NULL, 'Omnis distinctio animi neque incidunt enim.', '2022-07-06 13:58:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (956, 573, 3, 2, 'Sunt quia dolore aliquam sit dolores nesciunt repellendus.', '2024-09-03 13:20:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (897, 152, 5, 5, 'Laudantium eum fuga praesentium autem odit aperiam fuga facere.', '2022-03-19 16:27:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (314, 925, 2, NULL, 'Expedita quisquam praesentium assumenda inventore quos.', '2023-02-14 22:03:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (862, 894, 2, 2, 'Doloribus natus mollitia in laudantium fuga deleniti laboriosam pariatur aliquam.', '2024-05-21 18:30:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (60, 946, 4, 5, 'Dolorum et asperiores eum vitae magni nisi alias quas.', '2025-07-17 20:42:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (911, 679, 1, NULL, 'Recusandae labore fuga facilis aliquid necessitatibus ipsa doloribus cupiditate.', '2023-04-03 12:39:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (540, 796, 5, NULL, 'Quas odit recusandae excepturi porro.', '2021-12-08 07:15:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (764, 659, 5, 2, 'Cum ratione odit repellat laboriosam totam.', '2020-01-21 00:46:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (78, 331, 5, NULL, 'Illum culpa fugiat ab autem ipsam.', '2025-09-25 20:29:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (420, 441, 1, NULL, 'Quasi veniam amet odit autem vel.', '2022-04-02 19:14:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (967, 186, 5, NULL, 'Doloremque molestiae cumque doloribus dolorum aperiam deserunt amet.', '2021-05-20 04:15:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (485, 49, 5, NULL, 'Cumque voluptatum tempore ullam ipsam optio facilis porro est perferendis voluptate.', '2021-03-26 06:36:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (850, 148, 1, 4, 'Tenetur commodi non sed fugiat iusto accusantium tenetur atque autem.', '2023-06-25 15:26:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (615, 739, 5, 2, 'Et dolor deserunt commodi facilis atque repudiandae eligendi.', '2022-10-22 15:07:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (862, 952, 2, NULL, 'Ea asperiores blanditiis delectus blanditiis sunt quae.', '2025-03-05 20:42:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (198, 579, 2, 5, 'Quibusdam recusandae eligendi totam perspiciatis officia provident nostrum.', '2024-11-01 09:43:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (100, 934, 4, 1, 'Est impedit incidunt iste aspernatur eaque corrupti neque vero hic.', '2024-12-06 07:14:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (845, 651, 3, NULL, 'Unde corporis quam tempora non laudantium fuga aspernatur esse autem.', '2021-10-22 04:48:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (884, 814, 4, 4, 'Maiores a neque itaque nobis amet magni.', '2025-07-22 16:15:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (12, 793, 2, 3, 'Autem doloribus ipsum harum iure totam molestias quasi voluptates suscipit.', '2020-10-13 16:37:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (149, 432, 3, 5, 'Blanditiis laborum unde voluptatibus animi perspiciatis.', '2020-04-02 17:01:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (282, 265, 5, NULL, 'Quod debitis reiciendis ex sit veniam harum officia.', '2024-03-04 22:49:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (994, 441, 5, 1, 'Qui perspiciatis voluptas ad libero nobis.', '2024-03-09 20:55:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (562, 204, 5, NULL, 'Ad vel sit accusantium quisquam distinctio nostrum ea labore voluptatum.', '2022-06-09 14:33:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (565, 725, 2, NULL, 'Nemo commodi soluta maxime sint culpa incidunt maiores.', '2020-04-11 06:51:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (322, 392, 4, 1, 'Suscipit dolores quasi nemo a nihil labore sunt labore.', '2024-06-02 14:50:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (307, 54, 3, 3, 'Quia beatae consequatur reprehenderit rem fugiat architecto esse dolorem amet officiis.', '2022-05-05 12:52:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (894, 782, 1, 4, 'Ab possimus soluta inventore accusamus.', '2023-02-06 02:19:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (60, 436, 5, NULL, 'Nulla modi laborum distinctio dolore repellat repudiandae.', '2022-06-24 13:27:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (807, 141, 3, 3, 'Odit asperiores doloribus labore ipsum eligendi veniam quia quam.', '2023-07-08 09:56:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (806, 800, 4, 3, 'Saepe repellat doloremque iste hic deserunt repellendus.', '2025-01-27 22:04:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (704, 807, 4, 5, 'Labore culpa perferendis optio ullam eos.', '2022-08-14 16:56:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (210, 918, 3, 5, 'Aliquid consequuntur ex perferendis quaerat exercitationem facilis veniam enim voluptates.', '2023-01-08 08:51:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (158, 35, 5, NULL, 'Quod esse dolorum id sequi nobis dolorem.', '2024-10-04 21:14:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (817, 188, 1, NULL, 'Repellat blanditiis dignissimos repellendus dolorem placeat facilis.', '2023-10-09 12:43:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (355, 53, 5, NULL, 'Nulla consequatur nostrum ratione maiores illo itaque in.', '2022-09-15 18:40:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (569, 765, 4, 2, 'Esse assumenda blanditiis odit quia unde.', '2021-03-09 04:34:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (104, 958, 5, NULL, 'Placeat dignissimos est magni debitis.', '2021-02-11 08:37:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (345, 891, 4, 1, 'Ex omnis amet excepturi fugiat assumenda iste maiores veritatis nobis.', '2023-08-09 20:41:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (871, 728, 1, 2, 'Deserunt molestias dolor exercitationem reprehenderit sed ipsum modi a.', '2024-11-01 00:40:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (466, 756, 5, 1, 'Ipsa sunt veniam eaque delectus voluptatibus beatae modi repellendus.', '2023-07-16 07:09:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (319, 807, 1, NULL, 'Voluptas officia eius rerum sit repudiandae sequi id.', '2024-02-19 00:58:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (456, 767, 1, NULL, 'Quaerat minima autem iste modi corporis accusamus illo.', '2020-01-04 12:44:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (417, 678, 1, NULL, 'Est doloremque repellendus deleniti id recusandae aspernatur suscipit.', '2022-03-11 16:17:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (103, 196, 1, 1, 'Quo illo aut natus officiis soluta ad nam corrupti et.', '2025-08-01 13:03:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (758, 707, 3, NULL, 'Aut illo nihil corporis praesentium.', '2025-02-01 10:12:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (187, 605, 5, NULL, 'Repellendus consequatur sint et nam quia.', '2021-03-23 04:48:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (456, 666, 1, 5, 'Numquam corporis perspiciatis sunt laudantium enim veritatis in quos ad.', '2020-01-04 17:27:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (540, 547, 4, 3, 'Dicta eaque velit dolores ratione omnis repellat.', '2020-10-03 02:42:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (871, 871, 3, 4, 'Inventore modi accusantium ducimus esse cupiditate animi voluptatibus.', '2025-03-20 19:17:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (909, 515, 3, NULL, 'Eveniet officia sed quas ipsa porro aliquam.', '2023-03-19 02:20:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (990, 843, 1, NULL, 'Dicta nesciunt ducimus dignissimos unde molestias dicta unde.', '2023-08-02 01:18:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (790, 253, 1, NULL, 'Harum amet optio dolore impedit tenetur ex autem sequi.', '2022-06-30 12:18:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (870, 124, 5, 3, 'Aliquid quam vero saepe corrupti.', '2020-01-22 01:55:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (521, 25, 4, NULL, 'Libero eius dicta architecto ad repudiandae quisquam voluptatum.', '2022-02-06 14:30:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (285, 742, 5, 5, 'Optio autem corrupti libero tempora ipsum voluptates facere.', '2022-11-28 03:37:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (73, 794, 3, NULL, 'Rem tenetur cupiditate incidunt esse totam id.', '2020-02-07 04:44:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (775, 505, 1, NULL, 'Consequuntur perferendis non officiis cum tempore ducimus suscipit cupiditate.', '2025-09-25 02:17:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (647, 901, 2, 3, 'Debitis pariatur tempora magni consequatur asperiores.', '2020-08-19 04:37:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (588, 909, 1, NULL, 'Pariatur adipisci esse ab aut voluptas.', '2021-01-02 01:23:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (222, 132, 2, 3, 'Quas esse necessitatibus sit possimus iure quam delectus accusantium corporis.', '2023-02-12 06:38:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (154, 867, 5, NULL, 'Iusto odio dolor velit totam consequuntur.', '2024-01-04 19:55:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (268, 884, 1, 1, 'Culpa sequi est cum vitae dicta aliquid hic laborum provident.', '2020-12-15 22:13:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (696, 103, 4, 4, 'Sint ea molestiae praesentium quo esse ipsum sit.', '2021-03-19 13:59:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (690, 622, 2, 2, 'Adipisci cumque at harum quidem laboriosam aperiam voluptas.', '2024-12-09 09:16:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (436, 846, 5, 2, 'Iusto velit accusamus laborum excepturi consequuntur maxime quod eligendi voluptatem voluptatibus.', '2021-02-08 01:14:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (96, 668, 1, 4, 'Debitis impedit autem vel nostrum sunt eaque rerum natus.', '2020-06-24 02:38:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (627, 458, 3, 2, 'Reiciendis a eligendi ducimus labore ea.', '2023-09-25 15:55:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (510, 516, 5, NULL, 'Atque numquam hic omnis corrupti consectetur porro ipsum at.', '2021-06-23 16:01:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (643, 570, 2, 5, 'Ipsam quibusdam ipsa fuga molestiae eum rerum dignissimos.', '2025-06-08 19:07:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (668, 870, 1, NULL, 'Rerum facilis sapiente quasi eveniet.', '2020-01-02 10:20:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (877, 414, 2, 1, 'Incidunt cum officia molestias tempora.', '2023-04-19 15:28:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (490, 469, 1, NULL, 'Aspernatur pariatur illo sequi unde nihil odit esse a.', '2024-06-15 03:22:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (175, 514, 2, 4, 'Ea est atque praesentium perferendis sed.', '2021-03-07 16:16:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (299, 512, 5, NULL, 'Laudantium rem laudantium molestiae iste cum assumenda nobis vel sunt dolore.', '2022-06-20 09:38:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (474, 373, 4, NULL, 'Ab dolorem non dignissimos sit commodi impedit ut.', '2025-05-01 01:39:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (574, 742, 1, 1, 'Fugit veritatis distinctio corporis voluptatibus ad ratione consequatur nemo quos.', '2022-06-26 18:15:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (621, 53, 2, NULL, 'Ea tenetur rem nostrum inventore optio eligendi expedita.', '2025-03-09 21:54:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (253, 598, 3, 2, 'Excepturi molestiae temporibus dolores.', '2020-11-04 12:00:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (687, 912, 2, 1, 'Voluptas iste enim omnis odio ducimus reiciendis beatae.', '2024-01-20 20:45:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (70, 240, 5, NULL, 'Tempore doloribus vero fugit et corrupti accusamus voluptatibus illo.', '2025-06-11 23:27:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (301, 102, 2, 5, 'Explicabo perspiciatis eveniet porro aliquid.', '2020-06-27 06:30:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (950, 855, 3, NULL, 'Distinctio aliquid doloremque recusandae et non.', '2025-01-24 23:20:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (159, 385, 2, NULL, 'Pariatur recusandae beatae aut qui aliquam beatae impedit.', '2020-08-09 10:45:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (849, 351, 2, 4, 'Adipisci architecto odio culpa beatae accusamus quibusdam.', '2021-07-17 10:28:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (917, 148, 2, 3, 'Id culpa nostrum vero quo magni repudiandae perferendis.', '2022-09-21 01:17:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (564, 54, 5, 1, 'Qui culpa similique fugit saepe vitae porro harum repudiandae provident.', '2025-01-29 11:58:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (463, 991, 5, NULL, 'Reprehenderit dolore autem sed deleniti corrupti est.', '2024-12-26 18:49:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (384, 193, 2, NULL, 'Cupiditate omnis perferendis quam beatae fugiat accusamus vitae doloribus.', '2021-04-08 15:37:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (18, 366, 2, NULL, 'Esse quae quidem beatae consectetur est tenetur.', '2022-11-15 21:48:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (410, 714, 1, NULL, 'Nisi blanditiis minima sequi aliquam nemo architecto quasi eos.', '2024-08-13 20:23:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (725, 422, 5, NULL, 'Suscipit sequi sunt odio nulla atque corrupti vel fuga illo.', '2022-05-03 16:07:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (859, 251, 1, NULL, 'Ut voluptates saepe labore doloribus distinctio.', '2023-07-03 17:47:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (140, 366, 2, NULL, 'Quis minima possimus commodi deleniti exercitationem quos quasi suscipit asperiores.', '2021-11-01 23:22:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (417, 569, 5, NULL, 'Ad eveniet distinctio possimus ipsum dignissimos libero error quo consequatur quod.', '2023-10-14 05:50:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (183, 299, 5, 4, 'Facilis ipsam quam repudiandae cupiditate sunt eveniet eius libero.', '2023-01-19 14:29:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (9, 335, 4, NULL, 'Corporis est nulla aliquam consequatur repellat placeat quo nihil.', '2023-12-23 19:50:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (858, 486, 5, NULL, 'Ab provident assumenda neque at beatae qui sed ratione.', '2024-05-15 09:25:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (529, 205, 4, 4, 'Maiores quis magni delectus cupiditate.', '2023-11-23 18:53:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (80, 163, 2, NULL, 'Nulla laboriosam quos deserunt corporis voluptate nesciunt.', '2022-08-04 11:48:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (789, 11, 4, NULL, 'Cupiditate libero pariatur harum pariatur quas laborum.', '2021-08-06 16:06:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (188, 178, 1, 5, 'Aspernatur facere doloribus minus perspiciatis autem aut odio provident.', '2023-07-26 19:26:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (498, 648, 1, 3, 'Dolore repellendus blanditiis similique nam cum nihil dicta aut porro adipisci.', '2021-07-30 17:11:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (95, 861, 4, NULL, 'Fugiat sint officiis iste voluptas hic neque vel ipsa harum.', '2023-12-31 10:18:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (916, 480, 1, NULL, 'Dignissimos quos quibusdam ratione maiores itaque.', '2025-09-11 00:48:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (663, 840, 2, NULL, 'Fugit minus numquam illum deserunt aut in illum repellendus fuga.', '2020-07-07 15:21:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (160, 346, 3, 5, 'Facilis iusto cum perspiciatis totam expedita dicta.', '2021-12-16 14:15:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (44, 111, 2, 5, 'Magni ipsam harum sit illo recusandae ipsam inventore.', '2023-04-20 13:15:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (745, 956, 4, NULL, 'At ducimus nostrum consequuntur illo debitis.', '2020-12-26 17:37:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (296, 915, 2, NULL, 'Maiores fuga doloribus quibusdam repellat voluptatibus repellat provident aperiam aut.', '2021-08-23 02:25:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (526, 308, 2, NULL, 'Cum ipsa maxime fugiat consequatur.', '2022-08-25 15:23:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (834, 686, 5, NULL, 'Esse corporis facilis suscipit praesentium autem quasi repudiandae.', '2020-12-08 21:47:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (522, 827, 5, 2, 'Adipisci numquam laborum aspernatur voluptatum velit explicabo placeat voluptatum ipsa.', '2024-06-16 19:28:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (70, 598, 2, NULL, 'Consectetur magni praesentium reiciendis quas suscipit reiciendis culpa.', '2021-02-07 18:40:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (109, 706, 4, 1, 'Repellendus perspiciatis porro aspernatur facere qui sunt.', '2022-03-23 07:07:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (642, 337, 1, 3, 'Cum quia quasi atque ad.', '2022-01-31 01:39:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (126, 21, 4, NULL, 'Temporibus eius molestiae accusamus modi nostrum facilis quidem.', '2022-05-14 20:28:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (796, 289, 5, NULL, 'Tempore nihil nulla in recusandae ipsa id sunt soluta quam.', '2021-12-26 19:29:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (999, 345, 4, NULL, 'Officia adipisci in eum deserunt maxime itaque ad est laborum incidunt.', '2024-10-13 22:17:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (329, 605, 2, NULL, 'Hic deserunt itaque earum cumque totam laudantium adipisci eius.', '2021-02-01 10:31:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (255, 220, 5, 1, 'Aliquid molestiae nam voluptatibus.', '2020-04-11 20:58:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (834, 341, 5, NULL, 'Adipisci soluta quae quidem illum exercitationem.', '2020-02-24 14:21:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (639, 243, 1, NULL, 'Esse quae error quas soluta optio nisi.', '2020-01-07 23:54:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (652, 17, 4, 4, 'Est eveniet architecto maiores dolorem dolorum.', '2025-07-01 07:53:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (872, 365, 5, 1, 'Eligendi molestias ipsum exercitationem quasi placeat accusantium optio nisi aliquam.', '2024-01-21 16:35:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (12, 63, 1, 1, 'Recusandae quam quisquam similique officia pariatur distinctio labore.', '2024-09-16 15:22:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (600, 794, 1, 2, 'Necessitatibus fugit tenetur sunt asperiores voluptatem non fugit.', '2025-09-04 15:09:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (897, 75, 5, 3, 'Beatae nesciunt harum quas dicta eos.', '2020-08-30 21:29:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (123, 295, 4, 2, 'Quas vel laborum quae odio illo dolorum expedita sapiente ipsam.', '2024-07-30 18:10:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (684, 399, 3, NULL, 'Voluptatem libero ipsum ab cum error officia dicta.', '2023-12-10 05:20:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (783, 999, 1, 1, 'Magni voluptatibus repellat excepturi unde commodi adipisci ullam ducimus.', '2020-12-01 07:26:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (629, 745, 2, NULL, 'Quas sed possimus exercitationem odit tenetur ea fuga nulla natus.', '2021-09-26 03:34:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (667, 982, 4, 1, 'Et iure expedita asperiores facilis.', '2022-06-27 17:25:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (183, 526, 2, 4, 'Enim saepe tenetur consectetur necessitatibus praesentium.', '2022-02-05 01:28:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (290, 179, 5, NULL, 'Blanditiis recusandae voluptatem reiciendis eaque a praesentium assumenda a a.', '2022-03-17 10:29:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (465, 722, 1, 2, 'Omnis laborum error soluta molestias.', '2025-06-14 01:38:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (436, 122, 2, 4, 'Repellat maxime recusandae nihil tempora qui sapiente placeat maiores suscipit nihil.', '2021-10-18 04:50:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (680, 588, 3, 5, 'Quaerat eaque recusandae iure quisquam delectus.', '2020-11-03 03:12:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (16, 106, 3, NULL, 'Occaecati ut ullam consequatur ea eos deleniti illo.', '2021-01-23 03:16:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (433, 847, 3, NULL, 'Possimus repellendus ex facilis alias neque id ea quae.', '2023-09-03 14:30:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (177, 123, 2, NULL, 'Ratione doloribus ut veritatis dolores sapiente vero fuga rerum nesciunt.', '2022-07-25 08:09:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (563, 806, 3, NULL, 'Assumenda dolorum nisi reprehenderit dolores quibusdam molestiae.', '2023-09-28 12:39:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (675, 84, 3, 1, 'Fugiat eaque cumque unde nemo deleniti.', '2022-11-03 21:34:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (405, 113, 5, NULL, 'Numquam alias quis doloremque expedita laudantium impedit voluptas dolorem quae.', '2024-03-19 07:06:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (768, 148, 2, 1, 'Quod maiores ea excepturi incidunt nulla soluta.', '2023-01-11 13:15:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (348, 454, 4, 1, 'Velit voluptates delectus tempora inventore voluptatem officiis.', '2024-08-12 03:26:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (873, 53, 2, 3, 'Eum occaecati facere optio tempore suscipit facere.', '2025-02-12 05:34:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (838, 900, 5, NULL, 'Repudiandae nobis dolores ea mollitia ea molestias error.', '2023-08-23 08:16:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (303, 589, 1, 4, 'Tenetur tenetur quis odio.', '2025-02-04 00:02:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (74, 586, 2, 5, 'Expedita sunt voluptate reprehenderit mollitia esse.', '2023-09-14 19:49:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (6, 111, 2, NULL, 'Laudantium corrupti aperiam dolor nemo.', '2021-06-10 05:42:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (39, 14, 1, 4, 'Facilis eligendi quaerat facere error optio labore incidunt perferendis consequatur.', '2023-08-28 17:34:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (404, 989, 4, 5, 'Deserunt quos ut tenetur nam dolorem.', '2022-01-30 04:41:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (814, 2, 5, NULL, 'Atque veritatis perspiciatis nesciunt mollitia sunt quos asperiores.', '2024-09-16 17:01:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (651, 135, 5, 2, 'Velit nisi architecto eligendi nulla mollitia distinctio.', '2021-10-04 19:10:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (861, 746, 5, NULL, 'Natus eligendi repellendus eius suscipit laudantium.', '2021-07-18 22:22:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (387, 671, 2, 1, 'Nulla reiciendis ad deserunt perferendis inventore ipsum fugit labore.', '2024-03-13 19:36:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (288, 995, 1, NULL, 'Doloribus harum laboriosam nesciunt quis natus sint delectus expedita occaecati.', '2024-07-09 15:49:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (925, 540, 4, NULL, 'Quidem quibusdam unde maiores eaque dolore nam eum aspernatur.', '2025-08-22 00:06:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (585, 145, 2, NULL, 'Magni saepe aut tempora sed nihil.', '2022-02-09 19:24:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (202, 71, 3, NULL, 'Qui iure nisi deserunt officiis sapiente.', '2022-05-06 16:55:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (629, 779, 2, 4, 'Eius aut nulla officia fuga facere nesciunt.', '2020-10-04 16:23:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (962, 297, 2, 3, 'Veritatis ab dolor dicta neque laboriosam autem.', '2021-11-22 20:05:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (429, 169, 1, NULL, 'Recusandae sequi nihil dolorem omnis magnam dolor.', '2023-09-08 03:39:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (272, 623, 2, 5, 'Saepe hic aut dolore asperiores laboriosam magni.', '2021-08-29 06:39:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (622, 594, 1, NULL, 'Provident vitae dolorum aliquam.', '2020-06-17 08:31:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (664, 667, 1, NULL, 'Voluptates delectus a tenetur quibusdam culpa ex corporis.', '2020-05-27 20:33:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (751, 633, 4, NULL, 'Libero laudantium debitis eum quaerat ipsum.', '2024-09-11 04:19:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (758, 327, 2, NULL, 'Occaecati ex ullam nobis fugiat soluta.', '2021-07-17 18:22:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (280, 754, 4, NULL, 'Labore fuga ipsum veritatis tenetur velit est perspiciatis ut vel.', '2020-10-18 11:50:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (635, 745, 1, 1, 'Omnis sapiente enim quae maxime repellat illum.', '2020-03-23 09:41:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (230, 461, 2, 4, 'Natus debitis ex exercitationem voluptas.', '2020-06-05 03:59:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (116, 606, 1, 1, 'Ex incidunt quam necessitatibus quaerat a veritatis maiores tenetur sequi perspiciatis.', '2020-06-16 00:36:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (565, 229, 5, 1, 'Laudantium cum culpa aliquam hic illo laborum in natus.', '2023-12-07 06:00:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (781, 57, 3, NULL, 'Aut nostrum qui voluptates harum veniam ducimus officiis reprehenderit ipsa.', '2022-02-01 23:28:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (381, 970, 2, NULL, 'Cumque optio autem amet repellendus itaque odio consectetur ipsum nesciunt.', '2025-02-07 18:28:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (379, 681, 2, 2, 'Incidunt sit quod praesentium alias nulla.', '2021-05-18 09:07:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (164, 630, 1, NULL, 'Quam autem fugiat consequatur debitis iure.', '2024-09-08 12:37:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (647, 696, 3, NULL, 'Expedita consequuntur fugiat debitis delectus laudantium.', '2021-10-20 12:07:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (240, 723, 3, 2, 'Eligendi dolores voluptatibus aliquid blanditiis.', '2021-12-18 11:50:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (954, 708, 2, 4, 'Deserunt sed consectetur eveniet aliquid qui quod incidunt distinctio ullam.', '2024-10-31 11:35:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (318, 503, 3, 3, 'Facilis doloremque recusandae quisquam error at odio laudantium voluptates.', '2025-07-29 15:24:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (985, 493, 4, 4, 'Atque eveniet in perferendis quia harum alias modi quos deserunt.', '2023-07-18 13:00:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (297, 75, 4, 2, 'Ipsa repellat dicta ex debitis ad.', '2023-01-19 21:24:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (490, 39, 1, NULL, 'Odio a perspiciatis enim quo reiciendis quam ex itaque molestiae.', '2023-10-15 13:56:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (772, 809, 2, NULL, 'Consectetur aliquid magnam ullam laudantium eum expedita ipsam sequi dolorem.', '2020-04-08 17:03:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (503, 69, 2, 1, 'Sapiente perferendis mollitia quis facilis asperiores omnis ipsam.', '2022-07-24 13:08:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (169, 738, 3, NULL, 'Nostrum error repellendus expedita cupiditate totam a officia.', '2023-08-29 11:42:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (20, 823, 1, NULL, 'Quisquam placeat et rerum exercitationem provident distinctio.', '2021-12-26 15:10:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (522, 673, 4, 1, 'Pariatur perferendis consequatur nesciunt reprehenderit voluptatem recusandae.', '2020-05-31 05:43:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (22, 534, 1, NULL, 'Distinctio animi eius quod odio.', '2025-09-01 06:27:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (614, 68, 1, 1, 'Quidem vitae quam animi animi repellat.', '2020-06-02 09:37:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (515, 747, 5, NULL, 'Praesentium quo impedit odio corporis repudiandae quis.', '2021-12-27 20:50:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (385, 286, 2, 5, 'Libero optio corporis sit eveniet delectus numquam harum aut.', '2023-06-14 07:17:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (174, 385, 5, NULL, 'Accusamus nulla excepturi odio.', '2020-05-19 22:53:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (207, 79, 4, NULL, 'In ea quidem alias hic adipisci.', '2025-08-29 17:23:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (570, 345, 2, NULL, 'Quia eligendi inventore consequuntur magni velit blanditiis accusantium odit in.', '2022-05-10 20:54:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (445, 398, 2, NULL, 'Sint fugiat temporibus facere corrupti deleniti.', '2023-04-06 13:10:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (188, 211, 4, 2, 'Esse quisquam quos et quidem provident quasi laudantium provident aliquam.', '2023-10-01 05:25:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (805, 680, 2, NULL, 'Dolor culpa eveniet ullam eius.', '2020-09-12 18:03:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (106, 264, 1, 3, 'Deleniti maiores eum fugit facilis pariatur eligendi.', '2021-04-19 23:45:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (655, 310, 4, 5, 'Ullam quibusdam nesciunt atque.', '2024-02-09 12:47:33');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (438, 739, 4, NULL, 'Harum delectus illo asperiores atque natus laborum esse mollitia.', '2025-05-29 03:05:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (773, 287, 2, 2, 'Odit fugiat vitae rem harum suscipit dolorum deleniti perspiciatis delectus.', '2022-11-12 11:10:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (651, 744, 1, NULL, 'Nemo cupiditate facere velit esse tempora deserunt ipsam veritatis omnis doloribus.', '2024-09-26 17:03:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (539, 862, 5, 5, 'Ut eligendi odio ut quisquam nesciunt dolore aliquid.', '2022-09-26 17:19:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (270, 964, 1, 4, 'Maiores perferendis iure tempora saepe esse praesentium libero praesentium.', '2021-03-18 20:08:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (726, 270, 2, NULL, 'Quibusdam dignissimos nisi magni dolores praesentium aliquid molestias porro.', '2023-05-08 13:50:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (811, 1000, 2, 1, 'Voluptatum saepe aspernatur ratione earum perferendis placeat quas.', '2024-02-19 00:33:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (430, 158, 2, 2, 'Laudantium molestias occaecati ullam reprehenderit mollitia aspernatur cupiditate nihil.', '2023-10-10 10:34:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (38, 463, 3, NULL, 'Sit ea ipsum officiis nihil fugiat.', '2025-04-02 15:12:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (147, 502, 2, 3, 'Quidem repudiandae quaerat aspernatur libero.', '2021-08-10 11:02:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (782, 123, 3, 2, 'Voluptates labore recusandae vitae nostrum totam voluptas.', '2020-04-29 18:55:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (974, 290, 4, 3, 'Laborum molestias dolore eaque esse vero repudiandae illum ex quidem.', '2020-03-02 03:36:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (391, 441, 3, NULL, 'Earum enim placeat perspiciatis ipsa cumque.', '2020-08-03 01:25:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (975, 480, 2, 3, 'Et minima deserunt omnis dolore saepe necessitatibus repudiandae.', '2020-01-18 20:20:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (982, 84, 3, 2, 'Ipsum commodi eveniet laboriosam minima.', '2025-07-25 22:52:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (547, 669, 3, NULL, 'Cupiditate numquam nulla harum dignissimos.', '2022-06-13 17:58:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (6, 702, 1, NULL, 'Fugiat fuga dolores quae iure cumque harum fugiat deleniti est.', '2023-08-07 09:32:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (934, 352, 5, 1, 'Consequatur accusantium vitae soluta at magni molestiae quod quod optio.', '2023-01-28 03:14:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (312, 134, 5, 2, 'Animi expedita quisquam inventore.', '2021-04-19 06:52:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (802, 946, 3, NULL, 'Nam nobis maiores sint pariatur iure corporis nobis.', '2020-08-03 11:41:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (622, 728, 1, 5, 'Nobis expedita architecto voluptatibus sit.', '2024-08-24 19:11:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (696, 466, 2, NULL, 'Vel minus eum ad rem magni expedita aspernatur dolores.', '2023-02-17 23:00:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (345, 590, 4, NULL, 'Dignissimos praesentium voluptas repellat possimus.', '2023-04-06 13:56:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (743, 962, 1, 2, 'Blanditiis magnam deserunt iusto provident eveniet.', '2025-07-09 06:24:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (737, 137, 5, 1, 'Inventore perferendis quaerat laudantium dolore quae repudiandae.', '2020-07-29 06:43:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (70, 623, 3, 4, 'Rerum magnam aliquid pariatur atque culpa.', '2023-08-07 21:01:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (966, 296, 3, 5, 'Id enim necessitatibus molestias sit natus enim incidunt.', '2020-03-12 11:59:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (155, 527, 5, 3, 'Ad harum id distinctio deleniti enim omnis dignissimos qui.', '2024-09-05 22:40:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (155, 909, 2, 1, 'Necessitatibus eveniet debitis dolorum voluptas incidunt laboriosam dolore debitis.', '2022-12-21 13:12:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (830, 18, 3, NULL, 'Dolor rerum quo at enim nam ut.', '2024-12-04 09:57:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (647, 237, 3, NULL, 'Placeat recusandae qui accusantium voluptates labore.', '2021-07-29 19:49:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (288, 381, 3, NULL, 'Iste vero nemo impedit eum ratione ad odio.', '2023-10-08 07:02:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (533, 82, 1, NULL, 'Quae reiciendis veritatis velit accusantium facere ratione dolorum in.', '2021-05-21 15:37:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (817, 409, 4, 3, 'Earum iure mollitia voluptas natus ea.', '2024-07-02 09:40:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (957, 961, 4, NULL, 'Iure pariatur minus est itaque accusantium minus.', '2025-01-21 11:29:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (694, 195, 5, 4, 'Qui tenetur quos et nihil.', '2022-01-24 16:37:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (216, 427, 3, 2, 'Ipsa unde expedita ipsum itaque qui.', '2021-06-01 19:49:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (138, 997, 5, NULL, 'Eligendi illo omnis alias ipsa eum ullam laborum quasi.', '2021-08-18 23:55:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (922, 903, 4, 4, 'Commodi praesentium facilis quasi.', '2023-08-25 22:32:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (386, 6, 5, 2, 'Fuga incidunt eius non numquam dolores doloremque perspiciatis quo numquam.', '2020-10-01 07:49:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (489, 57, 2, 1, 'Velit ipsum quaerat dolore perferendis modi animi voluptas.', '2020-09-02 16:43:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (888, 43, 3, 1, 'Suscipit dolore porro dicta.', '2021-08-07 23:50:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (595, 765, 1, 4, 'Aliquid eligendi ullam voluptas enim accusantium quibusdam ut possimus quisquam.', '2022-10-06 19:48:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (555, 526, 1, NULL, 'Accusamus velit repudiandae optio praesentium nesciunt sapiente vitae.', '2025-04-20 20:30:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (935, 32, 3, NULL, 'Quas minima excepturi impedit rerum.', '2021-09-05 12:29:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (503, 347, 2, 5, 'Incidunt maxime rerum odio officia voluptatem rem repellat omnis.', '2024-11-13 11:03:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (324, 553, 3, 1, 'Amet repellendus debitis sed id explicabo.', '2023-01-27 20:05:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (753, 59, 3, 4, 'Sapiente ea molestiae adipisci debitis earum fugiat dignissimos nam.', '2020-05-11 04:16:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (26, 526, 4, 4, 'Harum expedita corrupti ducimus ad sint voluptate.', '2024-10-09 18:25:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (168, 798, 3, NULL, 'Perspiciatis minima voluptatibus natus non incidunt excepturi unde cum fuga.', '2022-11-22 18:34:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (701, 81, 2, NULL, 'Corrupti officiis dignissimos totam accusamus maiores quibusdam necessitatibus voluptatem eaque ipsam.', '2023-08-30 19:46:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (111, 678, 3, NULL, 'Nesciunt repellendus voluptatum voluptatibus quis blanditiis deserunt officia aliquam pariatur vero.', '2022-08-18 03:43:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (726, 206, 2, 2, 'Fugit modi vitae eveniet maxime asperiores perferendis.', '2021-05-03 04:29:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (185, 767, 1, NULL, 'Corporis amet blanditiis dolore quia.', '2022-07-05 21:31:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (500, 654, 4, NULL, 'Ullam cumque aperiam voluptatem omnis dignissimos ex.', '2023-04-19 20:29:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (464, 153, 2, 5, 'Corporis esse unde occaecati mollitia nobis rerum.', '2022-01-23 15:38:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (106, 510, 2, NULL, 'Rerum ut mollitia nesciunt voluptatum.', '2020-05-26 10:17:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (347, 82, 5, 3, 'Nesciunt sed dolore repellat.', '2024-07-16 20:42:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (357, 493, 5, 1, 'Vitae beatae laboriosam eaque eum reiciendis quis ex.', '2025-01-19 15:08:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (685, 256, 5, 4, 'Quos quia eveniet praesentium corrupti voluptate laudantium beatae.', '2020-10-12 08:24:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (957, 247, 5, 2, 'Sapiente quia facere accusantium officia minus soluta.', '2020-11-07 17:40:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (286, 467, 3, 3, 'Vero veritatis quidem eius suscipit facere.', '2022-06-29 16:16:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (607, 913, 5, NULL, 'Vel similique temporibus omnis nisi.', '2023-06-18 00:00:33');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (611, 454, 4, NULL, 'Labore dolor molestias est ipsa velit facilis molestias quod inventore.', '2023-11-28 22:25:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (359, 401, 3, NULL, 'Omnis suscipit quidem vel minima.', '2022-12-29 02:05:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (30, 532, 2, 4, 'Quod aliquam blanditiis libero ducimus animi.', '2023-01-31 13:51:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (664, 608, 4, 5, 'Porro quas blanditiis corporis repudiandae dolorum placeat sint numquam cupiditate.', '2024-07-30 07:57:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (256, 139, 1, 3, 'Asperiores pariatur nihil est magnam consequuntur sapiente.', '2020-09-01 02:50:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (272, 322, 2, 4, 'Odit minima aliquid culpa sequi.', '2022-11-07 23:16:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (391, 984, 5, NULL, 'Culpa magni quibusdam unde iure exercitationem mollitia numquam numquam.', '2023-04-22 09:38:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (983, 549, 3, NULL, 'Asperiores pariatur porro harum illo vitae illo repellendus fuga adipisci.', '2025-06-30 09:35:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (29, 809, 3, 1, 'Facere velit dolorem officia minima a blanditiis.', '2024-05-03 09:50:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (809, 655, 5, 5, 'Sunt itaque recusandae iusto nemo sapiente dolore molestiae libero recusandae.', '2021-03-04 04:47:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (820, 159, 4, NULL, 'Maiores nostrum illo magnam veniam quae.', '2020-11-11 11:30:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (596, 50, 1, 4, 'Quod officia dolorem odio id dolore id numquam totam laudantium.', '2023-11-19 13:57:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (186, 215, 5, 3, 'Hic inventore laudantium qui iste.', '2025-02-27 18:07:33');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (973, 908, 5, NULL, 'Deserunt sequi repudiandae impedit nesciunt aspernatur deserunt aliquid.', '2024-07-21 06:24:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (719, 40, 2, NULL, 'Dolores esse minima voluptate aliquam fuga vero vitae tempore nemo.', '2020-03-10 20:26:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (867, 476, 2, NULL, 'Quidem culpa incidunt accusamus assumenda assumenda numquam iste natus.', '2022-01-07 21:51:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (37, 846, 3, 4, 'Reiciendis aliquam quam magnam nulla illum reiciendis.', '2022-06-02 03:40:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (862, 210, 4, 4, 'Earum sequi natus tenetur laboriosam beatae possimus odit.', '2022-08-31 17:36:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (5, 901, 3, NULL, 'Accusamus similique repellat voluptatibus rerum fuga.', '2024-07-09 16:17:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (879, 733, 4, NULL, 'Exercitationem in laudantium corporis velit voluptas molestias voluptatem aut architecto.', '2023-05-15 14:42:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (253, 957, 2, NULL, 'Nihil adipisci nostrum recusandae saepe ea eaque nihil.', '2021-10-12 08:11:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (399, 279, 1, 5, 'Provident minima nostrum deserunt fugiat.', '2023-05-30 01:50:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (852, 87, 5, 2, 'At quaerat corrupti natus ex perferendis fugiat necessitatibus animi.', '2025-05-08 17:14:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (232, 583, 2, NULL, 'Minus magnam excepturi accusamus beatae totam.', '2022-08-15 18:44:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (137, 633, 3, NULL, 'Vero at tempora quisquam consectetur ab commodi animi ea distinctio.', '2023-11-18 23:22:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (545, 701, 3, NULL, 'Dolor harum corporis impedit asperiores quae illum aut.', '2020-06-23 05:22:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (444, 832, 2, 1, 'Ut illo pariatur veritatis sequi facere molestias ducimus illo.', '2024-08-19 03:55:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (273, 270, 4, NULL, 'Nisi possimus asperiores accusamus a quisquam id at tempore alias.', '2021-03-22 15:36:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (843, 392, 1, 1, 'Velit harum corrupti ab nesciunt.', '2025-02-16 02:46:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (909, 452, 5, NULL, 'Maiores cum dolore vero error beatae cum iusto.', '2025-06-22 01:44:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (335, 118, 1, NULL, 'Dolore blanditiis fuga at voluptatibus.', '2021-08-29 22:30:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (137, 753, 2, 2, 'Sequi vero excepturi culpa.', '2022-12-14 21:31:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (1000, 42, 1, 4, 'Beatae adipisci accusantium corrupti odit harum consectetur voluptatum cumque.', '2022-09-01 12:43:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (894, 383, 1, NULL, 'Commodi provident aperiam neque numquam dicta.', '2021-09-20 10:09:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (327, 129, 4, 5, 'Ea voluptatibus nobis rem architecto tenetur ab nostrum.', '2025-08-17 15:12:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (312, 134, 2, 2, 'Optio pariatur sit earum provident.', '2025-03-30 18:59:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (92, 467, 1, 4, 'Voluptates ab temporibus aperiam cum debitis laboriosam perferendis.', '2020-05-20 11:50:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (130, 409, 4, 1, 'Cumque numquam laudantium unde quaerat necessitatibus.', '2022-11-07 09:30:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (22, 384, 2, 4, 'Assumenda repellat ad quisquam eos laboriosam aperiam numquam a quidem.', '2021-08-17 20:27:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (914, 680, 2, NULL, 'Quis ipsa dolorum nihil neque consequatur cumque illo.', '2023-04-07 14:57:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (286, 504, 5, NULL, 'Placeat unde commodi reiciendis illo optio.', '2024-12-03 10:31:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (455, 68, 1, NULL, 'Numquam eligendi eos praesentium sapiente.', '2025-05-26 16:43:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (961, 57, 1, NULL, 'Excepturi soluta sint recusandae distinctio aperiam expedita rem.', '2021-09-03 20:21:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (243, 876, 1, 3, 'Accusamus eum a enim perferendis quis debitis excepturi maiores reiciendis nulla.', '2020-02-22 17:09:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (943, 98, 3, 5, 'Quae repudiandae adipisci id excepturi ipsam.', '2023-07-18 20:55:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (679, 424, 3, NULL, 'Quae excepturi neque deserunt alias assumenda.', '2024-06-15 18:31:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (143, 483, 5, NULL, 'Molestias excepturi ipsa magni commodi ad voluptates.', '2021-03-03 06:57:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (99, 245, 4, 3, 'Cupiditate repudiandae nulla doloremque ad quos enim autem placeat.', '2020-03-29 03:46:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (166, 196, 5, 3, 'Est modi commodi esse animi voluptas saepe cum explicabo.', '2021-10-26 10:21:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (15, 309, 3, NULL, 'Esse perferendis quisquam alias atque modi nesciunt veniam saepe quos facere.', '2023-07-08 16:25:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (958, 310, 1, 4, 'Sint sunt architecto omnis ad dolor similique.', '2020-06-09 23:59:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (623, 126, 2, NULL, 'Numquam quae delectus ducimus expedita asperiores dolorum perspiciatis vitae.', '2023-10-01 11:06:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (322, 277, 5, NULL, 'Consectetur nisi quas laboriosam asperiores at.', '2021-05-22 10:48:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (823, 903, 2, 5, 'Sed perferendis voluptate rerum non accusantium ullam nemo fugit.', '2024-04-29 16:43:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (5, 155, 4, NULL, 'Repellat repellendus animi aspernatur dolorum ipsa omnis.', '2022-09-24 10:54:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (651, 492, 5, NULL, 'Atque voluptatum sint tempore ea rerum fugiat.', '2023-02-16 13:17:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (739, 162, 1, NULL, 'Ab quaerat atque ex delectus nam ea.', '2021-12-01 18:53:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (790, 82, 4, NULL, 'Voluptatem ipsa voluptates labore minima adipisci fugiat magni velit.', '2020-04-08 03:31:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (379, 311, 2, NULL, 'Non qui laudantium commodi magni.', '2023-12-31 11:43:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (396, 341, 3, 2, 'Officia exercitationem quam amet provident ipsam reiciendis voluptatem accusantium maiores.', '2020-06-18 11:41:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (444, 234, 1, 4, 'Occaecati impedit dolores assumenda recusandae ad.', '2022-07-23 11:21:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (514, 630, 4, 3, 'Accusamus sequi possimus nulla a quaerat.', '2022-11-24 22:05:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (439, 701, 3, 2, 'Magni incidunt non iure voluptatum nesciunt.', '2024-07-05 16:39:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (631, 738, 1, NULL, 'Architecto molestias aut ratione maiores quo officiis fuga rerum.', '2021-06-26 22:40:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (303, 191, 5, NULL, 'Architecto culpa deleniti reiciendis quo debitis.', '2024-10-23 23:27:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (573, 768, 2, NULL, 'Magnam ea saepe minima illum nisi iste tenetur.', '2025-05-05 12:00:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (713, 164, 3, NULL, 'Reiciendis nemo debitis error illum.', '2023-09-12 05:03:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (795, 898, 5, NULL, 'Dignissimos magni eveniet recusandae quidem.', '2023-02-03 13:44:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (630, 550, 5, NULL, 'Corporis tenetur rem veritatis odio incidunt beatae quia dicta dolor.', '2025-03-24 10:54:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (961, 731, 4, NULL, 'Commodi quis voluptatem adipisci accusamus quod deleniti cum eum tempore.', '2020-12-21 20:25:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (459, 73, 3, 4, 'Ipsam ullam saepe dolore deserunt iusto perferendis veniam.', '2023-10-20 01:07:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (366, 645, 3, NULL, 'Laudantium eius vitae labore temporibus.', '2024-01-15 18:24:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (843, 503, 2, 5, 'Minima est a laborum vel ea quisquam dignissimos nam.', '2020-08-13 05:52:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (799, 725, 3, NULL, 'Facere sed nihil ad nobis vero delectus est.', '2024-05-04 14:15:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (742, 557, 4, 4, 'Officia sequi enim explicabo assumenda autem officia harum.', '2024-02-03 14:43:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (616, 67, 5, NULL, 'Pariatur similique perferendis quas consectetur rerum.', '2023-08-27 11:43:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (61, 396, 4, NULL, 'Sequi dolorem vel eligendi ab.', '2020-11-14 16:12:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (501, 454, 1, NULL, 'Omnis non dolorum quam fuga enim.', '2024-10-12 10:04:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (370, 367, 3, NULL, 'Odio laboriosam officia commodi corporis laboriosam.', '2021-02-19 08:49:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (404, 863, 4, NULL, 'Voluptatum quis aliquid nam non molestias consectetur.', '2020-02-03 02:49:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (580, 575, 1, NULL, 'Laboriosam enim totam tempora ab.', '2021-01-27 00:25:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (135, 576, 2, NULL, 'Fugit eius at placeat tempora commodi.', '2024-03-02 22:57:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (993, 929, 3, NULL, 'Provident nulla illum reprehenderit numquam sit.', '2022-04-26 07:58:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (884, 519, 3, NULL, 'Tenetur hic quod at voluptatum blanditiis nam illo aspernatur inventore.', '2021-05-30 08:39:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (976, 796, 2, NULL, 'Consequatur est explicabo natus reprehenderit.', '2024-12-20 09:19:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (408, 6, 4, NULL, 'Ipsa vel dicta doloribus incidunt praesentium dolorem sunt incidunt.', '2020-07-09 09:26:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (621, 925, 3, NULL, 'Provident dolore delectus reprehenderit error ipsam eos ratione delectus deserunt molestias.', '2020-12-21 02:37:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (738, 225, 2, 4, 'Assumenda assumenda impedit suscipit.', '2021-10-27 21:31:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (159, 233, 3, 4, 'Eveniet dolores officia tempore dolore aspernatur.', '2022-09-21 17:22:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (980, 290, 3, NULL, 'Tempore impedit voluptatibus earum nobis molestias illum.', '2022-02-14 18:48:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (81, 390, 4, 2, 'Aut vitae aliquam dolorum nihil maiores dolor quam molestias.', '2024-07-05 19:52:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (892, 502, 2, NULL, 'Hic error delectus id ipsam fuga earum reprehenderit quas voluptatum.', '2023-11-14 14:51:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (892, 557, 5, NULL, 'Accusantium explicabo vel assumenda debitis illo eligendi cumque.', '2025-03-24 11:43:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (938, 324, 5, 1, 'Nisi ab exercitationem occaecati quae nisi enim quaerat impedit fugit necessitatibus.', '2024-06-08 13:00:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (557, 159, 5, NULL, 'Ab voluptatem libero nobis qui.', '2021-10-27 18:41:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (237, 237, 2, NULL, 'Aliquam esse necessitatibus dolor minus voluptatum.', '2023-04-28 22:35:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (885, 958, 3, NULL, 'Dignissimos quaerat perspiciatis repudiandae aliquid.', '2025-06-29 04:15:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (176, 210, 5, 4, 'Totam eaque illo facere provident inventore quod cum voluptatem quos quod.', '2023-01-24 03:33:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (128, 592, 1, 1, 'Necessitatibus voluptatibus ut ut ea esse accusamus.', '2023-12-30 21:05:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (950, 321, 1, NULL, 'Quae nisi alias eveniet voluptate architecto ipsum repudiandae labore.', '2025-02-01 18:16:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (592, 797, 2, 1, 'Ducimus architecto inventore velit et impedit deserunt fuga ut similique.', '2024-08-03 12:54:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (932, 825, 1, 2, 'Nesciunt debitis soluta corrupti consequuntur nisi fugit repellat ratione.', '2025-03-24 12:35:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (72, 729, 5, 5, 'Eligendi delectus assumenda velit iusto accusantium a maiores.', '2020-07-09 22:10:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (195, 521, 5, NULL, 'Magnam optio assumenda molestiae quae tempora temporibus.', '2022-12-27 06:44:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (385, 75, 1, 4, 'Culpa repellendus voluptatibus tenetur facere ut.', '2022-04-18 21:05:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (176, 202, 5, 2, 'Nobis aliquid aliquid fugiat officia voluptates quae recusandae quo.', '2021-05-15 03:17:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (918, 39, 2, 3, 'Fuga alias fuga nisi numquam provident eaque eos.', '2025-02-24 11:05:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (731, 104, 2, NULL, 'Occaecati iure voluptate optio corporis unde placeat voluptatibus.', '2025-05-13 15:27:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (618, 957, 1, 3, 'Pariatur accusamus inventore vero numquam.', '2022-05-10 03:21:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (402, 59, 5, 3, 'Praesentium suscipit quo eveniet sunt doloribus quo.', '2023-01-04 05:43:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (199, 3, 2, 4, 'Ratione labore nihil accusantium soluta soluta beatae.', '2020-08-01 07:06:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (537, 594, 3, 1, 'Corrupti aperiam architecto perferendis eos repellendus.', '2021-09-02 23:37:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (767, 644, 2, 5, 'Assumenda voluptate temporibus ea iusto molestiae aspernatur recusandae beatae quos.', '2022-03-22 02:38:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (463, 127, 3, 1, 'Autem nostrum adipisci corrupti nemo deserunt.', '2021-02-20 19:27:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (1, 457, 1, 2, 'Omnis porro laudantium mollitia nesciunt.', '2021-04-30 19:22:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (22, 917, 5, 5, 'Quis commodi non deleniti atque corrupti dignissimos voluptates sit.', '2025-06-23 22:47:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (642, 479, 2, NULL, 'Voluptatum vel quod cumque hic atque eius.', '2022-11-24 12:05:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (267, 318, 5, 5, 'Voluptas vel quasi dicta cum pariatur nesciunt.', '2021-09-03 18:42:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (100, 101, 3, 5, 'Odio vero enim assumenda molestiae cupiditate consequatur illo porro perspiciatis.', '2020-07-15 10:53:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (737, 73, 5, NULL, 'Quos iste distinctio nesciunt voluptatum quidem voluptatibus.', '2023-06-26 10:59:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (581, 594, 4, 1, 'Quia quae at necessitatibus aperiam.', '2023-05-12 02:03:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (608, 695, 3, 4, 'Laudantium nihil minima dolor consequuntur recusandae.', '2022-07-02 04:54:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (967, 8, 4, 5, 'Reprehenderit asperiores eius consequatur odio occaecati sit quis.', '2021-06-27 10:12:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (340, 512, 3, 5, 'Quisquam veniam dicta tempora nulla dicta fuga velit at.', '2022-07-12 10:41:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (917, 239, 1, 4, 'Tempora dolores fugit quasi vel.', '2025-02-21 19:47:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (886, 891, 4, NULL, 'Animi officia ducimus dignissimos neque porro hic soluta.', '2022-09-03 21:47:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (986, 631, 5, 1, 'Temporibus velit eos cum et accusamus facere ut iste aut.', '2025-01-20 15:21:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (351, 898, 1, NULL, 'Nemo fuga reprehenderit voluptatibus unde qui nostrum laboriosam fuga laudantium.', '2020-06-30 11:46:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (965, 9, 1, NULL, 'Dolorum distinctio perspiciatis sed praesentium quidem alias architecto recusandae.', '2020-08-30 23:26:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (79, 956, 3, 1, 'Quam nesciunt numquam adipisci placeat.', '2024-12-01 11:43:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (828, 434, 3, 1, 'Praesentium atque aliquam debitis voluptatem consequuntur voluptates.', '2025-04-17 12:44:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (659, 380, 5, 4, 'Quasi saepe minus perspiciatis consequatur voluptatum sed autem veniam.', '2021-04-07 09:54:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (405, 25, 1, NULL, 'Unde nisi esse odit dicta dignissimos odit repudiandae officiis.', '2020-01-16 04:51:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (448, 123, 2, 5, 'Natus illum suscipit quas inventore sapiente sint.', '2022-11-08 05:44:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (584, 475, 2, 1, 'Dicta recusandae pariatur facilis.', '2024-06-06 00:37:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (369, 809, 3, NULL, 'Molestiae iste voluptatem illum facilis quibusdam quasi sint numquam ratione.', '2020-03-12 18:37:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (384, 434, 2, 5, 'Praesentium nobis voluptates minima officiis labore deleniti laudantium nulla.', '2023-11-22 08:49:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (526, 497, 4, NULL, 'Veniam corporis praesentium voluptas quasi.', '2023-07-17 07:37:33');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (907, 264, 5, 5, 'Nulla voluptas soluta mollitia similique temporibus unde modi dignissimos veritatis eveniet.', '2024-03-22 13:59:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (485, 138, 1, 1, 'Quisquam cum impedit doloribus debitis.', '2021-06-15 13:03:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (604, 774, 4, 5, 'Perferendis voluptates quaerat labore quidem nihil eum facilis.', '2025-08-01 07:00:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (984, 460, 5, 1, 'Similique ipsam cupiditate adipisci rem quasi maiores impedit.', '2022-03-15 15:56:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (3, 52, 1, NULL, 'Inventore odit laboriosam eveniet adipisci nulla.', '2022-12-27 16:45:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (614, 440, 4, NULL, 'Et ipsa maxime quibusdam quaerat dolore sunt voluptate id.', '2023-05-03 22:10:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (198, 818, 1, NULL, 'Eum accusantium cumque voluptatum animi.', '2021-11-06 23:59:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (877, 69, 5, NULL, 'Aperiam reprehenderit quos tempora iusto cumque sed laborum doloremque repellat.', '2020-07-16 09:56:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (792, 93, 3, NULL, 'Eos dignissimos expedita eum ex ratione velit odio esse.', '2024-01-22 22:03:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (847, 960, 5, NULL, 'Animi explicabo alias porro maxime ratione.', '2022-12-11 00:58:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (410, 382, 5, NULL, 'Enim omnis ex consequuntur omnis necessitatibus enim dolorem animi nihil temporibus.', '2022-01-30 13:01:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (552, 942, 3, NULL, 'Vitae modi dolore a sequi non hic et nostrum.', '2022-06-22 12:08:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (609, 351, 5, NULL, 'Cumque est neque nobis ratione veniam.', '2021-06-27 11:24:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (300, 360, 3, 2, 'Ipsam eligendi accusamus dolore maiores tempora labore similique neque officia.', '2025-01-08 01:09:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (597, 905, 2, NULL, 'Veritatis excepturi maiores vitae repudiandae dolores minus consectetur incidunt reprehenderit.', '2022-05-31 20:20:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (266, 636, 1, NULL, 'Neque quo similique distinctio ea earum animi cumque perferendis accusantium.', '2021-10-05 23:04:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (207, 654, 2, NULL, 'Quia voluptas ratione sit ab vero aliquam nihil rem.', '2020-05-23 14:54:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (296, 374, 5, 4, 'Esse nisi libero id labore dignissimos.', '2024-12-19 12:04:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (168, 651, 4, 2, 'Numquam maiores eligendi recusandae aperiam.', '2022-07-25 11:22:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (207, 722, 2, 2, 'Perferendis laborum vitae nihil quasi voluptatum reprehenderit reiciendis impedit suscipit.', '2025-09-01 10:21:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (851, 199, 2, 5, 'Aperiam vel enim iure ipsam modi architecto.', '2021-12-28 21:42:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (105, 247, 4, 1, 'Aliquam incidunt quae porro error eos corrupti laudantium.', '2020-06-30 06:00:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (586, 67, 1, 3, 'Tempore hic quo temporibus vel animi eveniet nostrum quae est beatae.', '2024-04-30 11:27:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (738, 457, 3, 5, 'Excepturi rerum ipsam voluptates dolorem porro esse aliquid quo.', '2023-04-15 22:04:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (735, 339, 3, 1, 'Unde porro quis minus perspiciatis.', '2020-03-07 18:12:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (316, 93, 4, NULL, 'Sequi tempore dignissimos aliquam vero autem iure ipsam blanditiis.', '2023-04-30 02:49:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (63, 416, 4, 1, 'Similique sapiente consequuntur laboriosam necessitatibus provident.', '2023-11-11 05:06:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (425, 62, 5, 5, 'Quos quae nulla voluptates eum sint nulla.', '2025-07-30 11:41:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (998, 480, 3, NULL, 'Et porro ullam occaecati at.', '2022-07-09 06:47:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (68, 841, 5, NULL, 'Inventore odit illo dolor voluptatum cumque tempora laudantium quae.', '2024-12-25 08:18:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (556, 345, 5, 5, 'Dolorem perspiciatis quisquam iure autem maiores illo officia.', '2020-09-10 19:25:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (689, 10, 5, 3, 'Delectus perferendis consequuntur corrupti ratione unde laboriosam alias.', '2023-05-20 13:18:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (511, 702, 4, NULL, 'Iure numquam porro adipisci velit quidem libero iusto soluta amet.', '2024-12-31 14:50:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (794, 663, 2, 1, 'Dolores magni incidunt cumque vitae quos.', '2021-08-01 12:18:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (499, 841, 5, NULL, 'Et ipsa aut veritatis fugit ipsum sapiente.', '2022-07-13 08:02:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (239, 554, 3, NULL, 'Velit fugiat sequi perferendis iste laborum excepturi ipsum sapiente error.', '2022-04-18 16:27:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (136, 49, 1, 1, 'Placeat ea ratione culpa perspiciatis temporibus sit accusamus aut suscipit.', '2020-07-25 19:36:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (564, 884, 3, NULL, 'Adipisci tempora nesciunt eum rem sapiente quod ipsum inventore.', '2024-09-07 10:42:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (890, 671, 2, 2, 'Incidunt explicabo perferendis in.', '2025-03-25 15:57:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (135, 749, 5, NULL, 'Ab vero unde eum nostrum placeat libero quo aliquid esse.', '2021-11-06 02:00:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (173, 417, 2, NULL, 'Id veniam ab quaerat reiciendis.', '2021-12-05 00:08:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (590, 881, 3, NULL, 'Ab fugiat nemo voluptatibus quam placeat nam mollitia.', '2022-11-02 12:31:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (101, 874, 2, NULL, 'Expedita architecto culpa velit dignissimos ab.', '2020-12-01 04:47:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (221, 331, 1, 5, 'Soluta nemo ipsum provident eos quibusdam occaecati iste.', '2021-08-17 00:55:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (550, 923, 2, 3, 'Accusamus dolorem et eos nemo minus quas.', '2024-07-19 20:09:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (807, 298, 3, 4, 'Nihil blanditiis debitis modi ipsum.', '2025-03-10 03:47:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (632, 61, 4, 2, 'Corrupti natus blanditiis in saepe veritatis.', '2022-07-26 15:51:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (575, 595, 3, 3, 'Provident a architecto vitae dolores fuga tenetur.', '2022-03-11 03:29:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (659, 43, 5, NULL, 'Praesentium dolore enim sint quae.', '2022-04-19 19:36:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (855, 727, 3, 1, 'Quis accusamus dolore magni enim ex tenetur.', '2022-04-29 23:41:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (383, 104, 5, NULL, 'Atque dolores voluptatibus deleniti nemo.', '2021-03-04 16:57:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (547, 74, 4, NULL, 'Debitis temporibus fugit facere ex id labore error.', '2021-03-03 02:58:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (612, 601, 4, 3, 'Quidem nostrum incidunt qui optio necessitatibus consequuntur repellendus eveniet labore itaque.', '2023-06-10 08:55:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (210, 184, 5, NULL, 'Recusandae magni dolores dolores delectus quo.', '2023-02-16 07:15:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (650, 197, 3, 2, 'Incidunt quisquam quis repudiandae distinctio eius reprehenderit soluta molestias velit.', '2022-05-16 04:24:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (759, 329, 2, NULL, 'Molestias laudantium iusto corporis culpa tempora.', '2023-03-20 13:51:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (332, 958, 5, NULL, 'Suscipit nemo voluptate fuga laudantium ea.', '2020-08-26 22:40:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (693, 380, 5, NULL, 'Alias molestias eos veritatis facilis vel ullam eum.', '2021-11-09 08:24:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (852, 529, 4, NULL, 'Suscipit laudantium corporis iure sit animi provident omnis corporis quaerat.', '2022-05-28 13:38:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (619, 101, 3, 5, 'Error repudiandae omnis quo iste ut.', '2020-08-18 14:56:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (709, 614, 1, NULL, 'Commodi saepe ipsa maxime animi laboriosam.', '2020-10-15 12:29:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (566, 706, 5, 5, 'Ab voluptatum eveniet voluptatem id pariatur nemo.', '2025-09-16 13:36:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (495, 943, 4, NULL, 'Eius a labore dolorum delectus sed.', '2023-09-18 21:07:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (575, 31, 1, 5, 'Laboriosam asperiores aliquid minima voluptate esse ratione totam maiores tempora aut.', '2023-01-11 04:19:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (419, 222, 3, 4, 'Debitis enim excepturi laudantium quis quidem ut quae.', '2024-02-01 08:25:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (704, 903, 2, NULL, 'Quas veniam animi voluptates nostrum dolorem blanditiis omnis sint id.', '2024-08-08 05:07:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (560, 750, 2, NULL, 'Rem voluptatum cum deleniti at.', '2024-08-08 13:01:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (241, 943, 5, NULL, 'Facere similique unde facere recusandae animi animi neque ipsam sint.', '2023-05-15 16:36:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (952, 465, 4, 4, 'Eveniet tenetur totam nesciunt officiis ab laboriosam voluptas nesciunt quasi.', '2024-03-26 17:24:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (402, 760, 4, NULL, 'Aut et reiciendis quidem recusandae nostrum odit nam at.', '2025-09-07 06:39:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (73, 148, 5, 5, 'Unde fugit animi maiores facilis eos ut doloremque nesciunt repudiandae.', '2022-04-28 04:22:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (578, 603, 3, NULL, 'Minima dolor animi harum recusandae adipisci asperiores sit praesentium.', '2024-04-18 01:16:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (163, 950, 4, 1, 'Sunt illum exercitationem magni rem consequuntur cumque pariatur non eaque.', '2025-08-25 05:23:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (470, 184, 5, 3, 'Blanditiis voluptatibus fuga nesciunt laboriosam pariatur nemo.', '2020-04-20 23:34:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (972, 327, 5, NULL, 'Aut quibusdam ab qui provident nobis.', '2021-07-14 00:00:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (196, 393, 1, 5, 'Quod mollitia quam enim eius beatae.', '2023-02-02 07:11:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (231, 962, 1, NULL, 'Numquam eum id pariatur pariatur placeat.', '2024-10-22 11:56:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (922, 334, 2, NULL, 'Autem minus quibusdam quam sed.', '2023-12-10 01:23:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (890, 696, 5, 3, 'Facere eos perspiciatis omnis odio placeat veniam veniam.', '2025-09-21 22:33:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (566, 617, 3, NULL, 'Aliquid ea adipisci molestiae blanditiis temporibus.', '2023-10-13 09:06:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (516, 842, 5, 3, 'Quasi voluptatem tenetur nostrum quisquam.', '2025-08-11 21:42:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (262, 285, 3, NULL, 'Id excepturi cum nemo iusto ratione ex veritatis explicabo debitis.', '2022-03-01 12:37:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (677, 425, 5, NULL, 'Sapiente voluptatem vero corrupti amet.', '2021-06-28 23:42:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (19, 182, 3, 1, 'Provident vero labore aperiam voluptatibus nobis labore doloremque deleniti dolorem.', '2020-04-26 14:49:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (991, 679, 1, 5, 'Provident doloremque amet vitae assumenda et est.', '2020-08-13 22:52:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (237, 125, 4, NULL, 'Consectetur reprehenderit quae molestias.', '2022-04-18 10:14:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (697, 671, 4, 3, 'Distinctio ad magni consequuntur consequatur.', '2020-02-26 00:05:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (61, 502, 4, NULL, 'Facilis iure modi pariatur nemo officia autem placeat harum aperiam.', '2025-08-24 19:50:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (356, 426, 1, 1, 'Amet magni dolore nostrum dolore quos.', '2021-08-31 07:06:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (271, 527, 1, 1, 'Eaque velit provident repellat magni hic nisi qui quae amet.', '2024-04-07 18:47:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (214, 973, 1, 5, 'Qui harum distinctio quaerat dolorum facilis.', '2022-06-20 23:46:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (553, 908, 4, NULL, 'Molestiae beatae beatae aliquam atque velit illum omnis itaque dolorum.', '2023-01-09 09:27:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (62, 525, 3, 4, 'Recusandae et magni aliquam ipsa.', '2022-09-26 12:11:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (879, 966, 3, 4, 'Ea aut nam fugit magni mollitia.', '2024-05-24 03:33:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (943, 903, 3, 1, 'Sed deserunt numquam dolorem distinctio dolore minima quia debitis.', '2022-08-08 21:22:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (756, 4, 5, NULL, 'Molestias veritatis dignissimos omnis ipsam enim illum unde asperiores facere.', '2025-02-19 13:21:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (576, 137, 1, 5, 'Quisquam nisi itaque temporibus modi fugit fuga iure ducimus.', '2022-02-13 07:13:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (395, 258, 5, 1, 'Repudiandae ullam eaque delectus laudantium mollitia pariatur occaecati cum.', '2025-06-04 10:59:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (587, 136, 4, NULL, 'Quas quis iure suscipit harum magni repellendus blanditiis dolore.', '2020-07-28 17:21:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (652, 46, 5, 2, 'Enim perspiciatis neque sed veniam reprehenderit expedita voluptate eum molestiae.', '2021-10-23 18:52:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (888, 104, 4, NULL, 'Eius veritatis fugiat et aliquid harum asperiores inventore.', '2022-05-18 05:16:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (601, 618, 1, 1, 'Ipsam cupiditate assumenda rem accusantium repellendus sunt officiis.', '2021-07-24 03:29:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (845, 989, 2, 3, 'Aut deleniti fuga tenetur repudiandae unde.', '2025-04-15 15:25:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (688, 663, 4, 1, 'Similique iusto repudiandae voluptas ea debitis sapiente.', '2024-08-01 02:45:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (172, 118, 3, 3, 'Natus vitae aliquam modi qui consectetur possimus.', '2024-07-21 20:04:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (123, 95, 1, 2, 'Quam cumque autem necessitatibus et molestiae atque quidem deserunt at.', '2022-11-09 02:46:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (271, 585, 1, 3, 'Similique nulla nemo iure doloribus atque ipsa ab.', '2023-10-07 21:34:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (470, 283, 4, NULL, 'Placeat sequi voluptatem velit consequatur perspiciatis atque sapiente.', '2020-11-05 12:10:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (947, 833, 3, 3, 'Iure nihil cumque distinctio provident a quos laboriosam.', '2025-07-19 21:51:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (498, 893, 5, NULL, 'Itaque veniam debitis quae voluptates.', '2021-10-31 06:58:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (76, 73, 5, 5, 'Amet veniam omnis sint aliquid.', '2024-08-11 19:37:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (78, 480, 4, 3, 'Voluptatibus nisi quaerat veritatis quae.', '2025-06-01 15:34:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (410, 313, 2, NULL, 'Delectus enim consequatur qui quaerat natus ullam nihil.', '2021-12-26 18:02:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (1000, 620, 1, 4, 'Molestiae dolore est delectus et excepturi veniam.', '2021-08-05 03:12:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (797, 256, 2, NULL, 'Beatae fugit inventore pariatur architecto.', '2020-04-18 06:42:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (610, 235, 5, 1, 'Officia iste laudantium possimus tenetur quia omnis molestias explicabo.', '2025-06-26 10:49:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (811, 380, 5, NULL, 'Totam aut natus similique nostrum nulla sunt est.', '2021-07-25 23:21:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (167, 882, 5, 3, 'Unde reiciendis laudantium rerum a necessitatibus dicta quam consequatur accusantium eveniet.', '2020-01-23 15:53:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (105, 575, 3, 4, 'Fugit animi commodi magni alias.', '2021-08-18 07:12:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (369, 949, 4, NULL, 'Similique quia aut dolorum deleniti.', '2021-06-23 19:14:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (190, 226, 5, NULL, 'Porro recusandae dolores amet quam quae dolores facilis.', '2021-06-23 10:29:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (115, 922, 1, NULL, 'Quas aut ipsam repudiandae accusantium ratione minus sunt.', '2021-01-24 14:22:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (846, 131, 4, NULL, 'Incidunt sit sed excepturi ullam officiis laboriosam repellat laboriosam quis deserunt.', '2020-07-14 07:45:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (880, 973, 1, 3, 'Ex magni molestias sunt saepe quibusdam saepe quam dolor quibusdam.', '2022-09-13 22:18:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (1, 859, 3, 4, 'Quaerat ratione dicta culpa libero illo laborum inventore.', '2023-05-12 22:56:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (496, 153, 4, NULL, 'Est similique optio eaque ad sequi.', '2024-12-05 07:58:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (896, 389, 4, 5, 'Quo itaque inventore repellendus recusandae nisi.', '2022-01-11 23:12:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (351, 188, 4, 5, 'Quis atque minima error dolore.', '2020-07-04 16:23:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (257, 925, 5, 4, 'Maxime eveniet consequuntur corrupti cum eius inventore.', '2025-06-10 14:57:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (869, 177, 1, NULL, 'Facere voluptates laborum illum commodi sequi distinctio.', '2021-11-21 10:58:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (810, 496, 2, 1, 'Eum facere mollitia vel ullam consequatur quis sunt reiciendis.', '2023-10-30 10:52:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (775, 119, 3, NULL, 'Doloremque necessitatibus consequuntur repellendus nemo deleniti minus voluptates illum quaerat.', '2024-10-01 13:10:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (767, 330, 5, 1, 'Architecto a quo vero odit natus nemo ducimus at officia.', '2023-12-26 22:06:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (907, 150, 4, NULL, 'Dolores placeat odit veniam exercitationem.', '2023-12-15 00:27:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (360, 864, 5, NULL, 'Voluptatem natus ipsa asperiores voluptas.', '2025-02-07 17:31:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (90, 234, 5, 3, 'Velit dolorum corporis laborum laboriosam occaecati facilis nisi.', '2023-08-08 14:46:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (931, 123, 1, NULL, 'Voluptatem porro magnam libero cumque labore.', '2022-05-08 03:39:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (801, 928, 3, NULL, 'Ab laborum aperiam placeat voluptates consequuntur quisquam.', '2023-05-09 19:43:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (396, 687, 1, NULL, 'Repellendus placeat sequi quidem cupiditate quos nulla veniam repellendus.', '2020-12-06 11:47:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (760, 228, 5, 2, 'Veniam officiis est non laborum.', '2024-05-04 22:32:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (862, 10, 3, 1, 'Maiores qui ea enim accusantium facilis iusto ullam nisi.', '2020-02-22 20:57:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (129, 762, 5, NULL, 'Recusandae quasi qui culpa nostrum labore consequuntur quidem quam.', '2025-01-16 05:05:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (414, 642, 4, 5, 'Repellendus natus quia libero corporis.', '2022-04-12 00:19:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (354, 80, 5, 4, 'Commodi sed commodi ducimus vel dolores.', '2021-07-03 19:49:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (648, 609, 5, NULL, 'Molestiae ab maxime ullam quae ratione magni harum.', '2021-01-10 21:23:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (634, 286, 2, NULL, 'Cupiditate a accusantium reiciendis dolores corrupti iusto molestias.', '2023-09-11 02:14:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (179, 151, 3, NULL, 'Vitae eaque placeat placeat aspernatur voluptates consectetur eos iste unde.', '2022-07-28 03:19:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (121, 497, 1, NULL, 'Quasi iste eaque iusto sapiente aut.', '2024-10-02 23:24:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (926, 516, 5, 4, 'Iusto dolores esse molestias nemo ut qui tempora.', '2021-09-29 04:17:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (922, 777, 2, 4, 'Harum rerum ipsam cumque ducimus est.', '2023-07-04 13:22:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (114, 730, 3, NULL, 'Voluptate quisquam quas nisi soluta sapiente.', '2023-12-18 03:35:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (835, 996, 5, 1, 'In aliquam tenetur cupiditate deleniti minus voluptates maxime a deleniti ipsum.', '2022-05-12 16:07:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (704, 675, 3, NULL, 'Nihil quaerat aspernatur animi similique dolore error blanditiis.', '2021-09-12 18:44:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (497, 913, 3, 3, 'Ea reiciendis libero molestiae consectetur blanditiis repudiandae assumenda necessitatibus.', '2020-04-11 11:53:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (873, 951, 3, 3, 'Ullam ipsum vel totam autem eveniet velit officiis corporis sit.', '2023-12-12 16:45:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (472, 974, 1, NULL, 'Animi deleniti explicabo necessitatibus autem ducimus maiores.', '2023-12-09 11:28:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (233, 732, 1, NULL, 'Repellat nihil quidem nisi reprehenderit laboriosam quibusdam cupiditate reprehenderit vitae.', '2025-05-21 22:46:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (545, 539, 4, 5, 'At reiciendis et consequuntur minus nostrum reprehenderit eius.', '2023-07-13 14:40:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (327, 243, 3, NULL, 'Aut impedit amet numquam dicta.', '2025-08-26 11:27:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (109, 949, 2, NULL, 'Animi autem nobis eum odio quam id aliquam repellendus in.', '2023-02-16 03:02:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (497, 501, 3, NULL, 'Ut inventore deserunt nobis nesciunt officia veritatis quibusdam.', '2022-01-15 13:14:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (395, 546, 2, NULL, 'Modi at delectus fugit omnis iure nihil ex quam dicta.', '2023-03-13 17:43:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (835, 951, 4, NULL, 'Similique placeat cum ex natus mollitia culpa repellendus.', '2023-11-07 06:48:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (706, 438, 2, NULL, 'Dolorem impedit optio iste iure nostrum consequatur ex consequuntur.', '2022-04-18 04:00:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (53, 538, 3, NULL, 'Mollitia eius natus natus dolores consequuntur dolore deserunt tempora officiis.', '2024-05-15 09:25:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (41, 646, 4, 5, 'Sequi aliquid dolores magni consectetur.', '2022-03-10 05:14:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (967, 793, 2, NULL, 'Maiores fuga facilis placeat nemo pariatur quia facere excepturi.', '2024-07-17 10:43:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (866, 566, 1, 1, 'Doloribus aspernatur eius consectetur recusandae necessitatibus.', '2025-08-26 02:04:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (58, 994, 1, NULL, 'Voluptas minima repellendus vel excepturi iste fugiat aspernatur ad non.', '2025-04-13 07:06:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (927, 855, 3, NULL, 'Odio rerum debitis error alias quos autem.', '2025-04-08 15:21:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (706, 823, 5, NULL, 'Veritatis sit iusto reiciendis architecto veritatis ad.', '2024-04-04 18:27:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (155, 531, 3, NULL, 'Velit porro neque adipisci optio explicabo.', '2022-06-19 19:26:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (170, 96, 4, NULL, 'Fuga velit iusto beatae ducimus aperiam deleniti repellendus at temporibus.', '2025-04-02 07:34:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (26, 78, 5, 3, 'Tenetur commodi quasi quia incidunt enim numquam nemo laboriosam repudiandae.', '2024-12-07 18:12:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (557, 268, 1, 3, 'Officiis repudiandae reiciendis necessitatibus ipsam perferendis.', '2022-11-26 04:25:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (701, 760, 4, 3, 'Quisquam facilis quos reiciendis illo nulla.', '2025-07-23 03:32:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (343, 263, 5, 3, 'Ducimus quo blanditiis totam itaque distinctio provident ab.', '2020-02-15 01:23:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (615, 736, 5, 1, 'Corporis ab ratione debitis iste dolore eligendi non dolore.', '2023-10-19 22:16:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (466, 914, 1, 3, 'Eaque assumenda dolorem repudiandae debitis harum eos assumenda placeat aut.', '2022-03-27 17:55:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (454, 62, 2, NULL, 'Voluptatem ratione laudantium nam quam ad.', '2024-04-04 16:15:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (587, 113, 3, 1, 'Officia libero omnis fugiat mollitia rem maxime maxime.', '2021-09-13 16:17:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (682, 211, 4, NULL, 'Nulla amet minima delectus soluta dolores laborum quasi.', '2024-02-14 19:05:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (657, 608, 1, NULL, 'Deserunt architecto sunt mollitia dicta.', '2021-03-30 16:13:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (757, 21, 5, 4, 'Cupiditate quia neque totam nemo eius incidunt.', '2022-07-03 11:41:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (970, 146, 4, 3, 'Voluptate officiis atque dolores maiores quia suscipit atque vero suscipit qui.', '2020-07-16 21:07:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (214, 335, 2, 2, 'Placeat quas neque quaerat ipsa magni asperiores exercitationem ut quos cupiditate.', '2022-10-25 13:07:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (668, 253, 4, NULL, 'Repellendus voluptatem perspiciatis aut quos.', '2020-02-02 21:26:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (204, 908, 3, 5, 'Labore rem dignissimos laboriosam sit nemo beatae consectetur.', '2024-10-07 22:27:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (519, 364, 2, 1, 'Totam commodi vel mollitia distinctio neque amet enim ducimus.', '2023-11-15 18:01:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (396, 863, 1, NULL, 'Laboriosam voluptatem consectetur adipisci dicta inventore asperiores numquam quia.', '2021-12-17 01:01:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (4, 297, 5, NULL, 'Rerum at pariatur aperiam earum autem dicta adipisci veniam fuga.', '2021-09-25 10:42:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (851, 31, 4, NULL, 'Exercitationem dolorum magni nisi optio in incidunt numquam.', '2021-05-10 23:53:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (243, 559, 5, 1, 'Provident provident nam voluptatum soluta itaque nihil.', '2020-09-07 11:03:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (905, 265, 5, 2, 'Odio error ex sapiente sunt ipsum a.', '2022-04-30 06:10:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (937, 929, 4, NULL, 'Illo officia eum animi totam repellat maiores perspiciatis explicabo.', '2024-05-15 19:41:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (207, 31, 1, 1, 'Maiores temporibus ab animi eveniet.', '2024-06-20 10:29:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (682, 93, 4, NULL, 'Id aperiam accusamus quod minus ipsa.', '2020-07-01 15:18:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (174, 290, 3, NULL, 'Veritatis iusto alias eos vitae illum deserunt ipsa asperiores.', '2024-08-08 11:08:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (595, 306, 2, 1, 'Laboriosam commodi iure facere distinctio quasi illo voluptatibus.', '2021-07-04 16:23:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (126, 878, 2, NULL, 'Perspiciatis accusamus qui voluptates quod id exercitationem iure.', '2023-04-20 00:27:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (209, 800, 5, 3, 'Libero ratione nostrum nisi sit suscipit neque accusamus.', '2023-03-22 21:53:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (290, 148, 4, NULL, 'Expedita velit nihil enim temporibus.', '2022-08-19 06:51:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (948, 84, 1, 1, 'Corrupti dolor impedit dolores nostrum cum culpa ex.', '2021-02-15 10:41:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (241, 366, 5, NULL, 'Vero laudantium error aut nulla magni.', '2021-07-20 17:22:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (108, 297, 3, 5, 'Laudantium dicta ea inventore aperiam quos.', '2024-12-04 02:53:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (258, 777, 5, 2, 'Mollitia vitae architecto nesciunt maxime.', '2024-01-30 08:06:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (964, 381, 2, 5, 'Incidunt culpa asperiores optio aliquid quisquam laborum delectus soluta id.', '2024-10-16 08:16:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (291, 719, 5, NULL, 'Debitis velit quod nobis fugiat labore ea asperiores eaque.', '2025-06-28 09:57:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (840, 225, 3, 3, 'Repellendus nulla facere quo hic quis sunt nobis.', '2023-03-02 00:18:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (334, 738, 2, NULL, 'Esse nobis quos perspiciatis omnis nam aliquid vel.', '2022-04-04 20:17:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (651, 184, 1, 5, 'Nostrum quidem tempore odit illum dolorem itaque explicabo veritatis similique.', '2020-07-23 18:56:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (316, 14, 5, 4, 'Placeat exercitationem at neque nobis nesciunt quam.', '2024-04-18 13:30:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (416, 232, 3, NULL, 'Qui sequi ipsam corrupti sequi itaque cumque.', '2022-08-21 23:30:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (359, 707, 4, 3, 'Explicabo illum omnis magni a pariatur id odit cupiditate amet magnam.', '2023-12-15 22:53:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (45, 265, 1, 1, 'Similique voluptatem quos velit possimus molestias doloribus ut fuga labore.', '2023-05-25 20:13:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (494, 283, 5, 5, 'Officiis ullam enim hic animi eaque.', '2024-09-03 18:47:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (632, 760, 1, NULL, 'Adipisci pariatur consequuntur quasi quae consequuntur ad consectetur.', '2020-08-26 18:33:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (888, 588, 3, 4, 'Rerum nihil quasi veritatis ipsam officiis tempora.', '2024-01-19 18:28:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (186, 702, 4, NULL, 'Eum quisquam saepe sequi eveniet.', '2020-01-09 22:36:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (514, 222, 1, 3, 'Quod ut cumque ab adipisci ad.', '2023-08-24 14:49:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (49, 489, 3, 3, 'Quidem necessitatibus sapiente eos quod.', '2020-05-29 17:04:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (966, 260, 2, 5, 'Excepturi numquam doloribus cumque cum.', '2023-08-12 15:57:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (191, 389, 4, NULL, 'Tempore provident porro debitis assumenda.', '2025-06-09 13:55:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (995, 813, 1, NULL, 'Dolorum nulla aliquam at at consequatur.', '2021-02-07 13:26:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (888, 183, 5, 3, 'Voluptas veniam cupiditate dolorum aliquam nihil non.', '2022-10-02 05:06:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (965, 164, 4, NULL, 'Praesentium ea asperiores quam vero molestias repellendus.', '2021-07-21 08:26:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (986, 76, 5, NULL, 'Totam iste magni atque quibusdam harum accusantium.', '2025-04-26 02:38:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (627, 514, 4, NULL, 'Et laborum eaque nemo nobis dolore.', '2023-04-10 06:15:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (685, 532, 4, 5, 'Doloremque officia ab eveniet occaecati quis ad est architecto quo incidunt.', '2022-01-07 00:08:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (164, 901, 3, 2, 'Est praesentium voluptates laudantium quo omnis quis consequuntur incidunt numquam sunt.', '2022-08-18 17:23:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (817, 159, 3, NULL, 'Voluptatum fugiat excepturi similique hic.', '2023-08-16 03:30:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (805, 947, 5, 1, 'Velit nostrum dolores id animi aspernatur quo odit earum.', '2025-09-05 07:29:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (595, 30, 4, NULL, 'Nobis delectus saepe officia voluptate corrupti.', '2021-07-17 04:11:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (442, 670, 5, 3, 'Doloremque atque quisquam nesciunt magni cumque corrupti libero eligendi eligendi.', '2025-05-26 08:39:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (961, 430, 5, NULL, 'Non suscipit provident quos animi et distinctio ratione quaerat.', '2025-01-14 02:29:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (96, 581, 5, 1, 'Excepturi temporibus maxime minus voluptatibus.', '2022-09-03 18:13:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (972, 603, 4, 5, 'Ea odio veniam error atque.', '2022-10-28 21:12:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (365, 667, 5, NULL, 'Autem autem quibusdam aspernatur neque voluptas aperiam impedit.', '2023-10-10 07:37:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (988, 670, 5, 5, 'Neque repellendus illo quas.', '2022-11-21 02:04:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (125, 377, 2, NULL, 'Tempora ratione veniam adipisci iusto nam inventore delectus nesciunt blanditiis quos.', '2020-08-14 18:34:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (594, 667, 4, NULL, 'Animi cupiditate laboriosam cum tenetur ipsa a reiciendis aliquid ullam.', '2022-01-15 04:30:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (453, 67, 4, 5, 'Et vitae aspernatur omnis vitae beatae.', '2021-04-04 19:39:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (957, 221, 2, 2, 'A accusamus modi ducimus odio maxime maiores.', '2022-12-31 16:19:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (303, 258, 3, 4, 'Voluptatum cupiditate quae quod autem laborum pariatur beatae minus perferendis.', '2024-08-02 18:50:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (803, 777, 4, NULL, 'Nisi hic doloremque aperiam exercitationem.', '2021-05-14 07:17:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (946, 512, 3, NULL, 'Facilis deleniti repellendus voluptatum.', '2025-05-09 03:04:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (983, 391, 2, NULL, 'Praesentium tempore est esse cumque.', '2022-04-16 10:28:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (655, 413, 4, 5, 'A porro fugit sed aliquam nobis consequuntur cum quam optio.', '2023-12-27 19:51:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (450, 473, 5, 1, 'Nulla at blanditiis molestiae porro.', '2020-01-20 04:19:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (917, 667, 1, 4, 'Dicta exercitationem eligendi hic porro vel.', '2022-04-18 19:46:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (727, 86, 2, NULL, 'Quo at facilis vel aspernatur aperiam.', '2024-05-12 07:11:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (153, 843, 1, 4, 'Illo numquam incidunt dicta explicabo quaerat voluptates quo fugit.', '2020-01-21 03:43:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (548, 979, 4, NULL, 'Deserunt architecto laboriosam velit consequatur nemo rem eius ex fuga.', '2023-07-09 04:33:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (239, 78, 2, NULL, 'Molestias et doloremque quis aliquam odit consequuntur.', '2022-04-01 06:48:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (669, 672, 3, NULL, 'Consectetur ea repellendus sunt odio dicta.', '2023-04-29 09:10:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (751, 215, 2, 5, 'Placeat minus debitis commodi in.', '2023-05-31 11:20:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (259, 874, 4, 3, 'Accusantium ab aperiam natus.', '2020-07-30 04:19:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (917, 564, 5, 4, 'Deserunt dolores commodi molestias perferendis dicta repudiandae illum sunt.', '2025-06-04 19:59:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (701, 262, 5, NULL, 'Nisi maiores alias labore cum pariatur voluptatem quaerat delectus provident.', '2021-06-24 02:01:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (662, 855, 3, 5, 'Sit omnis sunt accusamus veritatis corrupti.', '2022-01-18 15:03:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (777, 16, 2, NULL, 'Molestias cum natus harum consequuntur.', '2020-01-01 09:55:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (89, 540, 4, 4, 'Fuga optio at minima aut earum reiciendis.', '2022-06-25 19:38:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (220, 102, 5, 3, 'Tenetur fugit repudiandae quae eaque aut ducimus ullam et.', '2020-08-31 13:16:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (854, 138, 3, NULL, 'Qui facere nobis nisi quae deleniti voluptatem enim aspernatur.', '2022-02-18 09:40:32');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (792, 913, 5, NULL, 'Quam nobis explicabo blanditiis perspiciatis quia architecto distinctio.', '2022-01-31 13:30:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (411, 224, 4, NULL, 'Error modi repellat dolore vitae neque consequatur.', '2020-08-30 22:44:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (526, 178, 2, 4, 'Sapiente perspiciatis est magnam distinctio placeat officia dolore.', '2020-07-14 11:30:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (237, 344, 2, NULL, 'Cum magnam commodi tempore qui.', '2023-08-03 03:12:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (864, 373, 1, NULL, 'Cumque voluptatum quas quaerat quidem.', '2023-02-20 04:02:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (751, 479, 2, 3, 'Laboriosam voluptatibus magni repudiandae occaecati dolores quaerat ratione.', '2021-02-09 15:30:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (570, 605, 3, NULL, 'Magnam aliquam consequuntur molestiae tempore adipisci quasi repellat debitis recusandae.', '2020-04-28 10:39:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (150, 746, 3, NULL, 'Dolor sunt totam dolor omnis voluptatibus eveniet nesciunt.', '2024-10-30 10:36:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (687, 29, 2, NULL, 'Sed illum veniam dicta assumenda fuga eius nihil quo.', '2025-02-14 02:36:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (721, 370, 1, 2, 'Animi ipsum dolores voluptate voluptatem tempore illum.', '2021-09-21 18:16:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (400, 376, 4, 1, 'Minima tempora error adipisci qui sunt earum consequatur nisi incidunt.', '2020-01-11 06:46:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (532, 207, 4, NULL, 'Aut ea aliquam voluptatem nisi impedit dolorum eveniet.', '2021-04-26 13:59:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (339, 146, 3, 3, 'Eligendi reprehenderit beatae illum doloribus eveniet dolore illo.', '2020-04-10 02:27:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (893, 961, 1, NULL, 'Ab aperiam inventore ratione soluta asperiores inventore nisi.', '2022-05-15 21:12:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (9, 892, 4, 4, 'Eum ex aliquid perspiciatis earum magni expedita at maxime.', '2020-11-23 10:20:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (426, 540, 1, NULL, 'Ea fuga delectus sequi natus porro soluta reprehenderit.', '2024-06-26 11:38:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (738, 727, 4, 2, 'Consectetur enim corporis libero.', '2022-03-16 08:38:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (477, 661, 5, NULL, 'Sapiente explicabo eveniet doloremque suscipit quis ratione et.', '2024-05-31 21:48:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (665, 751, 3, NULL, 'Ullam voluptatum autem quidem velit similique accusantium.', '2021-05-20 19:24:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (449, 48, 1, NULL, 'Occaecati sint nisi quidem tempora cum corporis neque.', '2020-03-26 07:47:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (395, 715, 4, 3, 'Hic sed aspernatur molestias quo consectetur distinctio et vel quis.', '2022-05-07 19:45:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (874, 604, 5, NULL, 'Quasi rerum sit consequuntur quam aliquid autem ducimus tenetur ea.', '2022-12-04 01:02:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (742, 994, 4, NULL, 'Vel saepe rerum minus excepturi fuga error repellendus eligendi.', '2022-06-19 07:51:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (324, 59, 3, NULL, 'Quod cum incidunt qui assumenda modi debitis in.', '2022-05-24 04:46:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (580, 118, 4, NULL, 'Saepe voluptates alias aspernatur ipsa quaerat.', '2024-01-09 05:11:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (41, 362, 3, 5, 'Qui molestiae debitis magnam sapiente tempore at sit eaque quod.', '2020-10-18 01:32:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (949, 379, 5, 2, 'Aut distinctio ipsum esse eaque facere.', '2020-05-09 12:18:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (574, 737, 4, 4, 'Unde consequatur possimus eligendi mollitia alias ipsum deserunt debitis.', '2024-03-09 20:49:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (41, 79, 1, NULL, 'Vel laudantium atque eligendi temporibus.', '2021-12-25 05:34:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (358, 817, 4, NULL, 'Animi nostrum aliquam voluptate molestias beatae.', '2020-12-25 09:58:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (156, 608, 4, 4, 'Voluptatum vero non enim.', '2023-08-15 18:02:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (944, 222, 3, NULL, 'Repellat reprehenderit voluptatum numquam sed minus magnam.', '2022-09-07 09:42:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (379, 963, 5, NULL, 'Asperiores optio mollitia mollitia esse quo quia quas.', '2024-06-15 09:48:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (541, 190, 3, NULL, 'Impedit amet eius ad ratione.', '2024-06-13 04:55:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (666, 180, 4, NULL, 'Omnis sunt laudantium odit.', '2023-01-09 11:50:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (890, 92, 5, 3, 'Labore magnam neque excepturi sit reiciendis maxime iste.', '2024-12-24 06:22:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (911, 932, 3, 1, 'Consequuntur voluptate iure impedit.', '2024-03-02 12:51:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (137, 536, 3, NULL, 'Omnis cupiditate maxime adipisci tenetur sit dignissimos neque architecto ratione.', '2020-02-18 21:58:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (720, 864, 5, 2, 'Culpa commodi nobis ea dolorum.', '2021-12-02 13:54:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (210, 311, 3, NULL, 'Quaerat iusto doloribus deleniti voluptatem.', '2023-02-22 10:36:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (597, 127, 3, NULL, 'Ex nulla debitis voluptatum eveniet aspernatur.', '2022-05-14 09:59:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (488, 886, 1, NULL, 'Voluptatibus architecto nemo dolores sit fugiat suscipit inventore accusantium necessitatibus.', '2022-09-17 16:51:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (324, 384, 1, NULL, 'At unde ipsum beatae velit qui magni.', '2022-08-20 03:15:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (920, 124, 5, NULL, 'Consequatur officiis totam voluptatum delectus expedita dicta molestias.', '2022-12-14 13:33:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (159, 260, 4, NULL, 'Nam fugit amet debitis nostrum eaque consectetur.', '2023-08-27 21:09:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (866, 817, 4, NULL, 'Aliquam cupiditate delectus ullam ab.', '2023-06-05 20:41:31');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (531, 631, 3, NULL, 'Illo porro nihil quis veritatis asperiores.', '2023-01-09 19:51:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (580, 704, 1, 5, 'Odio nihil eius nam facilis necessitatibus.', '2021-04-10 15:07:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (404, 167, 5, NULL, 'Excepturi officia enim officia ex minima minima autem deserunt.', '2023-06-16 21:04:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (527, 634, 4, NULL, 'Rem fugiat rerum aliquam velit sunt reiciendis tempore vel eum nobis.', '2020-10-18 17:45:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (685, 939, 4, NULL, 'Perferendis ullam dolor ratione voluptate vero eveniet quia debitis.', '2020-08-31 08:07:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (438, 923, 4, NULL, 'Dolorem molestias nisi expedita dolor veritatis minima voluptate nihil.', '2020-09-07 11:03:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (924, 766, 4, 3, 'Optio cumque occaecati placeat et soluta ratione.', '2024-10-24 02:00:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (941, 51, 1, 1, 'Magni earum sint dolorum architecto iure perspiciatis ullam cum.', '2023-08-28 08:50:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (124, 527, 4, NULL, 'Aspernatur nam similique dolor blanditiis minima cum officia illo.', '2022-01-17 00:51:20');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (326, 985, 3, 4, 'Molestiae quasi eveniet perferendis magni maxime.', '2025-06-05 05:26:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (510, 816, 5, 4, 'Ipsum quisquam deleniti sunt similique dolor animi id corporis alias.', '2022-12-02 13:40:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (361, 271, 1, NULL, 'Unde dolorum cum odit alias ad.', '2020-10-16 18:19:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (871, 803, 2, 2, 'Pariatur excepturi eos distinctio necessitatibus dignissimos sunt rerum.', '2023-07-06 13:20:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (454, 283, 4, NULL, 'Placeat quaerat temporibus libero est aliquid ipsum harum dolorum vel.', '2024-11-25 15:47:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (181, 429, 5, 4, 'Accusamus repudiandae nostrum fugiat illo fugiat labore tempora.', '2021-03-18 18:18:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (434, 493, 5, 1, 'Porro laboriosam magni dolore ad natus qui quam inventore a.', '2025-04-04 09:35:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (62, 735, 3, 4, 'Aspernatur fugit dignissimos nulla aut vero distinctio reiciendis.', '2022-01-26 05:50:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (914, 730, 3, 3, 'Asperiores illum dicta aperiam eligendi odit ducimus.', '2020-11-22 11:16:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (455, 536, 2, NULL, 'Soluta reprehenderit a ratione cupiditate corrupti.', '2022-07-10 06:52:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (344, 587, 3, NULL, 'Perspiciatis vero illum culpa atque.', '2023-04-13 13:20:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (670, 497, 1, 5, 'Molestias mollitia assumenda impedit amet nobis aperiam mollitia ab.', '2022-10-29 11:30:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (58, 635, 1, 5, 'Voluptatem harum fuga quam optio illum laudantium id.', '2023-01-09 15:32:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (788, 880, 3, 5, 'Laboriosam consequuntur iste quaerat quia modi.', '2020-05-18 16:20:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (305, 875, 2, 4, 'Iste fugit harum facilis atque debitis veniam aliquam vel.', '2023-07-14 19:37:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (106, 308, 4, NULL, 'Nemo consequuntur atque id eveniet suscipit dicta eius odio.', '2021-08-04 14:48:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (747, 56, 3, NULL, 'Alias veritatis quo eius voluptate at quas.', '2024-01-09 23:27:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (691, 542, 1, NULL, 'Voluptatum quisquam quis est tenetur atque.', '2023-08-12 08:17:22');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (2, 398, 1, NULL, 'Commodi nobis officiis laboriosam corrupti.', '2022-07-08 22:00:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (560, 795, 3, 5, 'Accusantium accusantium alias est quia.', '2022-07-17 06:02:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (565, 436, 5, 2, 'Eligendi iure aut nam deleniti inventore voluptas sequi harum.', '2020-02-15 04:58:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (226, 675, 4, NULL, 'Maxime a distinctio eaque sed.', '2020-09-29 22:55:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (960, 428, 4, 5, 'Nulla aut beatae minus cumque animi libero reprehenderit velit.', '2020-07-05 04:24:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (265, 107, 1, NULL, 'Iure voluptatibus ipsum sunt voluptate.', '2022-08-16 07:41:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (40, 529, 5, 3, 'Minima dolorum eveniet non culpa est aperiam vitae.', '2024-03-21 08:37:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (818, 884, 3, NULL, 'Non cupiditate aut voluptate itaque.', '2022-01-17 13:48:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (544, 303, 1, 2, 'Excepturi ipsam minima voluptatibus ipsa praesentium modi fuga sed.', '2020-07-07 13:42:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (614, 676, 5, 3, 'Beatae mollitia quidem cum quam.', '2021-09-16 16:59:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (59, 512, 2, 3, 'Neque voluptate veniam ea laboriosam illum esse quaerat sequi.', '2021-09-12 02:13:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (952, 937, 4, 1, 'Tenetur animi perferendis ducimus pariatur.', '2023-06-25 19:38:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (788, 936, 5, NULL, 'Molestias officia illum nihil est nulla.', '2022-01-13 03:32:45');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (545, 922, 3, 4, 'Animi tempora aliquid corporis adipisci ad rerum qui accusantium.', '2023-09-02 11:18:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (239, 90, 5, NULL, 'Unde quod consequuntur repudiandae ipsam molestiae.', '2023-04-28 01:29:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (492, 756, 3, NULL, 'Necessitatibus quaerat illum iste nisi.', '2025-08-20 09:46:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (891, 153, 1, 5, 'Ducimus aliquam porro harum doloremque maiores dolores cumque.', '2022-12-19 09:35:49');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (31, 693, 3, NULL, 'Vitae cumque quas rerum voluptate veniam inventore ex quasi voluptatum.', '2023-03-07 13:48:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (916, 88, 2, NULL, 'Facere vero tenetur voluptates necessitatibus distinctio dolorum.', '2022-11-09 10:27:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (916, 930, 1, NULL, 'Expedita delectus non officia aperiam nam sunt quo alias.', '2024-04-19 17:40:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (344, 940, 2, NULL, 'Doloremque suscipit maxime sequi ipsum.', '2020-03-31 22:44:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (573, 254, 4, 2, 'Cumque unde vero optio a quis.', '2023-12-29 15:19:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (724, 798, 5, NULL, 'Molestiae accusantium quasi debitis minus occaecati vel mollitia in excepturi quaerat.', '2025-08-13 03:47:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (463, 508, 2, 4, 'Blanditiis deserunt laudantium assumenda iste.', '2024-07-25 00:07:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (586, 641, 1, NULL, 'Perferendis velit incidunt dolorum repudiandae sit impedit officiis.', '2020-01-14 03:13:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (153, 993, 4, NULL, 'Minus facilis minus blanditiis vero nisi magnam harum odio.', '2020-02-24 16:27:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (355, 687, 3, 1, 'Ad quos iusto quisquam nobis vel id aspernatur.', '2021-04-02 12:59:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (929, 415, 2, NULL, 'Recusandae laboriosam porro fugiat libero vel mollitia expedita amet.', '2023-12-24 20:07:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (333, 61, 2, 1, 'Delectus sint iste quod totam accusantium amet.', '2024-11-15 05:30:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (872, 995, 4, 4, 'Fuga recusandae corrupti sed sed aut a hic soluta.', '2024-12-08 19:40:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (435, 254, 1, 4, 'Officia totam earum nobis fuga consequuntur est expedita.', '2025-04-07 10:20:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (829, 330, 3, 1, 'Vero qui sed quae dolor illum.', '2021-10-10 21:25:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (687, 635, 4, NULL, 'Quae consectetur corrupti eaque delectus.', '2020-09-06 11:08:41');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (48, 554, 5, 2, 'Saepe inventore quibusdam totam debitis.', '2025-05-12 17:58:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (858, 710, 4, NULL, 'Placeat beatae exercitationem quaerat iste eius neque ducimus nesciunt.', '2020-06-06 06:26:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (812, 966, 2, NULL, 'Consequatur non illum iste nemo magnam esse cupiditate odio amet labore.', '2022-07-09 17:25:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (338, 738, 5, 5, 'Ullam deleniti omnis quaerat ipsa laborum fugit commodi.', '2020-02-04 10:39:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (561, 813, 2, NULL, 'Iure placeat repellat itaque distinctio exercitationem nihil ipsam deleniti.', '2022-05-15 01:56:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (669, 788, 1, NULL, 'Quia molestiae voluptate nisi facere eius harum iure totam debitis.', '2022-05-23 15:42:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (315, 825, 4, 4, 'Rem est autem nihil sunt id incidunt.', '2021-04-18 15:12:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (59, 997, 1, NULL, 'Error cupiditate cum minus fuga accusamus excepturi culpa maiores.', '2022-05-03 13:48:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (331, 786, 5, NULL, 'Sunt fuga nostrum libero nesciunt repudiandae asperiores esse itaque est ullam.', '2024-08-25 02:35:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (337, 825, 4, NULL, 'Saepe ea nostrum incidunt non quibusdam ducimus aut est aut ex.', '2021-02-03 06:12:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (954, 419, 2, NULL, 'Repudiandae consequatur quasi assumenda dicta repellat dicta modi ipsa expedita.', '2020-08-21 17:14:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (247, 834, 1, 4, 'Cumque expedita minima provident delectus fugiat a reprehenderit fugit harum.', '2023-12-02 09:35:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (807, 372, 1, 5, 'Aspernatur voluptas minima ratione necessitatibus quis minus dolor.', '2025-06-09 08:28:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (976, 225, 3, NULL, 'Alias enim quo dolores atque corrupti velit asperiores deleniti suscipit numquam.', '2024-09-28 14:01:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (308, 524, 5, 4, 'Illum voluptatem numquam recusandae.', '2020-04-29 02:48:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (577, 70, 4, NULL, 'Distinctio quae laudantium neque veniam totam aliquam.', '2020-10-07 23:02:02');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (592, 45, 5, NULL, 'Error alias aperiam odio occaecati quos.', '2023-10-05 20:47:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (313, 87, 2, 5, 'Molestias numquam molestiae commodi officiis doloribus earum.', '2023-02-21 06:33:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (125, 141, 3, 4, 'Delectus neque et vero veritatis maiores unde asperiores.', '2020-08-26 10:56:42');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (660, 553, 1, 2, 'Nisi distinctio minima unde nesciunt veniam.', '2023-08-24 13:45:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (202, 784, 4, 5, 'Sunt praesentium exercitationem dolorum voluptatem id.', '2021-03-04 08:58:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (830, 578, 4, 5, 'Voluptatum illo rerum pariatur laboriosam delectus sapiente aspernatur.', '2021-08-27 06:15:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (257, 820, 4, 5, 'Reiciendis dolorem sapiente eveniet pariatur labore deleniti veniam fuga sed.', '2020-07-02 01:32:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (991, 392, 2, NULL, 'Molestias adipisci rerum veniam autem dolores ipsum tempore velit.', '2024-12-25 03:19:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (742, 165, 2, NULL, 'Suscipit voluptatem quidem accusamus voluptates asperiores tempore.', '2025-05-05 22:58:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (561, 189, 3, 2, 'Vel ducimus numquam tempore quo labore.', '2022-08-03 16:14:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (564, 138, 5, NULL, 'Cupiditate soluta magnam dolore commodi autem laboriosam cumque voluptate expedita.', '2021-02-04 04:00:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (284, 365, 3, NULL, 'Maiores perferendis earum repellat saepe consectetur.', '2024-10-14 01:26:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (856, 289, 5, NULL, 'Illum distinctio hic necessitatibus vero facilis.', '2023-02-02 05:23:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (227, 263, 3, NULL, 'Officiis provident possimus aperiam earum odio eveniet praesentium necessitatibus dolor.', '2021-11-27 03:55:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (11, 204, 5, 4, 'Reprehenderit ut aliquid architecto ipsam corrupti perspiciatis.', '2025-02-26 02:58:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (384, 138, 5, 5, 'Quia ex tempora optio sapiente.', '2021-05-27 01:17:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (857, 221, 2, 4, 'Repellat ipsum aliquam veniam reiciendis ipsam ullam sit nulla dicta.', '2022-08-01 20:36:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (476, 903, 3, 4, 'Doloribus asperiores unde placeat.', '2021-07-12 05:55:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (882, 227, 2, 1, 'Quos facilis omnis quia exercitationem.', '2023-11-12 04:52:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (821, 45, 5, 1, 'Vel similique voluptates non nobis vel.', '2024-12-17 07:54:04');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (105, 849, 1, NULL, 'Non quisquam illum id odio.', '2024-04-23 15:39:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (165, 285, 1, 4, 'Molestias quidem quo sequi iusto magni neque aspernatur.', '2025-05-15 00:51:53');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (476, 664, 2, 5, 'Tempore magnam culpa magni dignissimos doloribus illo ex aliquid quos.', '2023-06-14 16:23:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (401, 561, 1, 5, 'Rerum aut alias deserunt minima quisquam facere nam.', '2020-03-05 19:49:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (153, 225, 4, 2, 'Consequatur itaque voluptatem dignissimos quae reiciendis eius eius.', '2025-05-25 16:02:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (511, 775, 3, 3, 'Numquam facere earum iste eaque ad dicta.', '2023-03-30 23:27:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (67, 434, 1, 1, 'Iste repellat eveniet at quidem repudiandae.', '2020-06-07 17:13:19');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (576, 256, 2, NULL, 'Aspernatur corrupti illum possimus beatae id accusamus perferendis.', '2021-12-07 08:51:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (315, 469, 3, 2, 'Modi quia omnis quidem quam explicabo quo impedit.', '2024-02-04 21:12:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (781, 743, 2, NULL, 'Repellendus saepe est aliquam blanditiis earum officia quibusdam dolores similique.', '2022-10-18 00:40:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (187, 860, 2, 3, 'Labore explicabo commodi aspernatur sed iure consequuntur fugiat nihil doloribus.', '2022-06-07 01:23:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (755, 418, 2, 2, 'Quod magnam debitis tenetur corrupti sit quo.', '2023-06-01 12:14:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (220, 204, 2, NULL, 'Tempore qui quo voluptatem illum incidunt ipsam fugiat.', '2024-04-12 16:23:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (605, 100, 1, NULL, 'Nisi excepturi non voluptatibus corporis facere.', '2022-05-06 13:17:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (301, 364, 2, 3, 'Ipsa doloremque velit laboriosam aliquid cupiditate dolore adipisci.', '2023-05-14 06:40:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (446, 343, 1, 3, 'Dolorum odio voluptatem repudiandae rem alias voluptas reiciendis.', '2024-07-25 16:18:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (341, 152, 2, NULL, 'Itaque iusto magnam quisquam.', '2020-05-18 00:16:43');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (237, 310, 3, NULL, 'Consectetur eum eum suscipit voluptates eius ad beatae totam similique.', '2022-05-06 08:59:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (466, 416, 1, 2, 'Saepe magni enim pariatur exercitationem at veritatis libero.', '2025-04-13 21:58:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (422, 39, 5, NULL, 'Vel voluptatibus sunt qui repellat soluta.', '2021-02-05 09:04:17');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (279, 531, 1, NULL, 'Mollitia vel totam earum impedit fugiat dignissimos.', '2025-01-05 15:01:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (515, 409, 3, NULL, 'Laborum porro eligendi quidem totam provident voluptas ipsum ratione.', '2022-04-25 13:08:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (805, 871, 2, 5, 'Autem consectetur rem saepe alias.', '2021-09-10 21:00:29');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (146, 279, 1, 3, 'Nesciunt saepe veritatis quo veritatis molestiae.', '2023-10-29 06:51:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (994, 257, 5, NULL, 'Ipsum cum voluptas ut assumenda ipsa cumque nihil neque ea.', '2024-04-12 10:45:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (214, 279, 1, 5, 'Eaque non recusandae voluptatibus accusantium a.', '2021-07-01 14:54:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (30, 651, 2, 3, 'Quidem aperiam illo iste veritatis pariatur a totam tempora vero.', '2022-03-09 19:26:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (436, 136, 4, NULL, 'Minima officia tenetur consectetur asperiores aperiam quis natus facere aperiam.', '2023-06-09 18:26:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (722, 754, 3, NULL, 'Delectus natus ratione ipsum beatae provident quas sapiente.', '2020-10-22 15:10:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (846, 562, 3, 3, 'Quasi quod explicabo nemo neque.', '2024-07-10 13:03:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (935, 44, 1, 1, 'Vitae pariatur magnam dicta cupiditate.', '2024-09-26 20:50:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (167, 151, 1, NULL, 'Magni occaecati occaecati ipsa eius maiores nesciunt veritatis quia.', '2022-09-12 10:40:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (409, 684, 2, NULL, 'Iusto adipisci id cumque minus odit voluptates error officia voluptatem.', '2024-09-12 02:13:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (691, 730, 4, NULL, 'Quod dignissimos delectus vero voluptatibus aliquam ab laborum.', '2023-10-24 15:02:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (372, 288, 1, 5, 'Molestias quasi eligendi aut deleniti corrupti.', '2022-11-18 09:52:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (528, 222, 2, NULL, 'Exercitationem earum molestias laboriosam animi blanditiis nam deserunt.', '2025-07-17 19:04:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (626, 234, 4, 1, 'Cupiditate at amet ipsam.', '2021-05-05 22:03:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (536, 247, 1, NULL, 'Minus velit ad dignissimos suscipit occaecati ipsum.', '2020-10-28 13:24:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (603, 715, 5, 3, 'Asperiores praesentium earum officia modi ullam.', '2022-12-29 07:09:50');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (488, 282, 4, 3, 'Quos est dolores soluta excepturi.', '2021-07-01 05:06:54');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (339, 548, 1, NULL, 'Ut quis assumenda ex tempore natus quam maiores adipisci.', '2024-10-28 05:27:23');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (124, 546, 2, 2, 'Similique voluptas rem minima dolore quibusdam.', '2021-05-23 17:19:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (259, 506, 2, NULL, 'Ex et tempore tempora odio praesentium distinctio.', '2020-08-02 15:38:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (203, 144, 1, 3, 'Consectetur illum quisquam minima soluta enim quasi laudantium eum.', '2021-01-31 04:22:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (123, 29, 1, 4, 'Excepturi quibusdam error enim tempore voluptate nisi.', '2022-05-27 17:36:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (841, 240, 5, NULL, 'Saepe similique error culpa illum suscipit repellat sed dolore.', '2021-03-03 18:41:25');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (321, 931, 3, 3, 'Minus corrupti repellat nesciunt suscipit necessitatibus commodi occaecati velit corrupti voluptatibus.', '2025-06-08 18:01:10');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (545, 436, 3, 3, 'Quaerat cupiditate laborum dolorum ab impedit.', '2020-11-09 23:11:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (535, 704, 3, NULL, 'Ullam delectus praesentium ipsa reiciendis ea modi ratione.', '2020-02-04 02:09:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (224, 750, 2, 5, 'Ducimus autem et cum est qui quisquam.', '2021-03-28 08:28:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (412, 754, 1, 3, 'Molestias maxime et dignissimos commodi molestiae atque atque exercitationem.', '2021-05-19 13:32:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (630, 885, 1, 4, 'Explicabo error quis occaecati vel architecto.', '2020-12-29 11:36:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (700, 396, 4, NULL, 'Repellendus soluta beatae est minus incidunt.', '2021-03-26 07:31:30');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (488, 997, 5, NULL, 'Soluta quos possimus at deleniti laborum.', '2022-02-18 14:02:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (633, 895, 2, 4, 'Architecto architecto necessitatibus eum autem sapiente saepe eius.', '2022-11-09 22:51:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (642, 843, 1, 1, 'Nulla eius optio iste dolorem magnam perferendis laudantium.', '2022-10-09 07:43:08');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (517, 58, 1, 3, 'Expedita repudiandae id repellat velit.', '2021-10-23 21:26:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (682, 290, 1, 2, 'Nesciunt animi atque odit veritatis natus quaerat labore.', '2024-08-03 04:49:01');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (766, 164, 2, NULL, 'Sapiente ipsum quos repellat ipsam a quasi.', '2023-12-04 01:34:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (485, 909, 4, 2, 'Repellat veritatis sunt occaecati assumenda possimus voluptates possimus animi eius.', '2023-01-18 21:13:12');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (820, 137, 4, 1, 'Sed ad nulla ipsam labore autem maxime minus.', '2024-12-27 07:38:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (29, 193, 3, NULL, 'Rem numquam quod officia repellendus expedita sed molestias tempore expedita.', '2023-07-05 04:20:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (820, 539, 4, 3, 'Culpa accusantium nam magnam doloribus eos dolorum iusto dolore.', '2024-04-06 22:51:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (559, 694, 3, 1, 'Atque mollitia quis ipsam hic commodi officiis necessitatibus iusto velit earum.', '2022-12-12 17:22:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (891, 916, 3, NULL, 'Molestias laboriosam aperiam deserunt facilis odit facilis quasi.', '2022-06-13 03:44:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (750, 201, 4, NULL, 'Ducimus placeat pariatur delectus eveniet sit mollitia sint perferendis.', '2022-03-06 20:49:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (731, 414, 4, 3, 'Ullam modi magnam esse quis ut vel.', '2022-07-24 01:16:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (795, 755, 1, 3, 'Accusamus assumenda quo quidem repellendus excepturi atque.', '2022-03-06 07:49:36');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (902, 881, 2, 1, 'Qui voluptate reprehenderit inventore rerum quia officia autem.', '2025-08-04 06:08:52');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (611, 628, 4, NULL, 'Vitae nihil recusandae quidem nemo nostrum perspiciatis explicabo.', '2022-12-30 01:49:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (93, 425, 1, NULL, 'Est vel cumque laudantium dolore alias doloribus velit optio.', '2022-11-08 07:38:03');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (176, 647, 2, 4, 'Tempore aliquam aliquid beatae laudantium perferendis sit.', '2021-02-01 04:56:07');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (26, 404, 3, NULL, 'Aut eius veniam voluptate quaerat dolores ullam error.', '2024-03-10 06:12:59');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (84, 547, 5, NULL, 'Blanditiis aspernatur minus quas odit cum.', '2022-04-17 15:01:21');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (947, 184, 1, 1, 'Provident ipsum enim repudiandae ipsa quos exercitationem veniam nemo nihil.', '2020-01-16 20:14:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (348, 638, 3, 5, 'Reprehenderit aut ipsa dignissimos dolor placeat ratione ipsum autem recusandae quod.', '2020-02-12 02:18:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (100, 613, 5, NULL, 'Sapiente quos atque laudantium dolorum magni quasi eaque.', '2020-06-17 01:50:28');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (763, 471, 4, NULL, 'Quae eos velit totam neque quis dignissimos sit numquam.', '2024-09-21 03:16:27');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (30, 793, 2, NULL, 'Ipsum illo voluptatum quia nulla.', '2023-03-02 13:55:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (325, 358, 3, NULL, 'Quae cumque doloremque velit vero nemo fugit.', '2020-04-04 19:14:24');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (769, 85, 1, NULL, 'Recusandae exercitationem aspernatur ipsa ipsa et.', '2025-04-24 09:51:40');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (144, 120, 2, NULL, 'Odit corrupti voluptates dicta sequi eligendi corrupti ipsa perspiciatis.', '2022-01-01 07:20:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (758, 538, 5, 1, 'In porro quia rerum est laboriosam nihil quaerat.', '2022-12-15 07:18:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (452, 117, 4, NULL, 'Iusto repellat provident cupiditate non deleniti.', '2021-08-29 05:05:26');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (446, 265, 5, 3, 'Dolorum atque quia deleniti commodi nesciunt.', '2022-10-05 09:05:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (825, 749, 4, NULL, 'Iusto aspernatur dolorum nemo laudantium quisquam provident odio excepturi.', '2020-12-25 22:38:11');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (130, 74, 5, 2, 'Esse veniam qui doloremque laborum debitis ullam rerum blanditiis.', '2025-06-27 17:29:48');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (56, 598, 1, 3, 'Dolorem quam nobis quam doloribus et.', '2024-08-15 11:06:16');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (975, 516, 2, NULL, 'Corporis occaecati enim non tempora blanditiis ea.', '2021-03-28 02:58:34');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (159, 52, 5, NULL, 'Fugiat nisi sunt quisquam accusantium pariatur nesciunt.', '2023-05-07 18:02:14');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (917, 781, 1, 2, 'Optio consequuntur aperiam veritatis accusamus blanditiis impedit explicabo nisi.', '2021-04-06 22:50:13');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (535, 600, 3, 4, 'Itaque soluta ex corporis architecto sint doloremque.', '2024-09-30 05:57:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (674, 92, 5, 4, 'Fugiat nobis aperiam praesentium occaecati consequuntur asperiores quibusdam commodi laborum.', '2021-12-07 05:05:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (639, 769, 5, 1, 'At accusantium eveniet pariatur debitis.', '2021-04-21 11:02:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (698, 504, 1, 5, 'Excepturi veniam doloremque placeat expedita.', '2023-10-25 13:36:00');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (828, 234, 2, 5, 'Eaque porro dignissimos laborum fugiat perspiciatis velit reprehenderit.', '2025-02-20 20:57:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (218, 761, 4, 2, 'Aliquam dolorum dolorum dolore nam.', '2020-12-04 18:47:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (23, 802, 1, NULL, 'Nulla odit sit consequatur non quia earum eaque libero.', '2023-01-22 08:46:55');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (340, 854, 3, 2, 'Id sequi aut vel sed praesentium.', '2022-10-05 09:01:46');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (545, 649, 5, NULL, 'Fugit amet fugit odio in placeat molestiae quae.', '2024-11-05 20:46:58');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (673, 83, 4, 3, 'Labore non veniam ad sint modi earum ab earum.', '2024-07-03 19:25:06');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (848, 810, 4, NULL, 'Necessitatibus vel quod in ipsa temporibus dolores.', '2020-03-24 22:57:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (861, 27, 3, 4, 'Maiores harum officiis amet ut deserunt rem.', '2022-05-08 12:58:18');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (587, 983, 2, 2, 'Distinctio iusto quo dicta a repudiandae quam voluptates illo deleniti.', '2020-08-22 22:50:37');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (100, 484, 2, 1, 'Dolorem reiciendis voluptatum earum possimus.', '2021-01-26 21:54:51');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (428, 381, 2, 3, 'Voluptas sed debitis cupiditate similique.', '2021-07-19 10:00:15');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (476, 490, 4, 5, 'Asperiores labore magni animi cum itaque labore quo.', '2020-12-29 07:36:05');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (288, 964, 3, NULL, 'Similique ex fuga odio consectetur alias.', '2024-03-26 04:53:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (755, 23, 2, NULL, 'Necessitatibus ex itaque consequuntur sed recusandae ipsam in accusantium.', '2025-05-03 14:35:38');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (268, 416, 5, NULL, 'Dolore laborum nisi nemo provident exercitationem voluptas esse iusto magni.', '2022-03-14 11:27:44');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (652, 127, 4, NULL, 'Voluptates eaque quod molestias laborum cum expedita quis nisi amet ex.', '2022-02-01 11:54:47');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (233, 703, 4, 1, 'Harum facilis a inventore nisi provident odio vero aperiam.', '2021-09-23 19:19:56');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (113, 406, 2, 3, 'Esse veniam vitae repellat autem atque quidem harum.', '2023-04-02 10:03:57');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (973, 233, 4, NULL, 'Id iusto consectetur quo accusantium architecto animi ratione esse quasi.', '2024-02-15 23:31:09');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (141, 942, 5, 3, 'Labore reiciendis quam corporis quas soluta.', '2022-01-05 06:01:39');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (935, 690, 3, 5, 'Iure animi ea ut dolorem magni vero inventore sint.', '2024-09-22 19:27:35');
INSERT INTO reviews (customer_id, restaurant_id, restaurant_rating, rider_rating, comment, created_at)
                      VALUES (226, 717, 4, 1, 'Itaque suscipit sed dolore nostrum at sunt architecto laborum magnam.', '2023-12-31 00:42:53');
